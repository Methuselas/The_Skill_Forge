---
object_id: DRILL_audit_resource_detail_by_decision_effect
object_type: drill
name: Audit Resource Detail by Decision Effect
library_path:
- game-design
- mechanics
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- resources
- simulation
- abstraction
- playtesting
- decisions
cross_links:
- rel: teaches
  target_object_id: PAT_compress_resource_contents_without_erasing_resource_constraints
- rel: teaches
  target_object_id: PAT_couple_resource_pools_through_shared_bottlenecks_and_conversion
- rel: related_to
  target_object_id: PAT_budget_mechanical_operating_cost_by_decision_value_and_activation_cadence
reference:
  source_title: 'Twilight: 2000 (1st Edition) and Twilight: 2000 Version 2.2'
  author: Frank Chadwick; David Nilsen, Loren Wiseman, and Lester Smith
confidence: high
target_skill: Determine which tracked resource distinctions create actual planning
  and which only create clerical state.
references: []
variants: []
---

# Audit Resource Detail by Decision Effect

## Practice Task
Audit one resource-heavy subsystem by tracing every tracked distinction into an actual player choice, then rerun a representative scenario after compressing one low-value distinction.

## Target Skill
Determine which tracked resource distinctions create actual planning and which only create clerical state.

## Setup
Choose a subsystem with at least three resource distinctions and a representative scenario in which some of those resources can be depleted, substituted, converted, or resupplied. Include at least two resources that compete through a shared bottleneck such as time, money, cargo, labor, access, mobility, or exposure.

## Instructions
1. List every resource field the table must track and the cadence at which it changes.
2. For each field, name the decision it can change: route, timing, load, equipment, staffing, risk, social need, mission priority, or another concrete choice. For equipment, include world-facing fields such as availability, legality, concealability, traceability, maintenance, and resale/liquidity when they change behavior outside the moment of use. Treat acquisition difficulty, possession legality, and evidence/transaction trail as separate axes when each produces different choices.
3. Mark the shared bottlenecks that connect resources, such as time, labor, cargo, mobility, money, access, exposure, or future risk.
4. Execute the scenario once with the full resource model and record the decisions that actually occur.
5. Select one distinction that produced bookkeeping but no observed decision, compress or remove it, and rerun the same scenario.
6. Compare the two runs. Keep the compression only if the same meaningful constraints and tradeoffs remain legible.
7. Test one plausible broader compression that would merge several tracked resource distinctions, including a single universal-supply abstraction when it can represent the tested resources, and identify which observed decisions from the full run it would preserve or erase.

## Success Check
- Every retained resource distinction is tied to at least one observed decision in the full-detail run.
- At least one resource interaction through a shared bottleneck was actually exercised rather than merely predicted.
- The compressed rerun was executed and preserved the named decision-bearing constraints.
- A named near-miss is excluded: replacing all resources with one universal supply meter does not pass if ammunition, medicine, fuel, food, or parts changed behavior differently in the full run.
- The final keep/compress decision states which choice would be lost or preserved, not merely that the detail feels realistic.

## Common Failures
- Keeping a field because it corresponds to a real object without identifying any decision it changes.
- Removing a distinction after observing only a scenario in which the resource never became scarce.
- Comparing bookkeeping quantity without testing substitution, conversion, or shared bottlenecks.
- Calling two resources interchangeable when their depletion changes different capabilities.

## Notes
Resource detail earns its cost at the boundary where remaining supply or ownership state changes planning. The audit therefore tests resources under pressure rather than judging their names or realism in isolation. Equipment fields can justify substantial detail when they alter acquisition, movement through the world, legal exposure, traceability, maintenance, or conversion back into spendable value—not only tactical performance.

This drill practices the capabilities owned by **Compress Resource Contents Without Erasing Resource Constraints** and **Couple Resource Pools Through Shared Bottlenecks and Conversion**.
