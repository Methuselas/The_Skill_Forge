---
object_id: PAT_build_complete_resolution_procedures_incrementally
object_type: pattern
name: Build Complete Resolution Procedures Incrementally
library_path:
- game-design
- mechanics
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- mechanics
- resolution
- procedures
- integration
cross_links:
- rel: related_to
  target_object_id: PAT_reuse_core_resolution_grammar_before_adding_new_mechanics
- rel: related_to
  target_object_id: PAT_make_the_game_operable_without_hidden_designer_knowledge
- rel: related_to
  target_object_id: PAT_evaluate_mechanics_by_the_decisions_and_agency_they_create
- rel: related_to
  target_object_id: PAT_invoke_resolution_only_for_meaningful_uncertainty
reference:
  source_title: Designing TTRPGs For Dummies
  author: Martin Buinicki
confidence: high
references: []
variants: []
---

# Build Complete Resolution Procedures Incrementally

## Pattern Rule
**IF** an action requires multiple mechanics, conditional branches, or state changes to resolve completely
**THEN** begin with the smallest dependency-ordered procedure that can carry the action from trigger to final state, validate that baseline, and add mechanics one at a time at the point where their required inputs already exist, retesting the complete affected procedure after every addition
**ELSE** when one mechanic already resolves the action completely, do not add procedural stages merely to make the system appear more detailed.

## Do
- Define the procedure's trigger, required inputs, initial state, terminal state, and minimum successful path before adding optional detail.
- Put each mechanic after the information or state it depends on has been produced; dependency order is part of the design, not only presentation.
- Establish and execute a known-working baseline before inserting another mechanic.
- Test a new mechanic both in isolation and inside every affected path of the larger procedure.
- After each addition, execute the full affected procedure from declaration through termination and verify that state, resources, modifiers, and consequences remain coherent.
- When a new mechanic breaks a previously working procedure, classify the defect as belonging to the mechanic itself, its insertion/order, or its interaction with existing state before adding another rule.
- Make branches explicit when different conditions call different mechanics; each branch should state its entry condition, state changes, and where control returns or terminates.
- Place resource expenditure, interruption points, resistance, and state writes at explicit steps so partial execution has a coherent result.
- Refactor the underlying procedure when repeated additions require precedence exceptions, adapters, or contradictory state assumptions.

## Don't
- Design a large stack of interdependent mechanics and postpone integration testing until the entire subsystem is assembled.
- Insert a mechanic before the values, state, or choices it needs have been established.
- Treat a mechanic that works alone as proof that it will compose correctly with the rest of the procedure.
- Patch every new collision with another exception while preserving a procedure whose underlying order no longer makes sense.
- Leave trigger timing, precedence, resource expenditure, branch conditions, control return, or termination implicit when multiple mechanics can interact.
- Add another stage immediately after an integration failure before identifying whether the mechanic, insertion point, or interaction is actually at fault.

## Checklist
- The smallest complete baseline can be executed from trigger to final state without relying on mechanics that have not yet been defined.
- Every added mechanic has a named insertion point and the inputs it requires already exist at that point.
- The complete affected procedure was retested after the most recent addition rather than only the new mechanic being tested alone.
- A failure introduced by a new mechanic can be classified as a mechanic failure, insertion/order failure, or interaction failure before another rule is added.
- Branches say what condition enters them, what state they change, and where control returns or terminates.
- Resource spending and state changes occur at explicit points that remain coherent if the action is interrupted, resisted, or fails.
- Repeated exceptions trigger a refactor decision rather than indefinite rule accretion.
- Another reader can follow the written procedure from trigger through every supported terminal state without supplying hidden sequencing assumptions.

## Notes
A mechanic performs an operation; a resolution procedure composes mechanics into an executable action. Combat makes this distinction easy to see: an attack check, Dodge, damage roll, armor reduction, resistance test, and injury rule can each work independently while their ordering and interaction still fail as a whole. Build the minimum complete chain first — for example, attack -> hit or miss -> damage — then insert defense, resistance, armor, criticals, locations, or other mechanics only after the simpler procedure works. The same method applies to repair, crafting, training, spellcasting, hacking, social actions, travel, and other multi-step resolution.

This Pattern owns **dependency ordering and incremental integration**. Common-path gating, operating-cost compression, persistent-state granularity, and moving repeated invariant work into shared procedures or data are adjacent optimization decisions that should be evaluated after the procedure itself is executable.
