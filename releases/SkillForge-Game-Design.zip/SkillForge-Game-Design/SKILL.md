---
name: skillforge-game-design
description: Use for designing, revising, critiquing, and playtesting game mechanics,
  characters, adversaries, adventures, and playable worlds using the SkillForge Game
  Design knowledge library.
---

# SkillForge Game Design

This is a self-contained SkillForge release.

`runtime/profile.yaml` (profile `generic`) is this release's **execution contract**. It declares the execution modes, routing, risk checks, and completion requirements this skill is expected to honor. Do not preload it for discussion, critique, help, or another non-productive request. Before the first productive action, resolve the execution mode, apply the activated metaskills, perform the named risk checks, and satisfy the completion requirements. That responsibility is yours — nothing in this package can check it for you.

`scripts/skillforge_runtime.py` is an **optional deterministic helper** for hosts that can execute Python. It holds no state, runs only when invoked, and cannot observe or block anything you do:

- `doctor` checks that the bundled profile and library are internally consistent.
- `resolve --request <user request>` returns the contract for a request as JSON, so mode and check selection are deterministic instead of re-derived each time.
- `verify` audits a completion record you write, and reports which required checks it does not contain.

Prefer the resolver's bounded result to loading the complete profile. Where Python is unavailable, read and apply `runtime/profile.yaml` directly. The release is complete without Python.

The semantic craft knowledge lives in `library/`. Python resolves and reports; it does not sequence stages, gate approvals, or enforce the contract. Hard prerequisites have already been materialized locally. Each card is self-contained: it needs no source document to execute.

## Bundled knowledge

Load `library/metaskills/INDEX.md` as the default baseline, then retrieve only the domain indexes and cards relevant to the current decision. `RELEASE_MANIFEST.json` lists every bundled module; do not preload that list or the complete library.

## Skillset Memory

`memory/<domain>/skill_memory.yaml` is this skillset's **empirical record**: what actually happened when this canon was used, including known weak areas and the boundaries of what has been verified. It is not canon and never overrides a card. Consult it when a task touches a scope it names, and read each entry as an observation carrying a stated confidence, not as an instruction. `training_history.jsonl` holds the events an entry was consolidated from; an event marked `invalid` failed before the capability was exercised and is evidence about a tool or a package, never about craft.

These files ship **read-only**. This package is not the persistence target: new events belong to the library that owns the store, so do not append to them, edit them, or copy their content into a card or a prompt.

- `memory/game-design/`
