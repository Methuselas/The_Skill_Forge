---
object_id: writing_fiction_drill_differentiate_character_voices_through_parallel_monologues
object_type: drill
name: Differentiate Character Voices through Parallel Monologues
library_path:
  - writing
  - fiction
  - character
stage_binding: 1 skeleton
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags:
  - fiction
  - character
  - voice
  - monologue
  - diction
  - deliberate_practice
cross_links:
  - rel: related_to
    target_object_id: writing_fiction_let_relationship_and_setting_shape_dialogue
  - rel: related_to
    target_object_id: writing_choose_diction_to_serve_purpose_and_tone
  - rel: related_to
    target_object_id: writing_read_draft_aloud_to_defamiliarize_it
  - rel: related_to
    target_object_id: writing_fiction_drill_audit_marked_character_speech_for_individuality_accuracy_and_legibility
reference:
  source_title: "Creative Writing: A Workbook with Readings"
  author: Linda Anderson
confidence: high
references: []
target_skill: Giving characters distinguishable voices grounded in attention, motive, relation, and spoken rhythm
variants:
  - variant_id: writing_fiction_variant_alternate_accounts_of_a_disputed_event
    variant_name: Alternate Accounts of a Disputed Event
    variant_basis: context
    difference_from_foundation: Turn the parallel monologues into first-person narrative accounts of the same conflict, requiring each speaker to contribute distinct evidence and a persuasive interpretation that can shift reader allegiance.
    when_to_use: A story may use competing narrators or needs to test whether more than one character can plausibly own the conflict.
    when_not_to_use: One account supplies all meaningful access or the second voice only repeats facts without changing their meaning.
    absorbed_from_object_id: none
---

# Differentiate Character Voices through Parallel Monologues

## Practice Task
Write two characters' monologues about the same immediate situation, compare their verbal choices by ear, and revise until each voice reveals a different person without depending on a stock label.

## Target Skill
Differentiate fictional voices through attention, motive, syntax, rhythm, diction, directness, and relation rather than through interchangeable authorial prose or decorative dialect.

## Setup
Choose two characters with different desires, knowledge, and relationships to one shared event. Give both the same addressee or equivalent reason to speak so the comparison tests voice rather than unrelated subject matter.

## Instructions
1. State what each speaker wants from the listener and what each is unwilling or unable to say directly.
2. List the categories of detail each character would notice, the words each knows or avoids, the degree of authority each believes they possess, and the languages, dialects, occupational vocabularies, or registers each would use with this addressee.
3. Draft a short monologue for the first character without consulting the second character's planned phrasing.
4. Draft the second monologue at a similar length, changing sentence movement, pace, directness, figurative habits, and selection of detail as the person and relation require.
5. Read both aloud. Mark places where the characters share the same polished syntax, explanation habits, jokes, or emotional vocabulary without a credible reason.
6. Exchange one sentence between the monologues. If it survives unchanged, revise it around the receiving speaker's attention, knowledge, motive, and social permission.
7. Remove phonetic spelling, catchphrases, profanity, or verbal tics that serve only as identity labels. When a retained voice depends on unfamiliar dialect, multilingual wording, accent marking, or a speech difference, run `writing_fiction_drill_audit_marked_character_speech_for_individuality_accuracy_and_legibility` before treating the distinction as credible.
8. Compare what each voice conceals, assumes, and tries to make the listener do. Revise until those differences affect more than sound.

## Success Check
- Each speaker's want from the listener and each speaker's unsayable are stated before drafting.
- The second monologue is drafted without consulting the first's planned phrasing, so difference is produced rather than negotiated.
- The voices differ in sentence movement, pace, directness, figurative habit, and selection of detail, not in dialect markers or verbal tics alone.
- Shared phrasing is marked on reading aloud and revised, including where the shared phrasing is good.
- Neither voice leans on a stock label; profession, class, or region does not perform the work the language should.
- Any marked language is grounded in the speaker's repertoire and present addressee, and the comparison does not make one speaker conspicuous against an unnamed neutral voice by default.
- A reader can attribute an unlabelled line to its speaker, and any line failing that is named.

## Common Failures
- Giving one character long sentences and the other short ones while their attention and motives remain identical.
- Replacing individual voice with accent, misspelling, slang, or a repeated catchphrase.
- Letting both speakers explain background for the reader in the author's prose style.
- Choosing unlike subjects so differences in content conceal sameness of voice.
- Making the more articulate character automatically more intelligent or truthful.

## Notes
Parallel conditions expose voice more clearly than unrelated speeches. A character's voice is not a bag of verbal ornaments; it is the audible result of what that person notices, knows, wants, withholds, and believes can be said to this listener. Reading aloud tests whether the designed differences survive as speech.

`writing_fiction_variant_alternate_accounts_of_a_disputed_event` changes the comparison from spoken performance to narrative ownership. Draft each character's version of one conflict, retain only overlap whose meaning changes between tellers, and compare what each account makes readers believe or feel. Use the variant when both voices complicate the story; reject the second narrator when it adds sound but no necessary interpretation.
