---
object_id: writing_fiction_ap_draft_and_revise_a_dialogue_scene
object_type: ap
name: Draft and Revise a Dialogue Scene
library_path:
  - writing
  - fiction
  - dialogue
stage_binding: 1 skeleton
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags:
  - fiction
  - dialogue
  - scene
  - drafting
  - revision
cross_links:
  - rel: supports
    target_object_id: writing_fiction_compress_real_speech_into_purposeful_dialogue
  - rel: supports
    target_object_id: writing_fiction_let_relationship_and_setting_shape_dialogue
  - rel: supports
    target_object_id: writing_fiction_combine_dialogue_with_action_thought_and_silence
  - rel: supports
    target_object_id: writing_fiction_choose_direct_or_reported_dialogue_by_effect
  - rel: supports
    target_object_id: writing_fiction_orient_speakers_with_unobtrusive_formatting_and_tags
  - rel: supports
    target_object_id: writing_make_nonstandard_language_deliberate
  - rel: supports
    target_object_id: writing_read_draft_aloud_to_defamiliarize_it
  - rel: related_to
    target_object_id: writing_fiction_drill_audit_marked_character_speech_for_individuality_accuracy_and_legibility
  - rel: related_to
    target_object_id: writing_fiction_drill_stage_and_audit_multi_speaker_dialogue_scene
  - rel: related_to
    target_object_id: writing_fiction_drill_compress_long_speech_through_listener_filtered_selection
reference:
  source_title: "Creative Writing: Four Genres in Brief"
  author: David Starkey
confidence: high
references: []
variants: []
---

# Draft and Revise a Dialogue Scene

## Objective
Create or revise a fiction scene in which spoken and unspoken behavior sounds socially plausible, changes the story, remains easy to follow, and uses direct speech only where its immediacy earns space.

## Steps / Flow
1. **Name the scene change.** Start with the speakers, immediate situation, and what must be different by the end: knowledge, power, commitment, relation, or available action. State what each speaker wants from the exchange, resists, knows, and cannot or will not say. Preserve that intended change and each character's established motives as invariants. Pressure may arise from opposed aims, unequal knowledge, incompatible readiness, evasion, negotiation, or discovery without requiring overt argument. When three or more active speakers participate, run `writing_fiction_drill_stage_and_audit_multi_speaker_dialogue_scene` to distinguish the pressure network from ambient crowd presence and require each retained participant to contribute distinct pressure, access, interpretation, or consequence. **Advance gate:** the conversation has a job beyond displaying voice, and no active speaker survives merely to fill the room.
2. **Set the social conditions.** Activate `writing_fiction_let_relationship_and_setting_shape_dialogue`. Record who is speaking to whom, relative power and intimacy, location, occasion, ownership, privacy, witnesses, noise, interruption, concurrent tasks, participant state, and risk. Select the communication channel; when it materially changes access, activate `writing_fiction_variant_let_communication_channel_shape_dialogue` and record available cues, latency, privacy, persistence, interruption, and concealed secondary activity. When limited time changes the speakers' choices, activate `writing_fiction_variant_constrain_dialogue_with_consequential_deadline` and define the expiry event and cost. If the same exchange would fit any pair, place, condition, or channel, revise the conditions before drafting lines.
3. **Choose the delivery branch.** Activate `writing_fiction_choose_direct_or_reported_dialogue_by_effect`. Use direct speech where timing, exact wording, or vocal presence carries force; report what needs compression or a revealing narrator filter. When a long speech, account, briefing, interview, or presentation carries necessary information, run `writing_fiction_drill_compress_long_speech_through_listener_filtered_selection`; use its active-exchange variant when institutional form, questioning rights, visual aids, or participant agendas affect delivery. If neither direct nor reported form earns the passage, omit the exchange and narrate only its consequence.
4. **Draft the verbal action.** Activate `writing_fiction_compress_real_speech_into_purposeful_dialogue`. Write speech-like rhythms and fragments, then test each turn for what it reveals or changes. When unfamiliar dialect, multilingual wording, accent marking, slang, code-switching, or a speech difference carries characterization, activate `writing_make_nonstandard_language_deliberate` and run `writing_fiction_drill_audit_marked_character_speech_for_individuality_accuracy_and_legibility`; preserve the individual's language repertoire, social context, and dignity while testing accuracy and legibility. **Advance gate:** no retained exchange consists only of routine talk, shared exposition, polished authorial sentences, or decorative identity markers.
5. **Expose the unsaid.** Activate `writing_fiction_combine_dialogue_with_action_thought_and_silence`. When a consequential subject cannot yet be named, use `writing_fiction_variant_make_unmentionable_subject_legible_through_displaced_talk` to give the surface exchange a credible purpose and readers enough converging evidence to infer the pressure. When an unintended word or name creates the turn, use `writing_fiction_variant_let_verbal_slip_trigger_contested_interpretation` and make repair, interpretation, and response consequential without treating the mistake as proven unconscious truth. Add only those pauses, gestures, thoughts, and actions that contradict, conceal, intensify, or redirect the words. Permit explicit disclosure when changed conditions make it the earned turn. If beats merely decorate every line, remove them; if obscurity supplies no reader footing, restore evidence; if a wall of speech erases bodies and subtext, restore them at pressure points.
6. **Orient the reader.** Activate `writing_fiction_orient_speakers_with_unobtrusive_formatting_and_tags`. Give each speaker a paragraph, establish turn order, and retag after ambiguity-producing interruptions, movement, entrances, exits, or added speakers. Name and track active participants while allowing ambient people to remain collective until they become consequential. **Advance gate:** a cold reader can assign every line without noticing attribution as a competing performance.
7. **Test by ear.** Use `writing_fiction_variant_read_dialogue_aloud_for_spoken_authenticity` within `writing_read_draft_aloud_to_defamiliarize_it`. Read every spoken line aloud or have another person read it. Route false formality back to step 4, socially implausible wording to step 2, and unclear identity to step 6.
8. **Cut and complete.** Remove repetitions, greetings, tags, and explanatory beats whose absence changes nothing. Stop when every exchange is speakable, context-specific, correctly oriented, and consequential; direct and reported speech serve deliberate effects; and action or silence carries meaning that words alone would flatten.

## Notes
The order protects downstream work from upstream vagueness. Voice cannot be judged before the social situation is known, and tag polishing cannot rescue an exchange with no story job. The flow allows mostly spoken scenes, sparse culminating lines, and fully reported conversations; it gates them by effect rather than by a fixed quota.
