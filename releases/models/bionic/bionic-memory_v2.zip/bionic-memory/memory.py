#!/usr/bin/env python3
"""Bionic Memory: persistent Markdown memory with an index that is always rebuilt from the entries.

    python memory.py index  [--project PATH]
    python memory.py read   NAME [NAME ...] [--project PATH]
    python memory.py write  NAME --type TYPE --description TEXT [--body TEXT | --body-file FILE | stdin]
                            [--confidence provisional|strong] [--author NAME] [--project PATH]
    python memory.py delete NAME [NAME ...] [--project PATH]
    python memory.py rebuild [--project PATH]

Without --project the global memory is used. Memory lives in ~/.bionic-memory/memory/: global/ for
regular chats, Project/<folder>/ for a workspace, where <folder> is the workspace path with every
character other than a letter or digit replaced by "-" (D:\\Repos\\PASS -> D--Repos-PASS).
Python 3.8+, standard library only.
"""

import argparse
import os
import re
import sys
from datetime import datetime, timezone

INDEX_FILE = "MEMORY.md"
TYPES = {
    "user": "who the user is, how they work, stable preferences",
    "project": "current work, decisions, goals, blockers",
    "feedback": "corrections and confirmed approaches: do X, not Y",
    "reference": "pointers to external resources, docs, tools",
}
CONFIDENCE = ("provisional", "strong")
MAX_READ = 8
MAX_BODY_CHARS = 4000
MAX_DESCRIPTION_CHARS = 200
NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
FIELDS = ("name", "description", "type", "confidence", "author", "modified")


class MemoryError_(Exception):
    pass


def memory_root(project):
    base = os.path.join(os.path.expanduser("~"), ".bionic-memory", "memory")
    if not project:
        return os.path.join(base, "global")
    return os.path.join(base, "Project", re.sub(r"[^A-Za-z0-9]", "-", os.path.abspath(project).rstrip("\\/")))


def check_name(name):
    if not NAME.match(name) or len(name) > 64:
        raise MemoryError_(f"'{name}' is not a valid entry name; use lowercase words joined by hyphens, e.g. user-terse")
    # Windows file names ignore case, so "memory.md" would overwrite the index.
    if name + ".md" == INDEX_FILE.lower():
        raise MemoryError_(f"'{name}' is reserved for the index")


def parse(text):
    """Front matter fields plus "body"; empty if the file is not an entry."""
    if not text.startswith("---"):
        return {}
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}
    entry = {}
    for line in parts[1].strip().splitlines():
        key, sep, value = line.partition(":")
        if sep:
            entry[key.strip()] = value.strip()
    entry["body"] = parts[2].strip()
    return entry if entry.get("name") and entry.get("type") else {}


def entries(root):
    found = []
    for file_name in sorted(os.listdir(root)):
        if not file_name.endswith(".md") or file_name == INDEX_FILE:
            continue
        with open(os.path.join(root, file_name), encoding="utf-8") as f:
            entry = parse(f.read())
        # Only well-formed entries whose name matches their file count; other files are left alone.
        if entry and entry["name"] + ".md" == file_name:
            found.append(entry)
    return found


def rebuild(root):
    order = list(TYPES)
    found = entries(root)
    lines = ["# Memory Index", "",
             "<!-- Rebuilt from the entry files by memory.py. Edit entries, not this file. -->", ""]
    for e in sorted(found, key=lambda e: (order.index(e["type"]) if e["type"] in order else len(order), e["name"])):
        lines.append(f"- [{e['name']}]({e['name']}.md) — {e.get('description', '')} `{e['type']}`")
    with open(os.path.join(root, INDEX_FILE), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
    return found


def ensure(root):
    os.makedirs(root, exist_ok=True)
    if not os.path.exists(os.path.join(root, INDEX_FILE)):
        rebuild(root)


def cmd_index(root, args):
    ensure(root)
    # Rebuilding on every read repairs an index someone edited by hand.
    rebuild(root)
    print(f"Memory: {root}")
    with open(os.path.join(root, INDEX_FILE), encoding="utf-8") as f:
        print(f.read().rstrip())


def cmd_read(root, args):
    if len(args.names) > MAX_READ:
        raise MemoryError_(f"Read at most {MAX_READ} entries at a time; pick the ones relevant to the task")
    for name in args.names:
        check_name(name)
    ensure(root)
    found = {e["name"]: e for e in entries(root)}
    for name in args.names:
        e = found.get(name)
        if not e:
            print(f"## {name}\n(missing)\n")
            continue
        meta = ", ".join(f"{k}: {e[k]}" for k in FIELDS[2:] if k in e)
        print(f"## {name}\n{e.get('description', '')}\n({meta})\n\n{e['body']}\n")


def cmd_write(root, args):
    check_name(args.name)
    if args.type not in TYPES:
        raise MemoryError_(f"Unknown type '{args.type}'; use one of: {', '.join(TYPES)}")
    description = " ".join(args.description.split())
    if not description or len(description) > MAX_DESCRIPTION_CHARS:
        raise MemoryError_(f"description is one line of 1-{MAX_DESCRIPTION_CHARS} characters")
    if args.body is not None:
        body = args.body
    elif args.body_file:
        with open(args.body_file, encoding="utf-8") as f:
            body = f.read()
    elif sys.stdin is None or sys.stdin.isatty():
        raise MemoryError_("body is missing; pass --body, --body-file or pipe it on stdin")
    else:
        body = sys.stdin.read()
    body = body.strip()
    if not body:
        raise MemoryError_("body is empty; pass --body, --body-file or stdin")
    if len(body) > MAX_BODY_CHARS:
        raise MemoryError_(f"body is over {MAX_BODY_CHARS} characters; an entry holds one fact, so split it")
    if body.startswith("---"):
        raise MemoryError_("body cannot start with '---'")

    ensure(root)
    path = os.path.join(root, args.name + ".md")
    existed = os.path.exists(path)
    header = [f"name: {args.name}", f"description: {description}", f"type: {args.type}",
              f"confidence: {args.confidence}"]
    if args.author:
        header.append(f"author: {' '.join(args.author.split())}")
    header.append("modified: " + datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("---\n" + "\n".join(header) + "\n---\n\n" + body + "\n")
    rebuild(root)
    print(f"{'Updated' if existed else 'Created'} {args.name}")


def cmd_delete(root, args):
    for name in args.names:
        check_name(name)
    ensure(root)
    for name in args.names:
        path = os.path.join(root, name + ".md")
        if os.path.exists(path):
            os.remove(path)
            print(f"Deleted {name}")
        else:
            print(f"Missing {name}")
    rebuild(root)


def cmd_rebuild(root, args):
    ensure(root)
    print(f"Index rebuilt: {len(rebuild(root))} entries")


def main(argv=None):
    # Windows consoles default to a legacy code page; entries and the index are UTF-8.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="Bionic Memory")
    parser.add_argument("--project", default="", help="workspace path; omit for global memory")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("index")
    p = sub.add_parser("read")
    p.add_argument("names", nargs="+")
    p = sub.add_parser("write")
    p.add_argument("name")
    p.add_argument("--type", required=True)
    p.add_argument("--description", required=True)
    p.add_argument("--body")
    p.add_argument("--body-file")
    p.add_argument("--confidence", choices=CONFIDENCE, default="provisional")
    p.add_argument("--author", default="")
    p = sub.add_parser("delete")
    p.add_argument("names", nargs="+")
    sub.add_parser("rebuild")
    # --project may come before or after the command.
    args, rest = parser.parse_known_args(argv)
    if rest:
        extra = argparse.ArgumentParser()
        extra.add_argument("--project", default=args.project)
        more, unknown = extra.parse_known_args(rest)
        if unknown:
            parser.error(f"unrecognized arguments: {' '.join(unknown)}")
        args.project = more.project

    handlers = {"index": cmd_index, "read": cmd_read, "write": cmd_write, "delete": cmd_delete, "rebuild": cmd_rebuild}
    try:
        handlers[args.command](memory_root(args.project), args)
    except MemoryError_ as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
