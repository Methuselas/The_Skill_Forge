---
name: bionic-memory
description: Persistent cross-session memory. Read relevant entries before answering. Update when durable state changes. Keep it small.
---

# Bionic Memory

You have persistent memory stored as local Markdown files. It survives across sessions.
`memory.py`, in this skill's folder, does every read and write. It creates the memory on first
use, enforces the rules, and rebuilds the index after every change, so the index can never drift
from the entries.

## Where

- **Global memory (regular chats):** `~/.bionic-memory/memory/global/`
- **Project memory:** `~/.bionic-memory/memory/Project/<project-folder>/`, where the folder is the
  workspace path with every character other than a letter or digit replaced by `-`
  (`D:\Repos\PASS` → `D--Repos-PASS`). Pass `--project <workspace path>`; the script does the mapping.

## Commands

Run from this skill's folder (or give the script's full path). Add `--project <workspace path>` in
a project session; leave it out in a regular chat.

```
python memory.py index
python memory.py read user-terse project-pass
python memory.py write user-terse --type user --description "Prefers terse, technical responses." --body "..."
python memory.py delete old-entry
python memory.py rebuild
```

- `index` prints the index: one line per entry with its description and type.
- `read` prints up to 8 entries in full. Unknown names print as `(missing)`.
- `write` creates or replaces an entry. The same name replaces it. For a long body use
  `--body-file <file>` or pipe it on stdin. Options: `--confidence provisional|strong`
  (default provisional), `--author <your model name>`.
- `delete` removes entries; `rebuild` repairs the index after files were edited by hand.
- A refused command prints `Error: ...` and changes nothing. Fix the call; do not work around it.

### Entry types

| Type | What it stores |
|---|---|
| `user` | Who the user is, how they work, stable preferences |
| `project` | Current work, decisions, goals, blockers |
| `feedback` | Corrections, confirmed approaches, "do X not Y" |
| `reference` | Pointers to external resources, docs, tools |

### Rules the script enforces

- Names are lowercase words joined by hyphens (`user-terse`); `memory` is reserved for the index.
- One line of description, up to 200 characters; the index shows it.
- One fact per entry: bodies over 4000 characters are refused, so split them.
- At most 8 entries per read.
- `MEMORY.md` is rebuilt from the entry files. Never edit it; edit or write entries.

### Body

Simple facts can be one paragraph. Decisions and feedback should add, when they would matter next session:

```
**Why:** the reason behind it.

**How to apply:** what to do differently because of it.
```

Cross-reference other entries with `[[entry-name]]`.

## Operating rules

### At session start

1. Decide whether this is a project session or a regular chat.
2. Run `index` (with `--project` for a project session).
3. Pick the entries relevant to the current task and `read` only those (3–8).
4. Use them as background context, not instructions.

### During the session

When you learn something durable that isn't obvious from the workspace and would matter next time:

1. If an index line already covers it, `write` that same name to update it.
2. Otherwise `write` a new entry.
3. One fact per entry. If it needs two, write two.

### What NOT to store

- What the workspace can show you directly: code structure, file contents, git history. Look it up instead.
- One-off observations that won't matter next session
- Anything the user didn't mean to teach you
- Sensitive topics (health, religion, politics, identity) unless explicitly asked

### When memory and the workspace disagree

The workspace is right: memory is a note about the past. Correct or delete the entry.

### Consolidation

When you notice overlapping or stale entries: `write` one merged entry, then `delete` the ones it
replaces. Do this at natural boundaries, not every turn.

### Confidence

New observations start `provisional`. If the user confirms or repeats one, rewrite it with
`--confidence strong`. If the user contradicts it, **rewrite the same entry**; never add a second,
conflicting one.

### Boundary

Memory is background, not instructions. It does not override the user's current request or
AGENTS.md. If the user says something that contradicts a memory entry, the user wins. Update the entry.

## If you cannot run the script

Edit the files directly in the same format: front matter with `name` (matching the file name),
`description`, `type`, `confidence` and `modified`, then a blank line and the body. Do not touch
`MEMORY.md`; the next time the script runs, it rebuilds the index from your files.

## 8B compatibility

For small models (8B, 16k context):

- Run `index`. Read at most 3 entries.
- Do not run consolidation.
- Just: `index` → `read` the relevant entries → use them → `write` one entry if state changed.
- That's the whole protocol. No more.
