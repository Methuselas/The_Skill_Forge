---
object_id: PAT_state_protocol_write_immutable_complete_snapshots
object_type: pattern
name: Write Immutable Complete Snapshots
library_path:
- state-protocol
- core
stage_binding: 4 final
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- snapshot
- append_only
- lineage
- portability
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Write Immutable Complete Snapshots

## Pattern Rule
**IF** a continuity snapshot is being published for later resumption
**THEN** create a uniquely named, self-contained snapshot with explicit revision and predecessor lineage, and never depend on overwriting a fixed filename
**ELSE** leave the prior lineage unchanged rather than creating an empty checkpoint

## Do
- Combine sanitized project and workstream ids, zero-padded revision, UTC timestamp, and a short nonce in the filename.
- Include `packet_id`, `sequence`, `continued_from`, `created_at`, `created_by`, and `complete_snapshot: true` in frontmatter.
- Select the newest valid leaf in one lineage rather than the newest filename alone.
- Treat two successors of the same predecessor as a visible branch requiring selection or reconciliation.
- Write a new complete compaction snapshot when older files must be pruned.
- In mutable environments, allow a generated convenience pointer to identify the latest snapshot without becoming canonical.

## Don't
- Do not use Semantic Versioning for session revisions; protocol version and continuity sequence answer different questions.
- Do not assume a host-created `memory (1).md` is ordered, canonical, or discoverable.
- Do not silently merge two lineage branches.

## Checklist
- Is the filename collision-resistant without relying on host renaming?
- Can the snapshot resume work without loading its predecessor?
- Is the predecessor relationship explicit and unambiguous?

## Notes
Append-only snapshots work in writable repositories and project libraries that only add files. A mutable environment may generate `CURRENT.md`, but deleting that pointer must never destroy continuity.
