---
object_id: DRILL_state_protocol_compact_continuity_by_character_budget
object_type: drill
name: Compact Continuity by Character Budget
library_path:
- state-protocol
- core
stage_binding: 0 design
lane_fit: skill
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- compaction
- continuity
- character_budget
- local_model
cross_links:
- rel: teaches
  target_object_id: PAT_state_protocol_bound_continuity_to_next_action
- rel: teaches
  target_object_id: AP_state_protocol_checkpoint_continuity
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
target_skill: Produce a complete resumption packet inside a model-neutral character budget
variants: []
---

# Compact Continuity by Character Budget

## Practice Task
Turn a supplied 10,000-character session recap containing one active workstream, two completed side threads, four old decisions, one blocker, and an exact next action into a complete continuity snapshot no longer than 2,500 characters.

## Target Skill
Preserve the minimum sufficient resumption state while removing narrative and inactive detail under a tokenizer-independent limit.

## Setup
Prepare or obtain the recap described in the Practice Task and a character-counting tool.

## Instructions
1. Mark the active objective, accepted decisions, constraints, blocker, next action, canonical references, staged ids, and quarantined ids.
2. Produce a first complete snapshot with all required packet sections.
3. Record its exact character count.
4. Remove transcript narration, completed side threads, duplicate wording, and details not needed for the next action.
5. Produce the bounded snapshot and record its exact character count.
6. Submit the original marked inventory, first count, final packet, final count, and a list of removed material by category.

## Success Check
- The final count is 2,500 characters or fewer and was measured from the submitted packet rather than estimated.
- The objective, blocker, exact next action, binding constraints, and applicable accepted decisions remain present.
- The packet contains no completed side-thread narrative; retaining even one such recap is the named near-miss because it spends budget without changing resumption.
- Proposed and quarantined material appears only as identifiers in their separate sections.
- The removal list explains why each category was safe to omit.
- A reader using only the final packet can name the first action and the condition currently blocking or permitting it.

## Common Failures
- Replacing exact state with a shorter narrative whose authority and next action are ambiguous.
- Counting words or estimated tokens instead of the actual characters in the artifact.
- Dropping the next action while preserving background explanation.
- Moving old information to another packet section rather than removing it from the active overlay.

## Notes
This exercise directly practises Bound Continuity to the Next Action inside the checkpoint orchestration. The before-and-after counts make compaction observable instead of aspirational.

