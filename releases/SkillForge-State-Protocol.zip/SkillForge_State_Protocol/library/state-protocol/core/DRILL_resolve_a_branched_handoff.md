---
object_id: DRILL_state_protocol_resolve_a_branched_handoff
object_type: drill
name: Resolve a Branched Handoff
library_path:
- state-protocol
- core
stage_binding: 0 design
lane_fit: skill
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- lineage
- conflict
- handoff
- recovery
cross_links:
- rel: teaches
  target_object_id: PAT_state_protocol_write_immutable_complete_snapshots
- rel: teaches
  target_object_id: PAT_state_protocol_quarantine_conflicts_without_overwriting
- rel: teaches
  target_object_id: AP_state_protocol_resume_continuing_work
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
target_skill: Detect and reconcile two incompatible successors without silently merging their state
variants: []
---

# Resolve a Branched Handoff

## Practice Task
Given one predecessor snapshot and two complete successor snapshots that both name it in `continued_from` but disagree about the active objective, prepare a safe resumption disposition.

## Target Skill
Recognize lineage branching, preserve both histories, and produce an authorized recovery path rather than selecting by filename or fluency.

## Setup
Create three packet fixtures: revision 7 as the predecessor and two revision 8 successors with different packet ids, timestamps, objectives, and next actions.

## Instructions
1. Parse the three packet identities and draw the predecessor-to-successor relationships.
2. Record the two leaf ids and the conflicting objective and next-action fields.
3. Attempt the cheap strategy of choosing the newest timestamp and record why it is insufficient.
4. Produce a branch report that keeps both successors inactive pending authority.
5. Choose one resolution basis: explicit user selection, verified canonical project evidence, or an explicitly authorized reconciliation.
6. Produce the metadata and active-state sections of the resulting new complete snapshot, including its lineage choice.
7. Submit the relationship map, rejected cheap strategy, branch report, authority basis, and successor excerpt.

## Success Check
- The relationship map shows two successors from one predecessor rather than a linear revision chain.
- Both leaf ids and both conflicting fields are preserved in the branch report.
- The timestamp-only choice is rejected explicitly; merely selecting the later file is the named near-miss because recency cannot authorize a branch.
- The resolution cites a user act or checkable canonical evidence rather than model preference.
- The resulting excerpt is a complete successor basis and does not splice incompatible objective or next-action fields from both branches.

## Common Failures
- Sorting by filename and treating the last entry as canonical.
- Combining whichever field sounds better from each successor.
- Deleting the rejected branch before recording why it lost authority.
- Producing a delta that requires both conflicting packets to interpret.

## Notes
This exercise practises Write Immutable Complete Snapshots, Quarantine Conflicts Without Overwriting, and the branch recovery inside Resume Continuing Work. The deliberately attractive timestamp shortcut tests whether lineage is actually being used.

