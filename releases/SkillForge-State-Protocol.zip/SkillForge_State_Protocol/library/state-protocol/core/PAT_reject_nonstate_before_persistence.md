---
object_id: PAT_state_protocol_reject_nonstate_before_persistence
object_type: pattern
name: Reject Non-State Before Persistence
library_path:
- state-protocol
- core
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- continuity
- classification
- privacy
- compaction
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Reject Non-State Before Persistence

## Pattern Rule
**IF** conversation material is being considered for durable continuity
**THEN** retain only compact facts or commitments that can change later action, and reject transcript, reasoning, emotional texture, repetition, and unrelated side threads before classification
**ELSE** leave the material in the live session without creating a durable record

## Do
- Ask what future action would differ if the candidate were absent; no operational difference means no entry.
- Rewrite an accepted candidate as a self-contained objective, decision, constraint, blocker, next action, canonical reference, or deliberately scoped note.
- Preserve the smallest statement that remains meaningful without the conversation around it.
- Let discarded conversation remain discarded; a later explicit decision can create a fresh entry without preserving the discarded wording.

## Don't
- Do not treat discussion length, repetition, confidence, or emotional importance as evidence of durable state.
- Do not store hidden reasoning, intermediate explanation chains, or a narrative recap of the session.
- Do not capture a side question merely because it occurred while project work was open.

## Checklist
- Does every retained candidate change a plausible future action?
- Can each candidate be understood without replaying the transcript?
- Has personal or sensitive material been excluded unless its retention is deliberate and scoped?

## Notes
The cheapest continuity system is the one that refuses noise before it acquires a lifecycle. Compaction after indiscriminate capture still leaves the model judging a polluted archive; early rejection prevents that archive from forming.

