---
object_id: AP_state_protocol_resume_continuing_work
object_type: ap
name: Resume Continuing Work
library_path:
- state-protocol
- core
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- resume
- continuity
- lineage
- retrieval
cross_links:
- rel: supports
  target_object_id: PAT_state_protocol_scope_state_before_retrieval
- rel: supports
  target_object_id: PAT_state_protocol_resolve_authority_before_recency
- rel: supports
  target_object_id: PAT_state_protocol_quarantine_conflicts_without_overwriting
- rel: supports
  target_object_id: PAT_state_protocol_bound_continuity_to_next_action
- rel: supports
  target_object_id: PAT_state_protocol_write_immutable_complete_snapshots
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Resume Continuing Work

## Objective
Begin a new session with a bounded, authoritative working set whose project, workstream, lineage, conflicts, and exact next action are known.

## Steps / Flow
1. **Identify the scope.** Apply `PAT_state_protocol_scope_state_before_retrieval`. Stop rather than inspect unrelated projects when the intended workstream is unknown.
2. **Find valid lineage leaves.** Inspect packet metadata, not filenames alone. Apply `PAT_state_protocol_write_immutable_complete_snapshots` to reject malformed packets and identify successors that are not themselves predecessors.
3. **Resolve branching.** If two valid packets continue the same predecessor, do not merge them. Present the branch identity and require an authoritative selection or a new reconciled complete snapshot.
4. **Choose the working snapshot.** Use the highest-sequence unambiguous leaf. If predecessors are missing but the leaf declares a complete snapshot, report the lineage gap and continue only when the remaining packet validates.
5. **Overlay structured state when available.** Retrieve committed active entries for the same scope plus only the ids of proposed and quarantined entries. Apply `PAT_state_protocol_resolve_authority_before_recency` to any mismatch between packet and entries.
6. **Keep conflicts inactive.** Apply `PAT_state_protocol_quarantine_conflicts_without_overwriting` and surface only unresolved conflicts material to the next action.
7. **Bound the prompt.** Apply `PAT_state_protocol_bound_continuity_to_next_action`. Load user adaptation separately and only for skills actually activated by the current request.
8. **Verify resumption.** Proceed when the objective, binding constraints, blockers, and exact next action agree with the current request. Otherwise report the mismatch before acting.

## Notes
A complete snapshot permits recovery after older project-library files are pruned. Lineage still matters because two plausible leaves represent two histories, not extra context to blend.

