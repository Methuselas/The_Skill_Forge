---
object_id: PAT_state_protocol_stage_inference_before_commitment
object_type: pattern
name: Stage Inference Before Commitment
library_path:
- state-protocol
- core
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- authority
- proposal
- crawler
- commitment
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Stage Inference Before Commitment

## Pattern Rule
**IF** a model or crawler derives a durable candidate from conversation, files, or search results
**THEN** record it as proposed until an explicit user act or checkable tool result supplies the authority required by its record type
**ELSE** preserve the entry's existing status without manufacturing a promotion event

## Do
- Treat a clear user adoption or correction as authoritative even when it lacks a prescribed magic phrase.
- Allow verified tools to commit factual project observations only when the canonical result is named in `source_ref`.
- Keep an ambiguous statement proposed without forcing the user through bookkeeping for an immaterial candidate.
- Record discovery origin separately from commitment authority.

## Don't
- Do not infer commitment from repetition, recency, confidence, file placement, or crawler ranking.
- Do not let the component that extracted an entry authorize it solely because the source sounded decisive.
- Do not allow tool authority to commit a personal preference on the user's behalf.

## Checklist
- Is commitment authority independent of candidate discovery?
- Does every committed entry name an authority allowed for its record type?
- Would ambiguous intent remain reversible?

## Notes
Literal promotion verbs are optional; an authoritative act is not. This preserves natural conversation while keeping extraction, interpretation, and authorization as distinct operations.

