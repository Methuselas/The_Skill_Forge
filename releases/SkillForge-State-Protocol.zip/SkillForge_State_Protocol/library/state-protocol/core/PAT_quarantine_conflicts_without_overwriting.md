---
object_id: PAT_state_protocol_quarantine_conflicts_without_overwriting
object_type: pattern
name: Quarantine Conflicts Without Overwriting
library_path:
- state-protocol
- core
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- contradiction
- quarantine
- recovery
- state
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Quarantine Conflicts Without Overwriting

## Pattern Rule
**IF** two applicable claims cannot both guide execution and authority does not already settle the difference
**THEN** preserve the accepted claim, quarantine the candidate with explicit conflict identifiers, and require authorized supersession before replacement
**ELSE** retain both claims in their honest non-conflicting scopes and statuses

## Do
- Preserve both claims and name the exact entry ids in `conflicts_with`.
- Set quarantined entries to `load_policy: never` so they remain searchable without entering active context.
- Resolve replacement by committing the authorized successor and explicitly superseding every displaced active entry.
- Keep discard reversible when investigation proves a candidate wrong.

## Don't
- Do not overwrite or delete an accepted file to make a disagreement disappear.
- Do not invent a story that makes incompatible statements appear compatible.
- Do not return quarantined bodies in an ordinary active-state overlay.

## Checklist
- Are both versions preserved with resolvable identifiers?
- Is the unresolved candidate excluded from active loading?
- Does any replacement carry sufficient authority and explicit supersession?

## Notes
Quarantine is a lifecycle status rather than a new information pool. That keeps the kind and scope of the claim intact while preventing unresolved material from steering execution.

