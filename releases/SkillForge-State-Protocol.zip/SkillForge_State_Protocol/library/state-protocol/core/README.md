# State Protocol Core

State Protocol keeps durable continuity in small, explicit artifacts. It does not
store transcripts and does not claim persistence a host cannot provide.

## Portable Manual profile

Use this profile when Python or a writable local filesystem is unavailable, such
as an ordinary project-library chat environment.

1. Treat quick questions and unchanged sessions as ephemeral; write no packet.
2. At a meaningful boundary, create one uniquely named Markdown file.
3. Make it a complete snapshot rather than a delta.
4. On resume, select the newest unambiguous lineage leaf, not the filename that
   happens to sort last.
5. If two snapshots continue the same predecessor, ask for an authoritative
   selection or create an explicitly reconciled successor.

Suggested filename:

```text
SP__<project>__<workstream>__r000042__20260912T214500Z__7c2a.md
```

Packet frontmatter:

```yaml
---
schema_version: 1
protocol_version: 1.0.0
record_type: continuity_packet
packet_id: sp:<project>:<workstream>:r000042:7c2a
project_id: <project>
workstream_id: <workstream>
sequence: 42
continued_from: sp:<project>:<workstream>:r000041:19bf
created_by: <model-or-host-id>
created_at: 2026-09-12T21:45:00Z
complete_snapshot: true
max_chars: 8000
---
```

The body contains these H2 sections exactly once and in this order:

```markdown
# Continuity Packet

## Active state
## Blockers
## Next action
## Constraints
## Canonical refs
## Quarantined
## Staged
```

Use a smaller `max_chars` for constrained models. The declared limit measures the
packet body as characters; tokenizer-specific counts are advisory only.

## State boundaries

- Project continuity says what this workstream is doing.
- User skill memory says how one local user wants an activated skill applied.
- PASS Skillset Memory records evidence about a skill's tested capability.

Those are different stores. A packet may list project entry identifiers, but it
never embeds user skill memory or PASS memory.

