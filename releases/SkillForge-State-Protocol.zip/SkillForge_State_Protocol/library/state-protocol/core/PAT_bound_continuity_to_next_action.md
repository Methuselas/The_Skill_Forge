---
object_id: PAT_state_protocol_bound_continuity_to_next_action
object_type: pattern
name: Bound Continuity to the Next Action
library_path:
- state-protocol
- core
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- compaction
- local_model
- context
- retrieval
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Bound Continuity to the Next Action

## Pattern Rule
**IF** a continuity packet or prompt overlay is being prepared for resumed work
**THEN** include only committed active state needed to identify or perform the next action, and retrieve other valid detail on demand
**ELSE** leave archival material searchable but unloaded

## Do
- Preserve the objective, exact next action, blockers, binding constraints, current decisions, and canonical references.
- Move older still-valid details to `on_demand` rather than replaying them automatically.
- List proposed and quarantined entry ids separately without loading their bodies.
- Measure portable limits in characters; offer tokenizer-specific estimates only as advisory information.
- Fail visibly when essential state exceeds the declared budget.

## Don't
- Do not fill available context merely because the host can hold it.
- Do not include transcripts, deliberation, completed side threads, or duplicate descriptions.
- Do not silently truncate the objective, blockers, next action, or binding constraints.

## Checklist
- Can a fresh session identify and perform the next action from the packet?
- Is every loaded entry committed, active, relevant, and appropriate for disclosure?
- Is the packet inside its declared character budget without losing essential state?

## Notes
Character limits behave consistently across tokenizers and model families. A packet is a working set, not an archive; its purpose is to reduce prompt load while keeping resumption exact.

