---
object_id: PAT_state_protocol_scope_state_before_retrieval
object_type: pattern
name: Scope State Before Retrieval
library_path:
- state-protocol
- core
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- isolation
- project
- workstream
- retrieval
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Scope State Before Retrieval

## Pattern Rule
**IF** continuity state is about to be searched, loaded, compared, or changed
**THEN** resolve the exact store, project, and workstream first and constrain the operation to that scope
**ELSE** stop rather than search every available scope and choose a plausible result

## Do
- Obtain `project_id` and `workstream_id` from the active project configuration, an explicit user choice, or a verified workspace adapter.
- Treat `main` as a declared single-workstream identifier, not as permission to omit workstream identity.
- Keep creator identity separate from scope so another model can continue the same workstream without creating a second history.
- Require packet references, conflicts, supersession, and active-role checks to remain inside one project and workstream.

## Don't
- Do not infer a project from whichever search result ranks highest.
- Do not use model name, session id, or chat title as a substitute for work ownership.
- Do not combine similarly named workstreams or projects during resume.

## Checklist
- Are the store, project id, and workstream id known before retrieval begins?
- Does every returned project entry belong to that exact scope?
- Could changing `created_by` leave the workstream identity unchanged?

## Notes
Retrieval filters are an isolation boundary, not an optimization. A highly relevant result from the wrong project is contamination, while a workstream can legitimately pass between models without changing its subject or history.

