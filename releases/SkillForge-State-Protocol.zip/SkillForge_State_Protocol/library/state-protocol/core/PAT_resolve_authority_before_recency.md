---
object_id: PAT_state_protocol_resolve_authority_before_recency
object_type: pattern
name: Resolve Authority Before Recency
library_path:
- state-protocol
- core
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- precedence
- authority
- evidence
- recency
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Resolve Authority Before Recency

## Pattern Rule
**IF** a new claim differs from stored state
**THEN** compare scope, record type, authority, and evidence before timestamp, using recency only between compatible claims of equal authority
**ELSE** use the compatible stored state normally

## Do
- Let an explicit current user correction replace an earlier user decision in the same scope.
- Let a newer verified observation replace an older factual observation when both identify checkable evidence.
- Treat an ambiguous live claim as a proposal even when it is newer than committed state.
- Apply current task requirements before stored user preferences, then apply narrower stored scope before broader scope.

## Don't
- Do not make live context win merely because it is live.
- Do not let a personal preference overwrite a project fact or constraint.
- Do not bridge incompatible claims with an invented sequence of events.

## Checklist
- Are the competing claims about the same subject in the same applicable scope?
- Which claim has explicit authority or stronger checkable evidence?
- Was recency used only after compatibility and authority were settled?

## Notes
Freshness is valuable among comparable observations and dangerous as a universal precedence rule. Separating the dimensions prevents an uncertain recent guess from defeating a deliberate decision.

