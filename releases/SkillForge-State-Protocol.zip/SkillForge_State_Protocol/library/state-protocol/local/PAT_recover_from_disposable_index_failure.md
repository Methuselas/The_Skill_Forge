---
object_id: PAT_state_protocol_recover_from_disposable_index_failure
object_type: pattern
name: Recover From Disposable Index Failure
library_path:
- state-protocol
- local
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: specialized
specialization_axis: tool
foundation_object_id: none
tags:
- sqlite
- recovery
- crawler
- markdown
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Recover From Disposable Index Failure

## Pattern Rule
**IF** a generated search index is missing, corrupt, stale, or unavailable on the local Python build
**THEN** reject the index, read validated canonical Markdown directly, serve a bounded result, and attempt an atomic rebuild without blocking continued read-only use
**ELSE** use the verified index only as a search accelerator

## Do
- Run an integrity and source-fingerprint check before trusting indexed results.
- Fall back to exact-scope file traversal and preserve the same privacy filters used by indexed search.
- Build a replacement beside the old database, verify it, then atomically replace the generated file.
- Keep the last readable index intact when a rebuild fails.
- Report direct mode and the rebuild result so degraded operation is visible.

## Don't
- Do not repair canonical Markdown from values recovered only from SQLite.
- Do not delete or replace the previous index before the candidate database passes verification.
- Do not widen a search to other projects or users because the intended scope lacks an index.

## Checklist
- Can the requested bounded state be returned from Markdown with the index deleted?
- Does a failed rebuild leave canonical files and the previous database unchanged?
- Are direct and indexed queries governed by identical scope and disclosure filters?

## Notes
The index is a cache whose failure belongs at the retrieval layer. A session may continue from valid files while search performance is degraded; malformed canonical state remains a separate blocking failure.

