---
object_id: AP_state_protocol_operate_a_local_continuity_store
object_type: ap
name: Operate a Local Continuity Store
library_path:
- state-protocol
- local
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: specialized
specialization_axis: tool
foundation_object_id: none
tags:
- local_model
- crawler
- sqlite
- lifecycle
cross_links:
- rel: supports
  target_object_id: PAT_state_protocol_scope_state_before_retrieval
- rel: supports
  target_object_id: PAT_state_protocol_recover_from_disposable_index_failure
- rel: supports
  target_object_id: AP_state_protocol_capture_scoped_state
- rel: supports
  target_object_id: AP_state_protocol_checkpoint_continuity
- rel: supports
  target_object_id: AP_state_protocol_resume_continuing_work
- rel: supports
  target_object_id: AP_state_protocol_capture_and_apply_user_adaptation
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Operate a Local Continuity Store

## Objective
Initialize and use a user-controlled local store so a model can capture, search, checkpoint, and resume bounded continuity without requiring a transcript or trusting generated navigation as state.

## Steps / Flow
1. **Initialize an explicit root.** Create the store sentinel, one named project/workstream, and optional local user/skill scopes. Refuse a directory that contains unrelated files but lacks the sentinel.
2. **Declare lifecycle integration.** Configure the host or model to call the shipped `state_protocol.py` interface when hooks exist. Where hooks do not exist, use explicit skill activation and write-through capture after material changes rather than relying only on session end.
3. **Resume exact scope.** Apply `PAT_state_protocol_scope_state_before_retrieval`, then delegate semantic resumption to `AP_state_protocol_resume_continuing_work`.
4. **Handle index degradation.** Apply `PAT_state_protocol_recover_from_disposable_index_failure`. Direct Markdown reads are the fallback; cross-scope search is not.
5. **Capture project change.** Delegate durable project candidates to `AP_state_protocol_capture_scoped_state`; an index rebuild never promotes them.
6. **Capture user adaptation separately.** Delegate explicit preferences or consented skill accommodations to `AP_state_protocol_capture_and_apply_user_adaptation`. Never place them in a project packet or PASS `memory/` directory.
7. **Checkpoint at material boundaries.** Delegate packet creation to `AP_state_protocol_checkpoint_continuity`, validate, rebuild generated navigation, and perform a readback resume.
8. **Complete the cycle.** The store is operational when deletion or corruption of every SQLite file still permits exact-scope resume from Markdown and the tool test suite passes without third-party packages.

## Notes
The shipped interface exposes `initialize`, `resume`, `search`, `propose`, `commit`, `checkpoint`, `crawl`, and `validate`. These verbs are a host adapter contract; only the model and user can supply semantic judgment and authority.
