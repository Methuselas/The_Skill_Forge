#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""State Protocol storage, validation, retrieval, and checkpoint primitives."""

from __future__ import annotations

from collections import Counter, defaultdict
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import tempfile
from typing import Any, Iterable, Iterator


PROTOCOL_VERSION = "1.0.0"
SCHEMA_VERSION = 1
SENTINEL = "STATE_PROTOCOL_STORE.md"
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
ENTRY_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
ENTRY_REF_RE = re.compile(r"\[entry:([A-Za-z0-9._:-]+)\]")
WINDOWS_RESERVED_NAMES = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{number}" for number in range(1, 10)),
    *(f"LPT{number}" for number in range(1, 10)),
}

PROJECT_KINDS = {
    "objective",
    "decision",
    "constraint",
    "blocker",
    "next_action",
    "canonical_ref",
    "note",
}
USER_KINDS = {"preference", "accommodation", "convention", "observed_tendency"}
STATUSES = {"proposed", "committed", "quarantined", "superseded", "discarded"}
AUTHORITIES = {"model", "user", "verified_tool"}
LOAD_POLICIES = {"active", "on_demand", "never"}
SENSITIVITIES = {"normal", "private"}
USER_SCOPE_LEVELS = {"user", "skill", "project", "workstream"}
PACKET_HEADINGS = (
    "Active state",
    "Blockers",
    "Next action",
    "Constraints",
    "Canonical refs",
    "Quarantined",
    "Staged",
)

PROJECT_REQUIRED = {
    "schema_version",
    "protocol_version",
    "record_type",
    "entry_id",
    "title",
    "project_id",
    "workstream_id",
    "created_by",
    "kind",
    "status",
    "authority",
    "load_policy",
    "sensitivity",
    "created_at",
    "updated_at",
    "source_ref",
}
USER_REQUIRED = {
    "schema_version",
    "protocol_version",
    "record_type",
    "entry_id",
    "title",
    "user_id",
    "skill_id",
    "created_by",
    "kind",
    "scope_level",
    "project_id",
    "workstream_id",
    "applies_to",
    "status",
    "authority",
    "load_policy",
    "sensitivity",
    "evidence_count",
    "review_after",
    "created_at",
    "updated_at",
    "source_ref",
}
PACKET_REQUIRED = {
    "schema_version",
    "protocol_version",
    "record_type",
    "packet_id",
    "project_id",
    "workstream_id",
    "sequence",
    "continued_from",
    "created_by",
    "created_at",
    "complete_snapshot",
    "max_chars",
}


class ProtocolError(ValueError):
    """Raised when a State Protocol operation cannot safely continue."""


class IndexUnavailable(ProtocolError):
    """Raised when generated navigation cannot be trusted."""


@dataclass(frozen=True)
class Document:
    path: Path
    record_type: str
    metadata: dict[str, Any]
    body: str
    sha256: str

    @property
    def identity(self) -> str:
        return str(self.metadata.get("entry_id") or self.metadata.get("packet_id") or self.path.name)


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def valid_datetime(value: Any) -> bool:
    if not isinstance(value, str) or not value:
        return False
    candidate = value[:-1] + "+00:00" if value.endswith("Z") else value
    try:
        datetime.fromisoformat(candidate)
    except ValueError:
        return False
    return True


def portable_id(value: str) -> bool:
    return bool(
        ID_RE.fullmatch(value)
        and not value.endswith(".")
        and value.split(".", 1)[0].upper() not in WINDOWS_RESERVED_NAMES
    )


def require_id(value: str, label: str, *, packet: bool = False) -> str:
    valid = bool(ENTRY_ID_RE.fullmatch(value)) if packet else portable_id(value)
    if not valid:
        raise ProtocolError(f"invalid {label}: {value!r}")
    return value


def slug(value: str) -> str:
    result = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return result[:48] or "entry"


def comma_list(value: Any) -> list[str]:
    if value in (None, ""):
        return []
    if not isinstance(value, str):
        raise ProtocolError("list frontmatter values must be comma-separated strings")
    return [item.strip() for item in value.split(",") if item.strip()]


def parse_scalar(raw: str, path: Path, line_number: int) -> Any:
    value = raw.strip()
    if value == "":
        return ""
    if value.startswith('"'):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ProtocolError(f"{path}:{line_number}: invalid JSON-quoted value") from exc
        if not isinstance(parsed, str):
            raise ProtocolError(f"{path}:{line_number}: quoted value must be a string")
        return parsed
    if value.startswith("'"):
        raise ProtocolError(f"{path}:{line_number}: quoted values must use JSON double quotes")
    if value in {"true", "false"}:
        return value == "true"
    if re.fullmatch(r"0|[1-9][0-9]*", value):
        return int(value)
    return value


def parse_markdown(path: Path) -> Document:
    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ProtocolError(f"{path}: expected UTF-8 Markdown") from exc
    lines = text.splitlines()
    if not lines or lines[0] != "---":
        raise ProtocolError(f"{path}: frontmatter must begin at byte 0")
    try:
        end = lines.index("---", 1)
    except ValueError as exc:
        raise ProtocolError(f"{path}: unterminated frontmatter") from exc
    metadata: dict[str, Any] = {}
    for line_number, line in enumerate(lines[1:end], start=2):
        if not line:
            continue
        if line[:1].isspace() or ":" not in line:
            raise ProtocolError(f"{path}:{line_number}: frontmatter must be flat key/value data")
        key, raw = line.split(":", 1)
        if not re.fullmatch(r"[a-z][a-z0-9_]*", key):
            raise ProtocolError(f"{path}:{line_number}: invalid key {key!r}")
        if key in metadata:
            raise ProtocolError(f"{path}:{line_number}: duplicate key {key!r}")
        metadata[key] = parse_scalar(raw, path, line_number)
    body = "\n".join(lines[end + 1 :]).strip()
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return Document(path, str(metadata.get("record_type") or ""), metadata, body, digest)


def render_scalar(value: Any) -> str:
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    text = str(value)
    if not text:
        return ""
    return json.dumps(text, ensure_ascii=False)


def render_markdown(metadata: dict[str, Any], body: str) -> str:
    front = "\n".join(f"{key}: {render_scalar(value)}" for key, value in metadata.items())
    return f"---\n{front}\n---\n\n{body.rstrip()}\n"


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        if temporary.read_text(encoding="utf-8") != text:
            raise ProtocolError(f"write readback failed for {path}")
        os.replace(temporary, path)
        if path.read_text(encoding="utf-8") != text:
            raise ProtocolError(f"replacement readback failed for {path}")
    finally:
        if temporary.exists():
            temporary.unlink()


def sentinel_path(store: Path) -> Path:
    return store.resolve() / SENTINEL


def ensure_store(store: Path) -> Path:
    root = store.resolve()
    sentinel = sentinel_path(root)
    if not sentinel.is_file():
        raise ProtocolError(f"not a State Protocol store: {root}; missing {SENTINEL}")
    document = parse_markdown(sentinel)
    if document.record_type != "state_protocol_store":
        raise ProtocolError(f"invalid store sentinel: {sentinel}")
    if document.metadata.get("schema_version") != SCHEMA_VERSION:
        raise ProtocolError(f"unsupported store schema in {sentinel}")
    if not str(document.metadata.get("protocol_version") or "").startswith("1."):
        raise ProtocolError(f"unsupported protocol version in {sentinel}")
    return root


def project_scope(store: Path, project_id: str, workstream_id: str) -> Path:
    require_id(project_id, "project_id")
    require_id(workstream_id, "workstream_id")
    return store / "projects" / project_id / "workstreams" / workstream_id


def user_scope(store: Path, user_id: str, skill_id: str) -> Path:
    require_id(user_id, "user_id")
    require_id(skill_id, "skill_id")
    return store / "users" / user_id / "skills" / skill_id


def initialize_store(
    store: Path,
    project_id: str,
    workstream_id: str,
    created_by: str,
    user_id: str = "",
    skill_ids: Iterable[str] = (),
) -> dict[str, Any]:
    require_id(project_id, "project_id")
    require_id(workstream_id, "workstream_id")
    require_id(created_by, "created_by")
    root = store.resolve()
    sentinel = sentinel_path(root)
    if root.exists() and not sentinel.exists() and any(root.iterdir()):
        raise ProtocolError(f"refusing non-empty directory without {SENTINEL}: {root}")
    root.mkdir(parents=True, exist_ok=True)
    if not sentinel.exists():
        created_at = utc_now()
        metadata = {
            "schema_version": SCHEMA_VERSION,
            "protocol_version": PROTOCOL_VERSION,
            "record_type": "state_protocol_store",
            "store_id": f"store-{secrets.token_hex(4)}",
            "created_by": created_by,
            "created_at": created_at,
        }
        atomic_write(sentinel, render_markdown(metadata, "# State Protocol Store\n\nMarkdown is canonical. Generated indexes are disposable."))
    ensure_store(root)
    scope = project_scope(root, project_id, workstream_id)
    (scope / "state").mkdir(parents=True, exist_ok=True)
    (scope / "continuity").mkdir(parents=True, exist_ok=True)
    initialized_skills: list[str] = []
    if user_id:
        require_id(user_id, "user_id")
        for skill_id in skill_ids:
            target = user_scope(root, user_id, skill_id)
            (target / "state").mkdir(parents=True, exist_ok=True)
            initialized_skills.append(skill_id)
    return {
        "store": str(root),
        "project_id": project_id,
        "workstream_id": workstream_id,
        "user_id": user_id,
        "skills": initialized_skills,
    }


def iter_documents(scope: Path) -> Iterator[Document]:
    for folder in (scope / "state", scope / "continuity"):
        if not folder.is_dir():
            continue
        for path in sorted(folder.glob("*.md")):
            yield parse_markdown(path)


def all_scopes(store: Path) -> Iterator[tuple[str, Path, dict[str, str]]]:
    root = ensure_store(store)
    for path in sorted((root / "projects").glob("*/workstreams/*")) if (root / "projects").is_dir() else []:
        if path.is_dir():
            yield "project", path, {"project_id": path.parents[1].name, "workstream_id": path.name}
    for path in sorted((root / "users").glob("*/skills/*")) if (root / "users").is_dir() else []:
        if path.is_dir():
            yield "user", path, {"user_id": path.parents[1].name, "skill_id": path.name}


@contextmanager
def scope_lock(scope: Path, owner: str, operation: str) -> Iterator[None]:
    require_id(owner, "lock owner")
    lock = scope / ".write.lock"
    payload = json.dumps({"owner": owner, "operation": operation, "created_at": utc_now()}, indent=2) + "\n"
    try:
        descriptor = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as exc:
        detail = lock.read_text(encoding="utf-8", errors="replace") if lock.is_file() else "unreadable"
        raise ProtocolError(f"scope is locked: {lock}; {detail.strip()}") from exc
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        yield
    finally:
        if lock.exists():
            lock.unlink()


workstream_lock = scope_lock


def generated_entry_id(kind: str, title: str) -> str:
    return f"{slug(kind)}-{slug(title)}-{secrets.token_hex(3)}"


def propose_project_entry(
    store: Path,
    project_id: str,
    workstream_id: str,
    kind: str,
    title: str,
    text: str,
    created_by: str,
    source_ref: str,
    *,
    entry_id: str = "",
    load_policy: str = "active",
    sensitivity: str = "normal",
    conflicts_with: Iterable[str] = (),
) -> Document:
    root = ensure_store(store)
    scope = project_scope(root, project_id, workstream_id)
    if not scope.is_dir():
        raise ProtocolError(f"project workstream is not initialized: {scope}")
    if kind not in PROJECT_KINDS:
        raise ProtocolError(f"invalid project kind: {kind}")
    if not title.strip() or not text.strip() or not source_ref.strip():
        raise ProtocolError("title, text, and source_ref must be non-empty")
    if load_policy not in LOAD_POLICIES or sensitivity not in SENSITIVITIES:
        raise ProtocolError("invalid load policy or sensitivity")
    require_id(created_by, "created_by")
    identity = require_id(entry_id or generated_entry_id(kind, title), "entry_id")
    conflicts = [require_id(item, "conflict entry_id") for item in conflicts_with]
    status = "quarantined" if conflicts else "proposed"
    if conflicts:
        load_policy = "never"
    now = utc_now()
    metadata = {
        "schema_version": SCHEMA_VERSION,
        "protocol_version": PROTOCOL_VERSION,
        "record_type": "project_state",
        "entry_id": identity,
        "title": title,
        "project_id": project_id,
        "workstream_id": workstream_id,
        "created_by": created_by,
        "kind": kind,
        "status": status,
        "authority": "model",
        "load_policy": load_policy,
        "sensitivity": sensitivity,
        "created_at": now,
        "updated_at": now,
        "source_ref": source_ref,
        "conflicts_with": ",".join(conflicts),
        "superseded_by": "",
    }
    target = scope / "state" / f"{identity}.md"
    with scope_lock(scope, created_by, "propose"):
        if target.exists():
            raise ProtocolError(f"entry already exists: {identity}")
        for conflict_id in conflicts:
            conflict = find_entry(scope, conflict_id)
            if conflict.record_type != "project_state":
                raise ProtocolError(f"project conflict references another record type: {conflict_id}")
        atomic_write(target, render_markdown(metadata, text))
    return parse_markdown(target)


def propose_user_entry(
    store: Path,
    user_id: str,
    skill_id: str,
    kind: str,
    title: str,
    text: str,
    created_by: str,
    source_ref: str,
    *,
    entry_id: str = "",
    scope_level: str = "skill",
    project_id: str = "",
    workstream_id: str = "",
    applies_to: str = "any_model",
    load_policy: str = "active",
    sensitivity: str = "private",
    evidence_count: int = 1,
    review_after: str = "",
    conflicts_with: Iterable[str] = (),
) -> Document:
    root = ensure_store(store)
    scope = user_scope(root, user_id, skill_id)
    (scope / "state").mkdir(parents=True, exist_ok=True)
    if kind not in USER_KINDS or scope_level not in USER_SCOPE_LEVELS:
        raise ProtocolError("invalid user-memory kind or scope level")
    if not title.strip() or not text.strip() or not source_ref.strip():
        raise ProtocolError("title, text, and source_ref must be non-empty")
    if scope_level in {"project", "workstream"} and not project_id:
        raise ProtocolError(f"scope_level {scope_level} requires project_id")
    if scope_level == "workstream" and not workstream_id:
        raise ProtocolError("scope_level workstream requires workstream_id")
    if project_id:
        require_id(project_id, "project_id")
    if workstream_id:
        require_id(workstream_id, "workstream_id")
    if load_policy not in LOAD_POLICIES or sensitivity not in SENSITIVITIES:
        raise ProtocolError("invalid load policy or sensitivity")
    if evidence_count < 1:
        raise ProtocolError("evidence_count must be positive")
    if review_after and not valid_datetime(review_after):
        raise ProtocolError("review_after must be an ISO-8601 timestamp")
    require_id(created_by, "created_by")
    require_id(applies_to, "applies_to")
    identity = require_id(entry_id or generated_entry_id(kind, title), "entry_id")
    conflicts = [require_id(item, "conflict entry_id") for item in conflicts_with]
    status = "quarantined" if conflicts else "proposed"
    if conflicts:
        load_policy = "never"
    now = utc_now()
    metadata = {
        "schema_version": SCHEMA_VERSION,
        "protocol_version": PROTOCOL_VERSION,
        "record_type": "user_skill_memory",
        "entry_id": identity,
        "title": title,
        "user_id": user_id,
        "skill_id": skill_id,
        "created_by": created_by,
        "kind": kind,
        "scope_level": scope_level,
        "project_id": project_id,
        "workstream_id": workstream_id,
        "applies_to": applies_to,
        "status": status,
        "authority": "model",
        "load_policy": load_policy,
        "sensitivity": sensitivity,
        "evidence_count": evidence_count,
        "review_after": review_after,
        "created_at": now,
        "updated_at": now,
        "source_ref": source_ref,
        "conflicts_with": ",".join(conflicts),
        "superseded_by": "",
    }
    target = scope / "state" / f"{identity}.md"
    with scope_lock(scope, created_by, "propose-user-memory"):
        if target.exists():
            raise ProtocolError(f"entry already exists: {identity}")
        for conflict_id in conflicts:
            conflict = find_entry(scope, conflict_id)
            if conflict.record_type != "user_skill_memory":
                raise ProtocolError(f"user conflict references another record type: {conflict_id}")
        atomic_write(target, render_markdown(metadata, text))
    return parse_markdown(target)


def find_entry(scope: Path, entry_id: str) -> Document:
    require_id(entry_id, "entry_id")
    target = scope / "state" / f"{entry_id}.md"
    if not target.is_file():
        raise ProtocolError(f"entry not found: {entry_id}")
    return parse_markdown(target)


def commit_entry(
    scope: Path,
    entry_id: str,
    authority: str,
    source_ref: str,
    actor: str,
    supersedes: Iterable[str] = (),
) -> Document:
    if authority not in {"user", "verified_tool"}:
        raise ProtocolError("commit authority must be user or verified_tool")
    if not source_ref.strip():
        raise ProtocolError("commit source_ref must be non-empty")
    require_id(actor, "actor")
    with scope_lock(scope, actor, "commit"):
        document = find_entry(scope, entry_id)
        if document.record_type == "user_skill_memory" and authority != "user":
            raise ProtocolError("only user authority may commit user skill memory")
        if document.record_type not in {"project_state", "user_skill_memory"}:
            raise ProtocolError("only state entries can be committed")
        metadata = dict(document.metadata)
        if metadata.get("status") not in {"proposed", "quarantined"}:
            raise ProtocolError(f"entry is not commit-ready: {metadata.get('status')}")
        conflict_ids = set(comma_list(metadata.get("conflicts_with")))
        replacement_ids = {require_id(value, "superseded entry_id") for value in supersedes}
        if conflict_ids and conflict_ids != replacement_ids:
            raise ProtocolError("committing a quarantined entry requires superseding every conflict id")
        if (
            document.record_type == "project_state"
            and metadata.get("kind") in {"objective", "next_action"}
            and metadata.get("load_policy") == "active"
        ):
            competing = {
                candidate.identity
                for candidate in iter_documents(scope)
                if candidate.record_type == "project_state"
                and candidate.identity != entry_id
                and candidate.metadata.get("kind") == metadata.get("kind")
                and candidate.metadata.get("status") == "committed"
                and candidate.metadata.get("load_policy") == "active"
            }
            if competing != replacement_ids:
                names = ", ".join(sorted(competing)) or "none"
                raise ProtocolError(
                    f"committing active {metadata.get('kind')} requires superseding exactly: {names}"
                )
        now = utc_now()
        for old_id in sorted(replacement_ids):
            old = find_entry(scope, old_id)
            if old.record_type != document.record_type:
                raise ProtocolError(f"cannot supersede a different record type: {old_id}")
            old_meta = dict(old.metadata)
            if old_meta.get("status") != "committed":
                raise ProtocolError(f"superseded entry must be committed: {old_id}")
            old_meta["status"] = "superseded"
            old_meta["load_policy"] = "never"
            old_meta["superseded_by"] = entry_id
            old_meta["updated_at"] = now
            atomic_write(old.path, render_markdown(old_meta, old.body))
        metadata["status"] = "committed"
        metadata["authority"] = authority
        metadata["source_ref"] = source_ref
        metadata["updated_at"] = now
        metadata["conflicts_with"] = ""
        atomic_write(document.path, render_markdown(metadata, document.body))
    return parse_markdown(document.path)


def packet_entry_refs(body: str) -> list[str]:
    return ENTRY_REF_RE.findall(body)


def validate_scope(scope_type: str, scope: Path, identity: dict[str, str]) -> list[str]:
    problems: list[str] = []
    for key, value in identity.items():
        if not portable_id(value):
            problems.append(f"{scope}: invalid {key} directory {value!r}")
    try:
        documents = list(iter_documents(scope))
    except ProtocolError as exc:
        return [str(exc)]
    entries: dict[str, Document] = {}
    packets: dict[str, Document] = {}
    active_roles: defaultdict[str, list[str]] = defaultdict(list)
    for document in documents:
        metadata = document.metadata
        where = str(document.path)
        if document.record_type in {"project_state", "user_skill_memory"}:
            required = PROJECT_REQUIRED if document.record_type == "project_state" else USER_REQUIRED
            missing = sorted(required - metadata.keys())
            if missing:
                problems.append(f"{where}: missing fields: {', '.join(missing)}")
                continue
            entry_id = str(metadata["entry_id"])
            if not portable_id(entry_id):
                problems.append(f"{where}: invalid entry_id {entry_id!r}")
            if entry_id in entries:
                problems.append(f"{where}: duplicate entry_id {entry_id}")
            entries[entry_id] = document
            if metadata.get("schema_version") != SCHEMA_VERSION:
                problems.append(f"{where}: schema_version must be {SCHEMA_VERSION}")
            if not str(metadata.get("protocol_version") or "").startswith("1."):
                problems.append(f"{where}: unsupported protocol_version")
            if not str(metadata.get("title") or "").strip() or not str(metadata.get("source_ref") or "").strip():
                problems.append(f"{where}: title and source_ref must be non-empty")
            if not portable_id(str(metadata.get("created_by") or "")):
                problems.append(f"{where}: invalid created_by")
            for key, allowed in (
                ("status", STATUSES),
                ("authority", AUTHORITIES),
                ("load_policy", LOAD_POLICIES),
                ("sensitivity", SENSITIVITIES),
            ):
                if metadata.get(key) not in allowed:
                    problems.append(f"{where}: invalid {key} {metadata.get(key)!r}")
            for key in ("created_at", "updated_at"):
                if not valid_datetime(metadata.get(key)):
                    problems.append(f"{where}: {key} must be ISO-8601")
            if metadata.get("status") == "committed" and metadata.get("authority") not in {"user", "verified_tool"}:
                problems.append(f"{where}: committed entry has invalid authority")
            if metadata.get("status") in {"quarantined", "superseded", "discarded"} and metadata.get("load_policy") != "never":
                problems.append(f"{where}: inactive status requires load_policy never")
            if metadata.get("status") == "quarantined" and not comma_list(metadata.get("conflicts_with")):
                problems.append(f"{where}: quarantined entry requires conflicts_with")
            if metadata.get("status") == "superseded" and not metadata.get("superseded_by"):
                problems.append(f"{where}: superseded entry requires superseded_by")
            if document.record_type == "project_state":
                if scope_type != "project":
                    problems.append(f"{where}: project entry is outside a project scope")
                if metadata.get("project_id") != identity.get("project_id") or metadata.get("workstream_id") != identity.get("workstream_id"):
                    problems.append(f"{where}: entry identity does not match directory scope")
                if metadata.get("kind") not in PROJECT_KINDS:
                    problems.append(f"{where}: invalid project kind")
                if metadata.get("status") == "committed" and metadata.get("load_policy") == "active" and metadata.get("kind") in {"objective", "next_action"}:
                    active_roles[str(metadata["kind"])].append(entry_id)
            else:
                if scope_type != "user":
                    problems.append(f"{where}: user entry is outside a user skill scope")
                if metadata.get("user_id") != identity.get("user_id") or metadata.get("skill_id") != identity.get("skill_id"):
                    problems.append(f"{where}: user or skill identity does not match directory scope")
                if metadata.get("kind") not in USER_KINDS or metadata.get("scope_level") not in USER_SCOPE_LEVELS:
                    problems.append(f"{where}: invalid user kind or scope_level")
                if not portable_id(str(metadata.get("applies_to") or "")):
                    problems.append(f"{where}: invalid applies_to")
                if metadata.get("status") == "committed" and metadata.get("authority") != "user":
                    problems.append(f"{where}: committed user skill memory requires user authority")
                if not isinstance(metadata.get("evidence_count"), int) or metadata["evidence_count"] < 1:
                    problems.append(f"{where}: evidence_count must be positive")
                if metadata.get("review_after") and not valid_datetime(metadata["review_after"]):
                    problems.append(f"{where}: review_after must be ISO-8601")
                level = metadata.get("scope_level")
                if level in {"project", "workstream"} and not metadata.get("project_id"):
                    problems.append(f"{where}: scoped user entry requires project_id")
                if level == "workstream" and not metadata.get("workstream_id"):
                    problems.append(f"{where}: workstream user entry requires workstream_id")
        elif document.record_type == "continuity_packet":
            missing = sorted(PACKET_REQUIRED - metadata.keys())
            if missing:
                problems.append(f"{where}: missing packet fields: {', '.join(missing)}")
                continue
            packet_id = str(metadata.get("packet_id"))
            if not ENTRY_ID_RE.fullmatch(packet_id):
                problems.append(f"{where}: invalid packet_id")
            if packet_id in packets:
                problems.append(f"{where}: duplicate packet_id {packet_id}")
            packets[packet_id] = document
            if scope_type != "project":
                problems.append(f"{where}: continuity packet is outside a project scope")
            if metadata.get("project_id") != identity.get("project_id") or metadata.get("workstream_id") != identity.get("workstream_id"):
                problems.append(f"{where}: packet identity does not match directory scope")
            if metadata.get("schema_version") != SCHEMA_VERSION or not str(metadata.get("protocol_version") or "").startswith("1."):
                problems.append(f"{where}: packet schema or protocol version mismatch")
            if not isinstance(metadata.get("sequence"), int) or metadata["sequence"] < 1:
                problems.append(f"{where}: sequence must be positive")
            if metadata.get("complete_snapshot") is not True:
                problems.append(f"{where}: complete_snapshot must be true")
            if not isinstance(metadata.get("max_chars"), int) or metadata["max_chars"] < 1:
                problems.append(f"{where}: max_chars must be positive")
            if not valid_datetime(metadata.get("created_at")):
                problems.append(f"{where}: created_at must be ISO-8601")
            headings = re.findall(r"^##\s+(.+?)\s*$", document.body, flags=re.MULTILINE)
            if headings != list(PACKET_HEADINGS):
                problems.append(f"{where}: packet headings must appear once in canonical order")
            if len(document.body) > int(metadata.get("max_chars") or 0):
                problems.append(f"{where}: packet body exceeds max_chars")
        else:
            problems.append(f"{where}: unknown record_type {document.record_type!r}")
    for role, ids in sorted(active_roles.items()):
        if len(ids) > 1:
            problems.append(f"{scope}: multiple committed active {role} entries: {', '.join(ids)}")
    for entry_id, document in entries.items():
        for target_id in comma_list(document.metadata.get("conflicts_with")):
            target = entries.get(target_id)
            if target is None:
                problems.append(f"{document.path}: unknown conflict id {target_id}")
            elif target.record_type != document.record_type:
                problems.append(f"{document.path}: conflict crosses record types")
        replacement_id = str(document.metadata.get("superseded_by") or "")
        if replacement_id:
            replacement = entries.get(replacement_id)
            if replacement is None:
                problems.append(f"{document.path}: unknown superseded_by {replacement_id}")
            elif replacement.metadata.get("status") != "committed":
                problems.append(f"{document.path}: replacement is not committed")
    if packets:
        children: defaultdict[str, list[str]] = defaultdict(list)
        sequence_seen: dict[int, str] = {}
        for packet_id, document in packets.items():
            sequence = int(document.metadata.get("sequence") or 0)
            if sequence in sequence_seen:
                problems.append(f"{document.path}: duplicate packet sequence {sequence}")
            sequence_seen[sequence] = packet_id
            predecessor = str(document.metadata.get("continued_from") or "")
            if predecessor:
                children[predecessor].append(packet_id)
                prior = packets.get(predecessor)
                if prior and sequence != int(prior.metadata.get("sequence") or 0) + 1:
                    problems.append(f"{document.path}: sequence does not follow predecessor")
            elif sequence != 1:
                problems.append(f"{document.path}: only sequence 1 may omit continued_from")
            for target_id in packet_entry_refs(document.body):
                target = entries.get(target_id)
                if target is None:
                    problems.append(f"{document.path}: unknown entry reference {target_id}")
                elif target.record_type != "project_state":
                    problems.append(f"{document.path}: packet references non-project entry {target_id}")
        for predecessor, successors in children.items():
            if len(successors) > 1:
                problems.append(f"{scope}: lineage branch after {predecessor}: {', '.join(sorted(successors))}")
    return problems


def validate_store(store: Path) -> list[str]:
    try:
        root = ensure_store(store)
    except ProtocolError as exc:
        return [str(exc)]
    problems: list[str] = []
    for scope_type, scope, identity in all_scopes(root):
        problems.extend(validate_scope(scope_type, scope, identity))
    return problems


def scope_fingerprint(scope: Path) -> str:
    digest = hashlib.sha256()
    for document in iter_documents(scope):
        relative = document.path.relative_to(scope).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(document.sha256.encode("ascii"))
        digest.update(b"\0")
    return digest.hexdigest()


INDEX_SCHEMA = """
CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE documents (
    id INTEGER PRIMARY KEY,
    path TEXT NOT NULL UNIQUE,
    record_type TEXT NOT NULL,
    identity TEXT NOT NULL,
    title TEXT NOT NULL,
    kind TEXT NOT NULL,
    status TEXT NOT NULL,
    authority TEXT NOT NULL,
    load_policy TEXT NOT NULL,
    sensitivity TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    body TEXT NOT NULL,
    metadata_json TEXT NOT NULL,
    sha256 TEXT NOT NULL
);
CREATE INDEX documents_filters ON documents(record_type, status, load_policy, sensitivity);
CREATE VIRTUAL TABLE documents_fts USING fts5(title, body, identity, content='documents', content_rowid='id');
"""


def build_index(scope: Path) -> dict[str, Any]:
    documents = list(iter_documents(scope))
    fingerprint = scope_fingerprint(scope)
    output = scope / "index.sqlite"
    handle, temporary_name = tempfile.mkstemp(prefix="index.sqlite.", suffix=".tmp", dir=scope)
    os.close(handle)
    temporary = Path(temporary_name)
    try:
        connection = sqlite3.connect(temporary)
        try:
            connection.executescript(INDEX_SCHEMA)
            connection.execute("INSERT INTO metadata(key, value) VALUES ('fingerprint', ?)", (fingerprint,))
            for document in documents:
                metadata = document.metadata
                connection.execute(
                    """INSERT INTO documents(
                        path, record_type, identity, title, kind, status, authority,
                        load_policy, sensitivity, created_at, updated_at, body,
                        metadata_json, sha256
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        document.path.relative_to(scope).as_posix(),
                        document.record_type,
                        document.identity,
                        str(metadata.get("title") or document.identity),
                        str(metadata.get("kind") or ""),
                        str(metadata.get("status") or ""),
                        str(metadata.get("authority") or ""),
                        str(metadata.get("load_policy") or ""),
                        str(metadata.get("sensitivity") or "normal"),
                        str(metadata.get("created_at") or ""),
                        str(metadata.get("updated_at") or metadata.get("created_at") or ""),
                        document.body,
                        json.dumps(metadata, sort_keys=True, ensure_ascii=False),
                        document.sha256,
                    ),
                )
            connection.execute("INSERT INTO documents_fts(rowid, title, body, identity) SELECT id, title, body, identity FROM documents")
            connection.commit()
            integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
            count = connection.execute("SELECT count(*) FROM documents").fetchone()[0]
            if integrity != "ok" or count != len(documents):
                raise IndexUnavailable(f"candidate index verification failed: {integrity}")
        finally:
            connection.close()
        os.replace(temporary, output)
        check = sqlite3.connect(f"file:{output.as_posix()}?mode=ro", uri=True)
        try:
            if check.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise IndexUnavailable("persisted index failed readback")
        finally:
            check.close()
        return {"index": str(output), "documents": len(documents), "fingerprint": fingerprint}
    finally:
        if temporary.exists():
            temporary.unlink()


def _matches_filters(
    document: Document,
    *,
    query: str,
    record_type: str,
    kind: str,
    status: str,
    load_policy: str,
    include_private: bool,
) -> bool:
    metadata = document.metadata
    if record_type and document.record_type != record_type:
        return False
    if kind and metadata.get("kind") != kind:
        return False
    if status and metadata.get("status") != status:
        return False
    if load_policy and metadata.get("load_policy") != load_policy:
        return False
    if not include_private and metadata.get("sensitivity") == "private":
        return False
    if query:
        haystack = "\n".join((str(metadata.get("title") or ""), document.identity, document.body)).lower()
        if query.lower() not in haystack:
            return False
    return True


def direct_search(
    scope: Path,
    *,
    query: str = "",
    record_type: str = "",
    kind: str = "",
    status: str = "",
    load_policy: str = "",
    include_private: bool = False,
    limit: int = 20,
) -> list[dict[str, Any]]:
    documents = [
        document
        for document in iter_documents(scope)
        if _matches_filters(
            document,
            query=query,
            record_type=record_type,
            kind=kind,
            status=status,
            load_policy=load_policy,
            include_private=include_private,
        )
    ]
    documents.sort(key=lambda item: (str(item.metadata.get("updated_at") or item.metadata.get("created_at") or ""), item.path.name), reverse=True)
    return [document_result(document) for document in documents[:limit]]


def document_result(document: Document) -> dict[str, Any]:
    return {
        "path": str(document.path),
        "record_type": document.record_type,
        "identity": document.identity,
        "title": str(document.metadata.get("title") or document.identity),
        "kind": str(document.metadata.get("kind") or ""),
        "status": str(document.metadata.get("status") or ""),
        "authority": str(document.metadata.get("authority") or ""),
        "load_policy": str(document.metadata.get("load_policy") or ""),
        "sensitivity": str(document.metadata.get("sensitivity") or "normal"),
        "created_at": str(document.metadata.get("created_at") or ""),
        "updated_at": str(document.metadata.get("updated_at") or document.metadata.get("created_at") or ""),
        "metadata": document.metadata,
        "body": document.body,
    }


def indexed_search(
    scope: Path,
    *,
    query: str = "",
    record_type: str = "",
    kind: str = "",
    status: str = "",
    load_policy: str = "",
    include_private: bool = False,
    limit: int = 20,
) -> list[dict[str, Any]]:
    index = scope / "index.sqlite"
    if not index.is_file():
        raise IndexUnavailable("index is missing")
    connection = sqlite3.connect(f"file:{index.as_posix()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        if connection.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise IndexUnavailable("index integrity check failed")
        row = connection.execute("SELECT value FROM metadata WHERE key='fingerprint'").fetchone()
        if row is None or row[0] != scope_fingerprint(scope):
            raise IndexUnavailable("index is stale")
        sql = "SELECT d.* FROM documents d"
        clauses: list[str] = []
        values: list[Any] = []
        if query:
            sql += " JOIN documents_fts f ON f.rowid=d.id"
            clauses.append("documents_fts MATCH ?")
            values.append('"' + query.replace('"', '""') + '"')
        for column, value in (
            ("record_type", record_type),
            ("kind", kind),
            ("status", status),
            ("load_policy", load_policy),
        ):
            if value:
                clauses.append(f"d.{column} = ?")
                values.append(value)
        if not include_private:
            clauses.append("d.sensitivity != 'private'")
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY d.updated_at DESC, d.path DESC LIMIT ?"
        values.append(limit)
        rows = connection.execute(sql, values).fetchall()
    except sqlite3.Error as exc:
        raise IndexUnavailable(f"index read failed: {exc}") from exc
    finally:
        connection.close()
    results: list[dict[str, Any]] = []
    for row in rows:
        metadata = json.loads(row["metadata_json"])
        results.append(
            {
                "path": str(scope / row["path"]),
                "record_type": row["record_type"],
                "identity": row["identity"],
                "title": row["title"],
                "kind": row["kind"],
                "status": row["status"],
                "authority": row["authority"],
                "load_policy": row["load_policy"],
                "sensitivity": row["sensitivity"],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
                "metadata": metadata,
                "body": row["body"],
            }
        )
    return results


def search_with_recovery(scope: Path, **filters: Any) -> dict[str, Any]:
    try:
        results = indexed_search(scope, **filters)
        return {"mode": "index", "rebuild": "not_needed", "results": results}
    except IndexUnavailable as exc:
        results = direct_search(scope, **filters)
        try:
            build_index(scope)
            rebuild = "rebuilt"
        except (OSError, ProtocolError, sqlite3.Error) as rebuild_error:
            rebuild = f"failed: {rebuild_error}"
        return {"mode": "direct", "index_error": str(exc), "rebuild": rebuild, "results": results}


def effective_project_entries(scope: Path, *, include_private: bool = False) -> list[Document]:
    return [
        document
        for document in iter_documents(scope)
        if document.record_type == "project_state"
        and document.metadata.get("status") == "committed"
        and document.metadata.get("load_policy") == "active"
        and (include_private or document.metadata.get("sensitivity") != "private")
    ]


def bullet_entries(entries: Iterable[Document], kinds: set[str]) -> list[str]:
    selected = [entry for entry in entries if entry.metadata.get("kind") in kinds]
    selected.sort(key=lambda item: (str(item.metadata.get("kind")), item.identity))
    return [f"- [entry:{entry.identity}] {entry.body.strip()}" for entry in selected]


def render_packet_body(scope: Path) -> str:
    entries = effective_project_entries(scope)
    proposed = sorted(
        document.identity
        for document in iter_documents(scope)
        if document.record_type == "project_state" and document.metadata.get("status") == "proposed"
    )
    quarantined = sorted(
        document.identity
        for document in iter_documents(scope)
        if document.record_type == "project_state" and document.metadata.get("status") == "quarantined"
    )
    sections = {
        "Active state": bullet_entries(entries, {"objective", "decision", "note"}),
        "Blockers": bullet_entries(entries, {"blocker"}),
        "Next action": bullet_entries(entries, {"next_action"}),
        "Constraints": bullet_entries(entries, {"constraint"}),
        "Canonical refs": bullet_entries(entries, {"canonical_ref"}),
        "Quarantined": [f"- [entry:{identity}]" for identity in quarantined],
        "Staged": [f"- [entry:{identity}]" for identity in proposed],
    }
    lines = ["# Continuity Packet", ""]
    for heading in PACKET_HEADINGS:
        lines.append(f"## {heading}")
        lines.extend(sections[heading] or ["- None."])
        lines.append("")
    return "\n".join(lines).rstrip()


def packet_leaf(scope: Path) -> Document | None:
    packets = [document for document in iter_documents(scope) if document.record_type == "continuity_packet"]
    if not packets:
        return None
    by_id = {document.identity: document for document in packets}
    children: defaultdict[str, list[str]] = defaultdict(list)
    for document in packets:
        predecessor = str(document.metadata.get("continued_from") or "")
        if predecessor:
            children[predecessor].append(document.identity)
    branches = {key: values for key, values in children.items() if len(values) > 1}
    if branches:
        predecessor = sorted(branches)[0]
        raise ProtocolError(f"lineage branch after {predecessor}: {', '.join(sorted(branches[predecessor]))}")
    referenced = {value for value in children}
    leaves = [document for identity, document in by_id.items() if identity not in referenced]
    if len(leaves) != 1:
        raise ProtocolError(f"ambiguous packet lineage has {len(leaves)} leaves")
    return leaves[0]


def checkpoint(
    store: Path,
    project_id: str,
    workstream_id: str,
    created_by: str,
    max_chars: int,
) -> dict[str, Any]:
    if max_chars < 256:
        raise ProtocolError("max_chars must be at least 256")
    root = ensure_store(store)
    scope = project_scope(root, project_id, workstream_id)
    with workstream_lock(scope, created_by, "checkpoint"):
        problems = validate_scope("project", scope, {"project_id": project_id, "workstream_id": workstream_id})
        if problems:
            raise ProtocolError("project scope is invalid: " + "; ".join(problems))
        body = render_packet_body(scope)
        if len(body) > max_chars:
            raise ProtocolError(f"packet body is {len(body)} characters; max_chars is {max_chars}")
        predecessor = packet_leaf(scope)
        sequence = int(predecessor.metadata["sequence"]) + 1 if predecessor else 1
        timestamp = utc_now()
        compact_time = timestamp.replace("-", "").replace(":", "")
        packet_id = f"sp:{project_id}:{workstream_id}:r{sequence:06d}:{secrets.token_hex(2)}"
        filename = f"SP__{project_id}__{workstream_id}__r{sequence:06d}__{compact_time}__{secrets.token_hex(2)}.md"
        metadata = {
            "schema_version": SCHEMA_VERSION,
            "protocol_version": PROTOCOL_VERSION,
            "record_type": "continuity_packet",
            "packet_id": packet_id,
            "project_id": project_id,
            "workstream_id": workstream_id,
            "sequence": sequence,
            "continued_from": predecessor.identity if predecessor else "",
            "created_by": created_by,
            "created_at": timestamp,
            "complete_snapshot": True,
            "max_chars": max_chars,
        }
        target = scope / "continuity" / filename
        atomic_write(target, render_markdown(metadata, body))
        problems = validate_scope("project", scope, {"project_id": project_id, "workstream_id": workstream_id})
        if problems:
            target.unlink()
            raise ProtocolError("candidate checkpoint failed validation: " + "; ".join(problems))
        try:
            index_result: dict[str, Any] = {"status": "rebuilt", **build_index(scope)}
        except (OSError, ProtocolError, sqlite3.Error) as exc:
            index_result = {"status": "direct_mode", "error": str(exc)}
        return {
            "packet_id": packet_id,
            "path": str(target),
            "sequence": sequence,
            "continued_from": metadata["continued_from"],
            "characters": len(body),
            "index": index_result,
        }


def applicable_user_entries(
    store: Path,
    user_id: str,
    skill_id: str,
    project_id: str,
    workstream_id: str,
    model_id: str,
) -> list[dict[str, Any]]:
    scope = user_scope(store, user_id, skill_id)
    if not scope.is_dir():
        return []
    results: list[Document] = []
    for document in iter_documents(scope):
        metadata = document.metadata
        if document.record_type != "user_skill_memory" or metadata.get("status") != "committed" or metadata.get("load_policy") != "active":
            continue
        if metadata.get("applies_to") not in {"any_model", model_id}:
            continue
        level = metadata.get("scope_level")
        if level in {"project", "workstream"} and metadata.get("project_id") != project_id:
            continue
        if level == "workstream" and metadata.get("workstream_id") != workstream_id:
            continue
        results.append(document)
    rank = {"user": 0, "skill": 1, "project": 2, "workstream": 3}
    results.sort(key=lambda item: (rank.get(str(item.metadata.get("scope_level")), -1), str(item.metadata.get("updated_at"))), reverse=True)
    return [document_result(document) for document in results]


def resume(
    store: Path,
    project_id: str,
    workstream_id: str,
    *,
    user_id: str = "",
    skill_ids: Iterable[str] = (),
    model_id: str = "any_model",
    max_chars: int = 8000,
) -> dict[str, Any]:
    root = ensure_store(store)
    scope = project_scope(root, project_id, workstream_id)
    problems = validate_scope("project", scope, {"project_id": project_id, "workstream_id": workstream_id})
    if problems:
        raise ProtocolError("project scope is invalid: " + "; ".join(problems))
    search_result = search_with_recovery(
        scope,
        record_type="project_state",
        status="committed",
        load_policy="active",
        include_private=False,
        limit=100,
    )
    leaf = packet_leaf(scope)
    packet_ids = {
        document.identity
        for document in iter_documents(scope)
        if document.record_type == "continuity_packet"
    }
    lineage_gaps = sorted(
        {
            str(document.metadata.get("continued_from"))
            for document in iter_documents(scope)
            if document.record_type == "continuity_packet"
            and document.metadata.get("continued_from")
            and document.metadata.get("continued_from") not in packet_ids
        }
    )
    reconstructed = leaf is None
    packet_body = leaf.body if leaf else render_packet_body(scope)
    if len(packet_body) > max_chars:
        raise ProtocolError(f"resume packet is {len(packet_body)} characters; max_chars is {max_chars}")
    adaptations: dict[str, list[dict[str, Any]]] = {}
    if user_id:
        require_id(user_id, "user_id")
        require_id(model_id, "model_id")
        for skill_id in skill_ids:
            adaptations[skill_id] = applicable_user_entries(root, user_id, skill_id, project_id, workstream_id, model_id)
    return {
        "project_id": project_id,
        "workstream_id": workstream_id,
        "packet_id": leaf.identity if leaf else "",
        "sequence": int(leaf.metadata.get("sequence") or 0) if leaf else 0,
        "reconstructed": reconstructed,
        "lineage_gaps": lineage_gaps,
        "packet": packet_body,
        "project_state": search_result,
        "user_skill_memory": adaptations,
    }
