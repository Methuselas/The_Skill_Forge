#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Portable stdlib-only command interface for the State Protocol."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sqlite3
import sys

from _state_protocol import (
    LOAD_POLICIES,
    PROJECT_KINDS,
    SENSITIVITIES,
    USER_KINDS,
    USER_SCOPE_LEVELS,
    ProtocolError,
    all_scopes,
    build_index,
    checkpoint,
    commit_entry,
    ensure_store,
    initialize_store,
    project_scope,
    propose_project_entry,
    propose_user_entry,
    resume,
    search_with_recovery,
    user_scope,
    validate_scope,
    validate_store,
)


def emit(value: object) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False))


def add_scope_arguments(parser: argparse.ArgumentParser, *, required: bool = True) -> None:
    parser.add_argument("--scope", choices=("project", "user"), required=required)
    parser.add_argument("--project-id")
    parser.add_argument("--workstream-id", default="main")
    parser.add_argument("--user-id")
    parser.add_argument("--skill-id")


def resolved_scope(args: argparse.Namespace) -> tuple[str, Path, dict[str, str]]:
    root = ensure_store(args.store)
    if args.scope == "project":
        if not args.project_id:
            raise ProtocolError("project scope requires --project-id")
        identity = {"project_id": args.project_id, "workstream_id": args.workstream_id}
        return "project", project_scope(root, **identity), identity
    if not args.user_id or not args.skill_id:
        raise ProtocolError("user scope requires --user-id and --skill-id")
    identity = {"user_id": args.user_id, "skill_id": args.skill_id}
    return "user", user_scope(root, **identity), identity


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--store", type=Path, required=True, help="explicit State Protocol data root")
    sub = result.add_subparsers(dest="command", required=True)

    initialize = sub.add_parser("initialize", help="create a guarded store and initial scopes")
    initialize.add_argument("--project-id", required=True)
    initialize.add_argument("--workstream-id", default="main")
    initialize.add_argument("--created-by", required=True)
    initialize.add_argument("--user-id", default="")
    initialize.add_argument("--skill", action="append", default=[])

    propose = sub.add_parser("propose", help="write a proposed or quarantined state entry")
    add_scope_arguments(propose)
    propose.add_argument("--kind", required=True)
    propose.add_argument("--title", required=True)
    propose.add_argument("--text", required=True)
    propose.add_argument("--created-by", required=True)
    propose.add_argument("--source-ref", required=True)
    propose.add_argument("--entry-id", default="")
    propose.add_argument("--load-policy", choices=sorted(LOAD_POLICIES), default="active")
    propose.add_argument("--sensitivity", choices=sorted(SENSITIVITIES))
    propose.add_argument("--conflicts-with", action="append", default=[])
    propose.add_argument("--scope-level", choices=sorted(USER_SCOPE_LEVELS), default="skill")
    propose.add_argument("--applies-to", default="any_model")
    propose.add_argument("--evidence-count", type=int, default=1)
    propose.add_argument("--review-after", default="")

    commit = sub.add_parser("commit", help="commit a proposal using declared authority")
    add_scope_arguments(commit)
    commit.add_argument("--entry-id", required=True)
    commit.add_argument("--authority", choices=("user", "verified_tool"), required=True)
    commit.add_argument("--source-ref", required=True)
    commit.add_argument("--actor", required=True)
    commit.add_argument("--supersedes", action="append", default=[])

    search = sub.add_parser("search", help="query one exact scope with direct-read recovery")
    add_scope_arguments(search)
    search.add_argument("query", nargs="?", default="")
    search.add_argument("--record-type", default="")
    search.add_argument("--kind", default="")
    search.add_argument("--status", choices=sorted({"proposed", "committed", "quarantined", "superseded", "discarded"}), default="")
    search.add_argument("--load-policy", choices=sorted(LOAD_POLICIES), default="")
    search.add_argument("--include-private", action="store_true")
    search.add_argument("--limit", type=int, default=20)

    resume_parser = sub.add_parser("resume", help="render a bounded project packet and applicable user adaptation")
    resume_parser.add_argument("--project-id", required=True)
    resume_parser.add_argument("--workstream-id", default="main")
    resume_parser.add_argument("--user-id", default="")
    resume_parser.add_argument("--skill", action="append", default=[])
    resume_parser.add_argument("--model-id", default="any_model")
    resume_parser.add_argument("--max-chars", type=int, default=8000)

    checkpoint_parser = sub.add_parser("checkpoint", help="write an immutable complete continuity snapshot")
    checkpoint_parser.add_argument("--project-id", required=True)
    checkpoint_parser.add_argument("--workstream-id", default="main")
    checkpoint_parser.add_argument("--created-by", required=True)
    checkpoint_parser.add_argument("--max-chars", type=int, default=8000)

    crawl = sub.add_parser("crawl", help="rebuild disposable indexes")
    add_scope_arguments(crawl, required=False)
    crawl.add_argument("--all", action="store_true")

    validate = sub.add_parser("validate", help="validate canonical Markdown and relationships")
    add_scope_arguments(validate, required=False)
    validate.add_argument("--all", action="store_true")
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.command == "initialize":
            emit(initialize_store(args.store, args.project_id, args.workstream_id, args.created_by, args.user_id, args.skill))
            return 0
        if args.command == "propose":
            if args.scope == "project":
                if not args.project_id or args.kind not in PROJECT_KINDS:
                    raise ProtocolError("project proposal requires --project-id and a project kind")
                document = propose_project_entry(
                    args.store,
                    args.project_id,
                    args.workstream_id,
                    args.kind,
                    args.title,
                    args.text,
                    args.created_by,
                    args.source_ref,
                    entry_id=args.entry_id,
                    load_policy=args.load_policy,
                    sensitivity=args.sensitivity or "normal",
                    conflicts_with=args.conflicts_with,
                )
            else:
                if not args.user_id or not args.skill_id or args.kind not in USER_KINDS:
                    raise ProtocolError("user proposal requires --user-id, --skill-id, and a user-memory kind")
                document = propose_user_entry(
                    args.store,
                    args.user_id,
                    args.skill_id,
                    args.kind,
                    args.title,
                    args.text,
                    args.created_by,
                    args.source_ref,
                    entry_id=args.entry_id,
                    scope_level=args.scope_level,
                    project_id=args.project_id or "",
                    workstream_id=args.workstream_id if args.scope_level == "workstream" else "",
                    applies_to=args.applies_to,
                    load_policy=args.load_policy,
                    sensitivity=args.sensitivity or "private",
                    evidence_count=args.evidence_count,
                    review_after=args.review_after,
                    conflicts_with=args.conflicts_with,
                )
            emit({"entry_id": document.identity, "path": str(document.path), "status": document.metadata["status"]})
            return 0
        if args.command == "commit":
            _scope_type, scope, _identity = resolved_scope(args)
            document = commit_entry(scope, args.entry_id, args.authority, args.source_ref, args.actor, args.supersedes)
            emit({"entry_id": document.identity, "path": str(document.path), "status": "committed", "authority": args.authority})
            return 0
        if args.command == "search":
            _scope_type, scope, _identity = resolved_scope(args)
            if args.limit < 1:
                raise ProtocolError("limit must be positive")
            emit(
                search_with_recovery(
                    scope,
                    query=args.query,
                    record_type=args.record_type,
                    kind=args.kind,
                    status=args.status,
                    load_policy=args.load_policy,
                    include_private=args.include_private,
                    limit=args.limit,
                )
            )
            return 0
        if args.command == "resume":
            emit(
                resume(
                    args.store,
                    args.project_id,
                    args.workstream_id,
                    user_id=args.user_id,
                    skill_ids=args.skill,
                    model_id=args.model_id,
                    max_chars=args.max_chars,
                )
            )
            return 0
        if args.command == "checkpoint":
            emit(checkpoint(args.store, args.project_id, args.workstream_id, args.created_by, args.max_chars))
            return 0
        if args.command == "crawl":
            root = ensure_store(args.store)
            if args.all:
                emit({"indexes": [build_index(scope) for _kind, scope, _identity in all_scopes(root)]})
            else:
                if not args.scope:
                    raise ProtocolError("crawl requires --all or one --scope")
                _scope_type, scope, _identity = resolved_scope(args)
                emit(build_index(scope))
            return 0
        if args.command == "validate":
            if args.all:
                problems = validate_store(args.store)
            else:
                if not args.scope:
                    raise ProtocolError("validate requires --all or one --scope")
                scope_type, scope, identity = resolved_scope(args)
                problems = validate_scope(scope_type, scope, identity)
            if problems:
                emit({"valid": False, "problems": problems})
                return 2
            emit({"valid": True, "problems": []})
            return 0
        raise ProtocolError(f"unknown command: {args.command}")
    except (OSError, ProtocolError, sqlite3.Error) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
