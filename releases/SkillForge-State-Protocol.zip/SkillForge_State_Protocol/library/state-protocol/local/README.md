# Local Store and Crawler

The bundled Python interface uses only the standard library:

```text
python library/state-protocol/local/tools/state_protocol.py --store <path> <command>
```

Commands are `initialize`, `resume`, `search`, `propose`, `commit`, `checkpoint`,
`crawl`, and `validate`. Run `--help` on the command and subcommand for arguments.

## Layout

```text
<store>/
|-- STATE_PROTOCOL_STORE.md
|-- projects/
|   `-- <project_id>/workstreams/<workstream_id>/
|       |-- state/
|       |-- continuity/
|       `-- index.sqlite
`-- users/
    `-- <user_id>/skills/<skill_id>/
        |-- state/
        `-- index.sqlite
```

The sentinel prevents the tool from treating an arbitrary directory as its data
root. Project and user indexes are separate and disposable. Deleting every
`index.sqlite` must leave all canonical state intact.

## First local project

```text
python library/state-protocol/local/tools/state_protocol.py --store D:/StateProtocol initialize --project-id my-project --workstream-id main --created-by bionic --user-id local-user --skill visual-art
```

Model or crawler discoveries use `propose`. Only a declared `user` or
`verified_tool` authority can commit project state, and only `user` can commit
user skill memory. The command records caller-supplied authority; it cannot prove
that a model represented the user honestly.

`resume` accepts repeated `--skill` values and retrieves user adaptation only for
those activated skills. It never injects the rest of the user store.

If an index fails integrity or does not match the current Markdown fingerprint,
search returns direct-read results first and then attempts an atomic rebuild. A
failed rebuild leaves canonical Markdown and the previous readable index intact.
