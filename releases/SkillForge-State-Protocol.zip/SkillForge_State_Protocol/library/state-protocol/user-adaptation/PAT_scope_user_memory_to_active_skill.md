---
object_id: PAT_state_protocol_scope_user_memory_to_active_skill
object_type: pattern
name: Scope User Memory to the Active Skill
library_path:
- state-protocol
- user-adaptation
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- user_memory
- skill
- retrieval
- privacy
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Scope User Memory to the Active Skill

## Pattern Rule
**IF** stored user adaptation may affect a task
**THEN** retrieve only committed entries whose user, skill, applicability, and declared scope match the current action
**ELSE** keep the user store unloaded

## Do
- Resolve the local user identity and activated skill before reading any user entry.
- Apply scope from narrowest to broadest: current instruction, workstream, project, skill, then user-wide default.
- Load only the entries needed to alter the active skill's execution.
- Keep user records in a separate root from project continuity and PASS Skillset Memory.
- Default user entries to private disclosure and omit them from ordinary project packets.

## Don't
- Do not preload a general portrait of the user.
- Do not expose one family member's entries to another local user or project collaborator.
- Do not send an Art preference to Software Engineering merely because both skills are installed.
- Do not copy user adaptation into canonical skill cards.

## Checklist
- Are user id and active skill known before retrieval?
- Does every loaded entry apply to the current scope and action?
- Could project continuity be shared without disclosing the user store?

## Notes
The store answers how to serve one user when a particular skill is active; it does not define project truth or what the skill universally knows. Retrieval by activation keeps personalization useful without turning every prompt into a dossier.

