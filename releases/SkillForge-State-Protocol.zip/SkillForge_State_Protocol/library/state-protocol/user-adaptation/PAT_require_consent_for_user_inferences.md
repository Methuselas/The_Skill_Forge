---
object_id: PAT_state_protocol_require_consent_for_user_inferences
object_type: pattern
name: Require Consent for User Inferences
library_path:
- state-protocol
- user-adaptation
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- consent
- inference
- preference
- privacy
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Require Consent for User Inferences

## Pattern Rule
**IF** a model notices a recurring user tendency that might improve future skill use
**THEN** keep the observation proposed until the user confirms the preference or explicitly authorizes that class of bounded learning
**ELSE** commit a directly stated preference in its narrowest applicable scope

## Do
- Express an observation as a concrete interaction change, such as smaller debugging steps or construction-first art feedback.
- Preserve the evidence count and scope without copying transcript passages into the durable entry.
- Ask for confirmation when the proposed adaptation would materially change future responses.
- Offer a review or expiry date for tendencies that may be temporary.
- Allow immediate correction, supersession, or deletion by the user.

## Don't
- Do not infer personality, diagnosis, relationships, beliefs, or sensitive traits from conversational behavior.
- Do not promote a tendency because several models repeated the same inference from shared context.
- Do not treat one successful interaction as a stable universal preference.
- Do not use tool verification to authorize a preference for the user.

## Checklist
- Does the entry describe a bounded change in skill behavior rather than a claim about the person?
- Was the preference stated, confirmed, or covered by explicit learning consent?
- Can the user understand, correct, and remove the entry from its Markdown alone?

## Notes
Repeated observation can justify asking, not deciding. This boundary captures useful quirks while preventing local personalization from becoming covert profiling.

