---
object_id: PAT_state_protocol_override_memory_with_current_instruction
object_type: pattern
name: Override Memory With Current Instruction
library_path:
- state-protocol
- user-adaptation
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- precedence
- preference
- correction
- scope
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Override Memory With Current Instruction

## Pattern Rule
**IF** an applicable stored preference conflicts with the user's current instruction or a binding project requirement
**THEN** follow the current instruction or requirement for this action and separately propose correction or supersession only when the durable preference itself appears changed
**ELSE** apply the stored preference within its declared scope

## Do
- Treat a one-off exception as local to the current action unless the user generalizes it.
- Let workstream and project overrides beat skill-wide and user-wide defaults.
- Surface a stored conflict only when it materially affects the requested result.
- Preserve the existing entry while an apparent permanent change remains ambiguous.

## Don't
- Do not argue with a current request because memory records an older preference.
- Do not silently rewrite a durable preference from one exception.
- Do not allow a soft preference to weaken a project fact, safety constraint, or explicit acceptance criterion.

## Checklist
- Was the current instruction followed for the present action?
- Is any durable update supported by a statement broader than the immediate exception?
- Did the narrower scope win without changing unrelated scopes?

## Notes
Stored adaptation is assistance, never authority over the user. Separating immediate execution from durable revision prevents both stubbornness and preference churn.

