---
object_id: AP_state_protocol_capture_and_apply_user_adaptation
object_type: ap
name: Capture and Apply User Adaptation
library_path:
- state-protocol
- user-adaptation
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- user_memory
- preference
- consent
- retrieval
cross_links:
- rel: supports
  target_object_id: PAT_state_protocol_reject_nonstate_before_persistence
- rel: supports
  target_object_id: PAT_state_protocol_stage_inference_before_commitment
- rel: supports
  target_object_id: PAT_state_protocol_scope_user_memory_to_active_skill
- rel: supports
  target_object_id: PAT_state_protocol_require_consent_for_user_inferences
- rel: supports
  target_object_id: PAT_state_protocol_override_memory_with_current_instruction
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Capture and Apply User Adaptation

## Objective
Preserve a user-controlled adaptation that improves future use of a specific skill, then apply it without contaminating project continuity, canonical skill knowledge, or another user's context.

## Steps / Flow
1. **Reject non-adaptation.** Apply `PAT_state_protocol_reject_nonstate_before_persistence`. Continue only when a compact preference, accommodation, convention, or bounded observed tendency would change future skill behavior.
2. **Name the owner and scope.** Record local user id, skill id, applicability, and the narrowest useful scope. Apply `PAT_state_protocol_scope_user_memory_to_active_skill`; never route the entry through project state or PASS Skillset Memory.
3. **Classify the authority.** A direct user preference may be committed. A model observation applies `PAT_state_protocol_require_consent_for_user_inferences` and remains proposed unless the user confirms it or has authorized that bounded learning behavior.
4. **Protect sensitivity.** Default the entry to private, exclude unnecessary personal explanation, and add review or expiry when the adaptation may be temporary.
5. **Check existing adaptation.** Compare applicable entries by scope and authority. Use explicit supersession for durable correction and quarantine unresolved contradictions.
6. **Write and read back.** Persist one self-contained entry and verify that it names no transcript, unrelated project state, or other user.
7. **Retrieve on activation.** When the named skill activates, load only matching committed active entries; do not preload the rest of the user store.
8. **Apply with live precedence.** Use `PAT_state_protocol_override_memory_with_current_instruction` so the current request and binding project requirements win. Completion means the adaptation changed only the intended skill action and remained independently inspectable and removable.

## Notes
Examples include preferring construction lines during art critique, seeing a diff before commits, or receiving smaller debugging steps. The record describes an interaction adjustment, not a theory of the user.

