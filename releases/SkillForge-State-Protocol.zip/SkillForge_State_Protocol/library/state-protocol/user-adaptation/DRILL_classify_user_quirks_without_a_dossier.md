---
object_id: DRILL_state_protocol_classify_user_quirks_without_a_dossier
object_type: drill
name: Classify User Quirks Without a Dossier
library_path:
- state-protocol
- user-adaptation
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- user_memory
- privacy
- consent
- classification
cross_links:
- rel: teaches
  target_object_id: PAT_state_protocol_scope_user_memory_to_active_skill
- rel: teaches
  target_object_id: PAT_state_protocol_require_consent_for_user_inferences
- rel: teaches
  target_object_id: AP_state_protocol_capture_and_apply_user_adaptation
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
target_skill: Retain useful user-specific skill adaptations without profiling or cross-skill leakage
variants: []
---

# Classify User Quirks Without a Dossier

## Practice Task
Classify a mixed set of ten observations containing direct preferences, one-off requests, inferred tendencies, sensitive personal facts, project constraints, and skill-specific accommodations into committed user skill memory, proposed user skill memory, project state, ephemeral material, or reject.

## Target Skill
Separate useful, consented interaction adaptations from project truth, temporary context, and personal profiling.

## Setup
Create ten labeled observations with at least two plausible misclassifications, including a repeated but unconfirmed tendency and a direct preference that conflicts with a current project requirement.

## Instructions
1. Assign one disposition and destination to every observation.
2. Record the user, skill, scope, authority, sensitivity, and load policy for every retained user entry.
3. Write the proposed entry for the repeated unconfirmed tendency and the confirmation question it would require.
4. Record the project destination for every project fact or constraint.
5. Produce a rejection list with the reason each rejected personal item is unnecessary or unsafe.
6. Resolve the direct-preference/project-requirement collision for the current task without changing the durable preference.
7. Submit the classification table, retained entry frontmatter, confirmation question, rejection list, and collision disposition.

## Success Check
- Every retained user entry names one user and one applicable skill, and defaults to private unless disclosure was explicitly required.
- The repeated inferred tendency remains proposed and has a bounded confirmation question; committing it because it appeared more than once is the named near-miss.
- Sensitive personal facts with no necessary interaction change are rejected rather than rephrased as preferences.
- Project facts and constraints are absent from the user store.
- The current project requirement wins its collision without silently deleting or rewriting the broader preference.
- Every classification has a reason tied to future behavior, authority, scope, or privacy.

## Common Failures
- Turning a direct preference into a universal personality claim.
- Keeping sensitive context because local storage feels private.
- Loading all user entries whenever any skill activates.
- Treating current task compliance as evidence that the user's long-term preference changed.

## Notes
This exercise practises Scope User Memory to the Active Skill, Require Consent for User Inferences, and the complete user-adaptation procedure. The mixed destinations force the learner to preserve the three-store boundary rather than merely write polite preference notes.
