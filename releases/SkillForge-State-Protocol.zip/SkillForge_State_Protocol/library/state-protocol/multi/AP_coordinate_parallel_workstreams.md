---
object_id: AP_state_protocol_coordinate_parallel_workstreams
object_type: ap
name: Coordinate Parallel Continuity Workstreams
library_path:
- state-protocol
- multi
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: specialized
specialization_axis: method
foundation_object_id: none
tags:
- multi_model
- workstream
- locking
- integration
cross_links:
- rel: supports
  target_object_id: PAT_state_protocol_bind_workstreams_to_work_not_models
- rel: supports
  target_object_id: PAT_state_protocol_serialize_each_workstream_write
- rel: supports
  target_object_id: PAT_state_protocol_quarantine_conflicts_without_overwriting
- rel: supports
  target_object_id: AP_state_protocol_operate_a_local_continuity_store
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Coordinate Parallel Continuity Workstreams

## Objective
Let several models or agents work in one project without mixing continuity, racing on one lineage, or confusing integration with shared context.

## Steps / Flow
1. **Partition the work.** Apply `PAT_state_protocol_bind_workstreams_to_work_not_models`; assign one coherent objective and collision domain to each workstream, with separate worktrees or checkouts when code can overlap.
2. **Initialize independently.** For each workstream, delegate store setup and lifecycle operations to `AP_state_protocol_operate_a_local_continuity_store`. Record creator identity without using it as the continuity key.
3. **Retrieve locally.** Each worker resumes and searches only its own project/workstream plus explicitly applicable user skill memory. It does not preload sibling packets.
4. **Write transactionally.** Apply `PAT_state_protocol_serialize_each_workstream_write` to every mutation and checkpoint. A held lock pauses only its owning workstream.
5. **Expose dependencies explicitly.** When one workstream needs another's result, add a canonical reference or blocker naming the dependency; do not copy the sibling's active state into both packets.
6. **Handle semantic disagreement.** Apply `PAT_state_protocol_quarantine_conflicts_without_overwriting` inside the integration workstream. Preserve contributing snapshots and require authority for any resolved project decision.
7. **Integrate deliberately.** Review artifacts and acceptance evidence outside the continuity store, then write the accepted project decision and next action into the designated integration workstream.
8. **Verify isolation.** Search each scope and confirm that unrelated entry and packet ids cannot appear. Completion requires independent lineages, successful readback, and an explicit integration record for every merged outcome.

## Notes
Continuity isolation and filesystem isolation solve different collisions. The protocol owns the former; worktrees, checkouts, and assignment boundaries must own the latter.

