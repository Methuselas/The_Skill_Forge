---
object_id: DRILL_state_protocol_isolate_parallel_workstreams
object_type: drill
name: Isolate Parallel Workstreams
library_path:
- state-protocol
- multi
stage_binding: 0 design
lane_fit: skill
foundation_role: foundation
routing_class: specialized
specialization_axis: method
foundation_object_id: none
tags:
- multi_model
- isolation
- locking
- contamination
cross_links:
- rel: teaches
  target_object_id: PAT_state_protocol_bind_workstreams_to_work_not_models
- rel: teaches
  target_object_id: PAT_state_protocol_serialize_each_workstream_write
- rel: teaches
  target_object_id: AP_state_protocol_coordinate_parallel_workstreams
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
target_skill: Maintain independent continuity and write transactions for parallel work in one project
variants: []
---

# Isolate Parallel Workstreams

## Practice Task
Run two simulated workers in one project: one repairs an API and one produces art assets. Give them different workstream ids, overlapping creator identities, one cross-workstream dependency, and one deliberate attempt to write the API packet while its lock is held.

## Target Skill
Separate work ownership from creator identity, keep retrieval scoped, reject concurrent writes, and integrate a dependency without copying sibling state.

## Setup
Create a disposable State Protocol store with two workstreams and fixtures containing distinct objectives, constraints, and next actions.

## Instructions
1. Record each workstream's objective, collision domain, creator, and continuity root.
2. Resume both scopes independently and save the returned entry and packet ids.
3. Hold the API workstream lock and attempt a second API checkpoint, recording the result.
4. While that lock remains held, checkpoint the art workstream and record the result.
5. Add an explicit dependency reference from the art workstream to the accepted API artifact without copying API active state.
6. Produce an integration entry that names both contributing workstreams and the authority accepting their joint result.
7. Submit the scope table, both resume outputs, both lock-attempt results, dependency entry, and integration entry.

## Success Check
- The two resume outputs contain no sibling state or packet ids.
- Both workers may share a creator value without sharing a workstream id.
- The second API write fails before changing a canonical file; allowing it because individual writes are atomic is the named near-miss.
- The art checkpoint succeeds while the API lock is held, demonstrating that locking is per workstream rather than store-wide.
- The dependency is represented by a reference or blocker, not duplicated active state.
- The integration entry names both workstreams and an allowed authority.

## Common Failures
- Naming workstreams after models and losing continuity when assignments move.
- Using one global lock that serializes unrelated work.
- Treating separate continuity folders as protection against edits in one shared checkout.
- Loading sibling packets to understand a single dependency.

## Notes
This exercise practises Bind Workstreams to Work, Not Models, Serialize Each Workstream Write, and the full parallel coordination procedure. The deliberate held-lock branch distinguishes real transaction isolation from tidy directory naming.

