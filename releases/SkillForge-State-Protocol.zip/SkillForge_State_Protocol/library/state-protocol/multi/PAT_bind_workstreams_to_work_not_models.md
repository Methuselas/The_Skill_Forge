---
object_id: PAT_state_protocol_bind_workstreams_to_work_not_models
object_type: pattern
name: Bind Workstreams to Work, Not Models
library_path:
- state-protocol
- multi
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: specialized
specialization_axis: method
foundation_object_id: PAT_state_protocol_scope_state_before_retrieval
tags:
- workstream
- multi_model
- handoff
- isolation
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Bind Workstreams to Work, Not Models

## Pattern Rule
**IF** several models, agents, or sessions operate in one project
**THEN** assign continuity by stable work ownership and record the current creator separately, so handoff changes `created_by` without changing `workstream_id`
**ELSE** retain an explicit `main` workstream for the single-threaded case

## Do
- Name a workstream for one coherent objective or integration surface rather than for the model currently assigned.
- Give parallel work distinct workstream directories and, where code is edited, distinct worktrees or checkouts.
- Let any authorized model resume the same lineage after validating its project and workstream ids.
- Merge conclusions only through an explicit integration action that cites the contributing workstreams.

## Don't
- Do not create `claude`, `codex`, or model-version workstreams when those models are merely interchangeable workers.
- Do not share one active packet between unrelated assignments because they inhabit the same repository.
- Do not infer that separate continuity directories prevent filesystem collisions in a shared checkout.

## Checklist
- Does each workstream name work that remains meaningful after its creator changes?
- Are unrelated objectives backed by separate continuity and filesystem scopes?
- Is every cross-workstream integration explicit and reviewable?

## Notes
This specializes Scope State Before Retrieval for multi-model work. Creator metadata answers who wrote an artifact; workstream identity answers which evolving body of work owns it.
