# Multi-Model Workstreams

Use one stable workstream per coherent body of work. `created_by` records who
wrote an entry or packet; it is not the continuity namespace.

Every project mutation uses a `.write.lock` inside its workstream. The lock covers
selection of the current packet, revision assignment, canonical write,
validation, and readback. Another workstream uses another lock and may proceed.

Continuity isolation does not isolate source files. Models that can edit the same
repository need separate worktrees or checkouts plus an explicit integration
workstream.

