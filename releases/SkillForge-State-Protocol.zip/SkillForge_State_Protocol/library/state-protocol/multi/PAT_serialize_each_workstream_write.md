---
object_id: PAT_state_protocol_serialize_each_workstream_write
object_type: pattern
name: Serialize Each Workstream Write
library_path:
- state-protocol
- multi
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: specialized
specialization_axis: method
foundation_object_id: none
tags:
- locking
- atomicity
- workstream
- concurrency
cross_links: []
reference:
  source_title: State Protocol
  author: Mitchell D McPhetridge
confidence: high
references: []
variants: []
---

# Serialize Each Workstream Write

## Pattern Rule
**IF** two processes may change state or create a checkpoint in the same workstream concurrently
**THEN** acquire one exclusive workstream lock across read, validation, write, and readback, and fail visibly when the lock is already held
**ELSE** keep other workstreams independent and writable

## Do
- Create the lock atomically and include owner, timestamp, and intended operation for diagnosis.
- Hold it across the whole invariant: selecting predecessor, assigning revision, writing the successor, validating, and readback.
- Write candidate files and indexes beside their destination and replace only after verification.
- Require explicit inspection before clearing a stale-looking lock; elapsed time alone cannot prove the owner is dead.

## Don't
- Do not lock the entire store when only one workstream is being changed.
- Do not treat atomic file creation and atomic rename as making the compound checkpoint transaction atomic.
- Do not auto-delete a lock based only on age.

## Checklist
- Can two different workstreams progress without sharing a lock?
- Does one lock cover every step that depends on the selected predecessor and revision?
- Would a second writer fail before changing any canonical file?

## Notes
The protected invariant is one linear workstream lineage. Locking a single write call leaves a race between reading the current leaf and publishing its successor; the lock must cover the complete transaction.

