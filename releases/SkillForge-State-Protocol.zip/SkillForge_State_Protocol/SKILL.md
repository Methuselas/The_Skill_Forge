---
name: skillforge-state-protocol
description: Use for compact cross-session continuity, local-model context recovery,
  user-controlled skill preferences, immutable project handoffs, local Markdown crawling,
  and isolated multi-model workstreams.
---

# SkillForge State Protocol

This is a self-contained SkillForge release.

`runtime/profile.yaml` (profile `state-protocol`) is this release's **execution contract**. It declares the execution modes, routing, risk checks, and completion requirements this skill is expected to honor. Do not preload it for discussion, critique, help, or another non-productive request. Before the first productive action, resolve the execution mode, apply the activated metaskills, perform the named risk checks, and satisfy the completion requirements. That responsibility is yours — nothing in this package can check it for you.

`scripts/skillforge_runtime.py` is an **optional deterministic helper** for hosts that can execute Python. It holds no state, runs only when invoked, and cannot observe or block anything you do:

- `doctor` checks that the bundled profile and library are internally consistent.
- `resolve --request <user request>` returns the contract for a request as JSON, so mode and check selection are deterministic instead of re-derived each time.
- `verify` audits a completion record you write, and reports which required checks it does not contain.

Prefer the resolver's bounded result to loading the complete profile. Where Python is unavailable, read and apply `runtime/profile.yaml` directly. The release is complete without Python.

The semantic craft knowledge lives in `library/`. Python resolves and reports; it does not sequence stages, gate approvals, or enforce the contract. Hard prerequisites have already been materialized locally. Each card is self-contained: it needs no source document to execute.

## Bundled knowledge

Load `library/metaskills/INDEX.md` as the default baseline, then retrieve only the domain indexes and cards relevant to the current decision. `RELEASE_MANIFEST.json` lists every bundled module; do not preload that list or the complete library.

## Blind Drill administration

This release includes canonical Drills and the optional model-neutral `scripts/skillforge_drill.py` helper. It standardizes administration, not how a taker reasons or solves the task. `list` and `show` discover the bundled Drills; `prepare` creates a student-safe packet at either `before-instructions` or `before-success-check`; `freeze` seals the produced answer before `reveal` creates the grader packet; and `finalize` requires every canonical Success Check criterion to be dispositioned. Use repeated `--drill` arguments to chain compatible Drills from one domain. Never expose `controller/` to the taker.

The helper never repeats a sitting, judges craft semantics, or writes Skillset Memory. `finalize` exports `candidate_training_event.json` for review and later import into the owning repository. If Python is unavailable, follow the same prepare → produce → freeze → reveal → grade order manually from the card.

## Mandatory execution barriers

Before the first productive action, read and retain `references/execution-barriers.md`. Do not load it for a non-productive request.

## License and attribution

Keep `LICENSE.md`, `NOTICE.md`, `TRADEMARKS.md`, and `LICENSES/` with this release. The vendored Python helpers are AGPL-3.0-or-later; the Skill instructions, knowledge, declarative profile, memory, and original assets are CC-BY-SA-4.0 unless a shipped file states otherwise.
