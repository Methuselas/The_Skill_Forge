# Mandatory Execution Barriers

These profile-owned instructions are part of the portable execution contract, not optional guidance. Read them before the first productive action and retain them for the active task.

- Markdown is canonical continuity state. SQLite indexes and CURRENT-style pointers are disposable navigation and never authorize, promote, quarantine, supersede, or repair an entry.
- Keep State Protocol data outside this release and outside PASS Skillset Memory. Project continuity, user skill memory, and PASS memory use separate roots, schemas, validators, and retrieval calls; never promote between them implicitly.
- Resolve an exact store, project_id, and workstream_id before project retrieval or mutation. Resolve an exact local user_id and active skill_id before user adaptation retrieval. Never search every scope and choose a plausible result.
- Reject transcript recap, hidden reasoning, emotional texture, repetition, and unrelated side threads before persistence. When no durable future behavior changed, write nothing and use NO_STATE_CHANGE only if a lifecycle adapter requires a disposition.
- New model or crawler inferences begin proposed. A clear user adoption can commit project state or user skill memory; a named verified tool may commit only factual project state. Indexing and repeated observation never create authority.
- Current user instructions and binding project requirements outrank stored user preferences. A one-off exception changes the current action, not the durable preference, unless the user generalizes it.
- User skill memory describes bounded interaction adjustments, defaults to private, loads only when its named skill activates, and never becomes a personality, diagnosis, relationship, belief, or sensitive-trait profile.
- Continuity packets are uniquely named, immutable, complete snapshots with explicit sequence and continued_from lineage. Detect two successors of one predecessor as a branch and never merge or choose it silently by recency.
- In local mode use library/state-protocol/local/tools/state_protocol.py. If its index is missing, corrupt, stale, or FTS5 is unavailable, resume by direct validated Markdown reads and attempt an atomic rebuild without claiming data loss.
- In multi mode bind workstream_id to the work rather than the model, serialize the complete read-validate-write-readback transaction for each workstream, and use separate worktrees or checkouts when filesystem edits could collide.
