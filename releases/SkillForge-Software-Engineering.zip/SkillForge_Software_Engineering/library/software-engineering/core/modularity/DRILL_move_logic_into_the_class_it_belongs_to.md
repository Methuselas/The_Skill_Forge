---
object_id: DRILL_move_logic_into_the_class_it_belongs_to
object_type: drill
name: Move Reaching-In Logic Into the Class It Belongs To
library_path:
- software-engineering
- core
- modularity
stage_binding: 3 rough
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- law_of_demeter
- modularity
- refactoring
- encapsulation
cross_links:
- rel: teaches
  target_object_id: PAT_make_classes_care_about_themselves
reference:
  source_title: 'Good Code, Bad Code: Think Like a Software Engineer'
  author: Tom Long
confidence: high
target_skill: relocating logic that operates on another class's internals into that class
references: []
variants: []
---

# Move Reaching-In Logic Into the Class It Belongs To

## Practice Task
Take a method that reaches into another class's parts to compute something, move it onto that class, and confirm a related requirement change now touches only one class.

## Target Skill
Spotting logic that cares about another class's internals and relocating it to that class.

## Setup
No special setup required.

## Instructions
1. Start from a class with a method that operates on another class's parts — a book computing a chapter's word count from the chapter's prelude and sections.
2. Quote the chained access verbatim before moving anything, and name separately each part of the other object it reaches into. This is the Law-of-Demeter smell.
3. Count how many distinct members the method touches on the other class.
4. Move the logic onto the class it concerns: give the chapter a `wordCount()` member function that sums its own parts. Write out the relocated method's parameter list and confirm nothing in it belongs to the class it left.
5. Update the original class to call the new high-level method and drop its knowledge of the other class's structure. Count the distinct members the former caller now touches.
6. Search the original class for a surviving copy of the moved logic and state the result of that search.
7. Apply a requirement change — chapters gain a summary — and list the classes you actually had to edit.

## Success Check
- The chained access is quoted verbatim before the move, and each part of the other object it reaches into is named separately. A general observation that the method knows too much cannot be compared against the after-state.
- The relocated method's parameter list is written out and contains nothing belonging to the class it left. Moving the body while passing the same internals in as arguments satisfies every other bullet here and keeps the whole of the coupling; that is what this bullet is for.
- The number of distinct members the former caller touches on the other class is counted before and after, and the after count is one high-level call.
- The requirement change is applied rather than imagined, and the classes actually edited are listed. A prediction that only one class would need editing is the claim under test and cannot also be the evidence for it.
- The original class is searched for a surviving copy of the moved logic and the result of that search is stated, since a duplicate left behind passes every bullet above.

## Common Failures
- Moving the method but still passing the other object's parts into it, keeping the coupling.
- Leaving a duplicate of the logic behind in the original class.

## Notes
This drills Long's `Book`/`Chapter` refactor. The reflex it builds is to read a chained call through an object into its members as a sign the logic is in the wrong place, and to push it onto the class that owns the data so future changes stay local.
