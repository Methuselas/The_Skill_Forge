---
object_id: DRILL_replace_inheritance_with_composition
object_type: drill
name: Replace Inheritance With Composition
library_path:
- software-engineering
- core
- modularity
stage_binding: 3 rough
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- composition
- inheritance
- refactoring
- interfaces
cross_links:
- rel: teaches
  target_object_id: PAT_prefer_composition_over_inheritance
reference:
  source_title: 'Good Code, Bad Code: Think Like a Software Engineer'
  author: Tom Long
confidence: high
target_skill: converting an inheritance-for-reuse relationship into composition over an interface
references: []
variants: []
---

# Replace Inheritance With Composition

## Practice Task
Take a class that extends another purely to reuse it, and refactor it to compose an injected interface instead, then compare the public APIs.

## Target Skill
Recognizing inheritance-for-reuse and converting it to composition over an interface.

## Setup
No special setup required.

## Instructions
1. Start from a subclass that extends a utility class to reuse it — an integer reader extending a comma-separated file handler.
2. Write out the subclass's effective public API in full, including everything inherited, and note the strange functions it exposes (reading raw strings, writing values).
3. Identify the interface that captures only what you need from the superclass (a file value reader), and find a call site for every member you put on it.
4. Refactor: have the class hold an injected instance of that interface instead of extending the class, and forward only the functions callers need (such as close). Enumerate the forwarded functions with a reason for each.
5. Support a sibling requirement — a semicolon-separated format — by injecting a different implementation and running it, with no subclass added.
6. Write out the new public surface, compare it against the one from step 2, and list the members that were removed.

## Success Check
- The subclass's effective public surface is written out in full, inherited members included, before the change. That list is the finding — the strange functions do not appear in the subclass's own source, which is exactly why the problem survives review.
- The extracted interface names only what this class actually uses, verified by finding a call site for every member on it. An interface that mirrors the superclass has renamed the coupling rather than removed it.
- The forwarded functions are enumerated with a reason for each, so forwarding is a decision rather than whatever was needed to make existing callers compile.
- The sibling format is supported by injecting a different implementation and running it, with no subclass added. That it could be done is what was already believed before the exercise.
- The new surface is compared against the old and the removed members are listed. If nothing was removed, composition bought nothing here, and saying so is the result rather than a failure.

## Common Failures
- Composing the concrete class instead of its interface, losing the reconfiguration benefit.
- Forwarding every function reflexively, which re-leaks the API composition was meant to hide.

## Notes
This drills Long's `IntFileReader` refactor from extending `CsvFileHandler` to composing a `FileValueReader`. The lesson is that inheritance couples you to a whole class and its API, while composition over an interface reuses just what you need and stays reconfigurable — reserve inheritance for genuine is-a relationships, and even then weigh its hazards.
