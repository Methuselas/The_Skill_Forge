---
name: skillforge-agent-kit
description: 'Use when several AI agents or sessions work in the same project and
  must not step on each other: acting as lead or worker, creating and claiming bounded
  tasks, holding file and resource scopes, heartbeating, reporting blocks and evidence,
  reviewing or reworking results, and asking for the next task. Ships a local, provider-neutral
  coordination runtime.'
---

# SkillForge Agent Kit

This is a self-contained SkillForge release.

`runtime/profile.yaml` (profile `generic`) is this release's **execution contract**. It declares the execution modes, routing, risk checks, and completion requirements this skill is expected to honor. Do not preload it for discussion, critique, help, or another non-productive request. Before the first productive action, resolve the execution mode, apply the activated metaskills, perform the named risk checks, and satisfy the completion requirements. That responsibility is yours — nothing in this package can check it for you.

`scripts/skillforge_runtime.py` is an **optional deterministic helper** for hosts that can execute Python. It holds no state, runs only when invoked, and cannot observe or block anything you do:

- `doctor` checks that the bundled profile and library are internally consistent.
- `resolve --request <user request>` returns the contract for a request as JSON, so mode and check selection are deterministic instead of re-derived each time.
- `verify` audits a completion record you write, and reports which required checks it does not contain.

Prefer the resolver's bounded result to loading the complete profile. Where Python is unavailable, read and apply `runtime/profile.yaml` directly. The release is complete without Python.

The semantic craft knowledge lives in `library/`. Python resolves and reports; it does not sequence stages, gate approvals, or enforce the contract. Hard prerequisites have already been materialized locally. Each card is self-contained: it needs no source document to execute.

## Bundled knowledge

Load `library/metaskills/INDEX.md` as the default baseline, then retrieve only the domain indexes and cards relevant to the current decision. `RELEASE_MANIFEST.json` lists every bundled module; do not preload that list or the complete library.

## Module runtime

This skill ships executable helpers that belong to its own modules. Run them with Python from the root of the project you are working in, using their path inside this installed skill; `--help` lists every command. They keep their state in that project, never in this package, and use only the Python standard library. Each ships with the tests that passed before this release was built.

- `library/agent-kit/coordination/runtime/agentkit.py` (module `agent-kit/coordination`)

Read `library/agent-kit/coordination/runtime/README.md` before the first use of that runtime.

## License and attribution

Keep `LICENSE.md`, `NOTICE.md`, `TRADEMARKS.md`, and `LICENSES/` with this release. The vendored Python helpers and any module runtime code under `library/**/runtime/` are AGPL-3.0-or-later; the Skill instructions, knowledge, declarative profile, memory, and original assets are CC-BY-SA-4.0 unless a shipped file states otherwise.
