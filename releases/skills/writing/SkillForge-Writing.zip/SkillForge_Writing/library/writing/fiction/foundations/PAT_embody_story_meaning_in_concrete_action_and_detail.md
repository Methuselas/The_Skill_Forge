---
object_id: PAT_embody_story_meaning_in_concrete_action_and_detail
object_type: pattern
name: Embody Story Meaning in Concrete Action and Detail
library_path:
- writing
- fiction
- foundations
stage_binding: 2 block
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags:
- fiction
- meaning
- theme
- concrete_detail
- dramatic_action
cross_links:
- rel: related_to
  target_object_id: PAT_replace_abstractions_with_specific_sensory_images
- rel: related_to
  target_object_id: PAT_balance_symbols_between_cliche_and_obscurity
- rel: related_to
  target_object_id: PAT_use_specific_sensory_details_to_imply_larger_conditions
- rel: related_to
  target_object_id: PAT_reveal_character_incrementally_through_behavior
reference:
  source_title: "Creative Writing: A Workbook with Readings"
  author: Linda Anderson
confidence: high
references: []
variants:
- variant_id: writing_fiction_variant_make_literal_mechanics_generate_meaning
  variant_name: Make Literal Mechanics Generate Meaning
  variant_basis: method_sequence
  difference_from_foundation: Choose a real physical, technical, bodily, occupational, ritual, or procedural system
    whose actual constraints can enact the thematic relation, then let meaning emerge from what characters must
    literally do before explaining the abstraction.
  when_to_use: Work, craft, technology, ritual, bodily process, environment, or another concrete procedure is central
    enough that its mechanics can change decisions and carry thematic pressure at the same time.
  when_not_to_use: The procedure exists only to illustrate a thesis, its mechanics are inaccurate or irrelevant to the
    action, or explanation would overwhelm the human situation the process is supposed to intensify.
  absorbed_from_object_id: none
---

# Embody Story Meaning in Concrete Action and Detail

## Pattern Rule
**IF** a fiction draft states its issue, judgment, emotion, or moral position more strongly than readers can experience it through the story
**THEN** relocate the consequential meaning into particular characters, behavior, speech, sensory evidence, objects, and outcomes whose interaction lets readers encounter and infer it
**ELSE** retain direct reflection only where the narrator's act of interpretation is itself part of the dramatic experience

## Do
- Begin with a specific person in a specific human situation whose choices can test the story's larger pressure.
- Give emotion a body through attention, gesture, sensation, altered routine, speech, silence, or material consequence.
- Select details that belong literally in the scene and also change how readers understand character, relation, or action.
- Let an object or image gather meaning through use, ownership, recurrence, and consequence before treating it as symbolic.
- Preserve contradiction among evidence so the experienced meaning can exceed a one-sentence lesson.
- Use private statements about theme as revision hypotheses, then test whether the enacted story supports, complicates, or refuses them.

## Don't
- Substitute an abstract problem for people whose particular conduct makes the problem dramatic.
- Add sensory detail as decoration after the thesis has already told readers what to conclude.
- Explain what an image symbolizes before its literal role and accumulated context can carry resonance.
- Make every detail represent the same idea and flatten the story into an illustration.
- Remove all narrator judgment when the telling consciousness is one of the story's concrete human forces.

## Checklist
- The story's central pressure is available through enacted evidence, not only an explanatory statement.
- Consequential emotions and judgments have specific behavioral, sensory, verbal, or material expression.
- Retained details perform literal work before or while they accumulate further meaning.
- Readers have room to connect evidence without being forced toward one abstract paraphrase.
- The ending completes or deepens the experienced meaning through action, image, relation, or changed perception.
- Cutting the thematic explanation does not make the story meaningless; if it does, the enactment needs more work.

## Notes
Fiction can contain beliefs, arguments, and moral judgment, but its distinctive force comes from making them experienceable. Concrete detail is not opposed to thought: selection and viewpoint make every observed fact an act of judgment. Meaning becomes durable when the story's literal surface remains convincing while actions and details accumulate implications that no detached summary can fully replace.

`writing_fiction_variant_make_literal_mechanics_generate_meaning` begins with the literal system rather than an abstract analogy. Understand what the procedure physically requires, where it creates dependence, danger, timing, resistance, coordination, or limitation, and let characters encounter those constraints in action. The thematic relation should be discoverable in the mechanics themselves before narration decodes it. Add reflection only when the character's act of interpretation creates a further turn instead of restating what the process has already made experienceable.
