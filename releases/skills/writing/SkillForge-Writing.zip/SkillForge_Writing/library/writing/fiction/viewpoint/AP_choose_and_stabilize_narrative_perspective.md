---
object_id: AP_choose_and_stabilize_narrative_perspective
object_type: ap
name: Choose and Stabilize Narrative Perspective
library_path:
  - writing
  - fiction
  - viewpoint
stage_binding: 0 design
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags:
  - fiction
  - point_of_view
  - tense
  - narrator
  - style
cross_links:
  - rel: supports
    target_object_id: PAT_choose_point_of_view_by_access_distance_and_effect
  - rel: supports
    target_object_id: PAT_design_the_first_person_telling_situation
  - rel: supports
    target_object_id: PAT_use_alternating_first_person_narrators_to_complicate_interpretation
  - rel: supports
    target_object_id: PAT_keep_point_of_view_knowledge_and_access_consistent
  - rel: supports
    target_object_id: PAT_design_unreliable_narration_with_readable_evidence
  - rel: supports
    target_object_id: PAT_choose_tense_by_visibility_and_temporal_effect
  - rel: supports
    target_object_id: PAT_shape_style_as_response_to_story_situation
  - rel: supports
    target_object_id: PAT_render_stream_of_consciousness_in_controlled_bursts
  - rel: supports
    target_object_id: PAT_structure_multiple_viewpoint_narratives_by_function_and_orientation
  - rel: supports
    target_object_id: PAT_filter_setting_through_character_consciousness
  - rel: related_to
    target_object_id: DRILL_redraft_passage_across_point_of_view_and_tense
  - rel: related_to
    target_object_id: DRILL_build_a_peripheral_witness_account_from_mixed_knowledge_routes
  - rel: related_to
    target_object_id: DRILL_map_a_multiple_viewpoint_timeline_and_rotation
reference:
  source_title: "Creative Writing: Four Genres in Brief"
  author: David Starkey
confidence: high
references: []
variants: []
---

# Choose and Stabilize Narrative Perspective

## Objective
Establish a fiction narrator, point of view, tense, and responsive style that grant the story its necessary access and reader relation without accidental knowledge leaks or unmotivated shifts.

## Steps / Flow
1. **Name the telling pressure.** State what event is being told, who could need to tell it now, what readers must eventually know, and what should remain partial or uncertain. Preserve the story's central event and required revelation as invariants. **Advance gate:** the telling has a reason beyond reporting that events occurred.
2. **Choose access and distance.** Activate `PAT_choose_point_of_view_by_access_distance_and_effect`. Separate focal owner, grammatical person, teller role, access range, distance, timing, address, and reliability rather than changing the whole bundle at once. Compare at least one close singular position with any collective, direct-address, omniscient, or exterior-only option the design plausibly supports. If several characters could plausibly own the close position, run the **Compare Plausible Focal Owners of One Event** variant of `DRILL_redraft_passage_across_point_of_view_and_tense` with event, facts, sequence, person, and tense held constant. If the focal owner and access are settled but first person and third-person limited remain plausible, run the drill's **Compare First Person and Third-Person Limited around One Focal Character** variant without changing tense or character identity. If objective third person wins, require selected action, dialogue, silence, objects, and consequences to make the central pressure inferable without private thought. If omniscience wins, establish the governing voice, permitted movement across selected minds, places, and times, focal set, transition logic, degree of interpretation, reader relation, and either an intentional identity or intentional anonymity. Use the **Personify Omniscience through Bounded Impossible Access** variant when embodiment supplies the access mechanism, and **Use Omniscient Reader Address as Governing Commentary** when direct commentary supplies a necessary reader effect. If first person wins, activate `PAT_design_the_first_person_telling_situation` and establish whether the narrator participates centrally or witnesses another person's story, who receives the account, how long after the events it is told, and why it is told now. When the speaker is settled but the listener, occasion, or elapsed time is not, run the drill's **Compare First-Person Telling Situations** variant without introducing unreliability as a substitute for those choices. If no narrator can possess necessary information, change the information route or choose a broader controlled access before drafting. **Advance gate:** the chosen position credibly governs access, address, inference, and hindsight beyond the opening, and any added complexity preserves a named effect that a simpler position loses.
3. **Decide whether one account is enough.** Activate the **Build a Bounded Multiple-Viewpoint Roster** variant of `PAT_choose_point_of_view_by_access_distance_and_effect` only when no single account can supply the necessary access, contrast, social field, or productive uncertainty. Give every proposed viewpoint a distinct narrative job, remove it provisionally, and keep it only when the story loses something necessary. For competing first-person versions, activate `PAT_use_alternating_first_person_narrators_to_complicate_interpretation`; for alternating third-person access, activate the **Signal Alternating Third-Person Focalization** variant of `PAT_keep_point_of_view_knowledge_and_access_consistent`. If several accounts remain, activate `PAT_structure_multiple_viewpoint_narratives_by_function_and_orientation`, choose the topology by function rather than symmetry, and run `DRILL_map_a_multiple_viewpoint_timeline_and_rotation` to expose chronology, gaps, clusters, allocation, and transition cues. Permit mixed narrative forms only when each account retains a legible voice and knowledge contract. **Advance gate:** every retained viewpoint survives removal testing, the presented sequence rests on a coherent chronology, and readers can identify each new access position before private knowledge depends on it. Otherwise keep one account, and reduce voices or repeated events when orientation cost exceeds the contribution.
4. **Write the knowledge contract.** Activate `PAT_keep_point_of_view_knowledge_and_access_consistent`. Record what each narrator can perceive, remember, learn through named testimony or records, infer, reconstruct openly, and never directly know, plus how any deliberate transition will be signaled. When a peripheral witness depends on offstage reports or reconstruction, run `DRILL_build_a_peripheral_witness_account_from_mixed_knowledge_routes` and update the contract from the completed claim audit. For omniscience, record the active focal set, allowed reach, prohibited reach, narrator interpretation, and the signals that distinguish governed movement from accidental head-hopping. For alternating third-person focalization, establish the active set and relocate at a visible boundary before the new private access begins. **Advance gate:** every indispensable fact has a credible route into the telling, reconstruction is legible before unsupported precision appears, and every access change is legible before it occurs.
5. **Choose the temporal stance.** Activate `PAT_choose_tense_by_visibility_and_temporal_effect`. Decide whether events are remembered, unfolding, or projected and how much attention the tense should attract. Route a need for hindsight back to past narration or an explicit later frame rather than leaking future knowledge into an unframed present.
6. **Calibrate trust.** If a narrator misreads, conceals, or fabricates, activate `PAT_design_unreliable_narration_with_readable_evidence`; otherwise keep ordinary limitations without manufacturing suspicion. **Advance gate:** readers can tell whether a contradiction belongs to a narrator or to an uncontrolled draft.
7. **Shape the verbal surface.** Activate `PAT_shape_style_as_response_to_story_situation` and `PAT_filter_setting_through_character_consciousness`. Choose whether necessary thought appears as tagged or typographically marked direct language, unmarked direct language, reported thought, or free indirect style according to the intended distance, voice, emphasis, attribution load, and continuity with surrounding prose. When the choice remains uncertain, use the **Compare One Interior Passage across Thought-Presentation Modes** variant of `DRILL_redraft_passage_across_point_of_view_and_tense` while holding event, viewpoint, tense, and information constant. When acute pressure needs associative mental movement, activate `PAT_render_stream_of_consciousness_in_controlled_bursts` and return the burst to external action before orientation or pace collapses. Let vocabulary, syntax, paragraph movement, and noticed details arise from the established teller, addressee, and current pressure. Route generic description back to the knowledge contract and focal attention.
8. **Stress-test the choice.** Use `DRILL_redraft_passage_across_point_of_view_and_tense` on an opening or turn, changing only the unresolved controls when a targeted variant applies. Treat drafting ease, immediate affinity, novelty, and a striking opening as discovery signals rather than verdicts; compare sustained access, blind spots, revelation control, voice, and maintenance cost. If an alternate version delivers necessary access or pressure more economically, migrate the whole passage and update the contract; do not patch the old version with isolated perspective leaks.
9. **Audit and complete.** Mark every private thought, its owning consciousness, its presentation mode, every time shift, and every claim unavailable through direct perception. Repair unexplained access changes, ambiguous thought ownership, accidental toggles between spoken and unspoken language, unsupported typographic conventions, tense drift, addressee discontinuity, redundant accounts, or voice instability. Stop when the chosen perspective earns its costs, every essential fact arrives credibly, deliberate uncertainty remains readable, and style changes with situation without losing each governing voice.

## Notes
Perspective is a coordinated design, not a pronoun setting. Point of view establishes access and distance; tense establishes the relation between event and telling; style makes those choices perceptible sentence by sentence. Short forms usually benefit from fewer transitions because each relocation consumes scarce space, but a conspicuous or broad perspective remains valid when its effect is central and consistently controlled.
