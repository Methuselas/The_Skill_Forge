---
object_id: PAT_interrogate_memory_before_claiming_precision
object_type: pattern
name: Interrogate Memory Before Claiming Precision
library_path:
  - writing
  - creative-nonfiction
  - foundations
stage_binding: 3 rough
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: PAT_preserve_factual_accountability_while_using_literary_craft
tags:
  - creative_nonfiction
  - memory
  - reconstruction
  - self_scrutiny
  - accuracy
cross_links:
  - rel: related_to
    target_object_id: PAT_choose_truth_contract_before_shaping_real_material
  - rel: related_to
    target_object_id: PAT_make_personal_presence_part_of_inquiry
reference:
  source_title: "Creative Writing: Four Genres in Brief"
  author: David Starkey
confidence: high
references: []
variants:
  - variant_id: writing_creative_nonfiction_variant_paraphrase_or_summarize_uncertain_speech
    variant_name: Paraphrase or Summarize Uncertain Speech
    variant_basis: method_sequence
    difference_from_foundation: Replace unsupported verbatim reconstruction with clearly mediated paraphrase or concise summary that preserves the remembered substance without claiming exact wording.
    when_to_use: A conversation matters to the essay but elapsed time, lack of recording, or incomplete recall makes direct quotation implausibly precise.
    when_not_to_use: Exact wording was recorded or is distinctly remembered and its voice, rhythm, or phrasing carries necessary meaning.
    absorbed_from_object_id: none
  - variant_id: writing_creative_nonfiction_variant_research_own_life_as_external_subject
    variant_name: Research Your Own Life as an External Subject
    variant_basis: method_sequence
    difference_from_foundation: Approach one slice of personal history as a reporting problem by interviewing other participants, consulting records and artifacts, and drafting from the resulting distance.
    when_to_use: Familiarity, self-protection, or one dominant recollection prevents the writer from seeing competing accounts and concrete evidence.
    when_not_to_use: The material is too private or unsafe to investigate through other people, or the inquiry depends only on a clearly framed present response rather than historical precision.
    absorbed_from_object_id: none
  - variant_id: writing_creative_nonfiction_variant_trace_later_inputs_that_construct_memory
    variant_name: Trace Later Inputs That Construct a Memory
    variant_basis: method_sequence
    difference_from_foundation: Reconstruct the memory's history by separating the earliest available recollection from photographs, family stories, repeated retellings, later knowledge, present sensory triggers, and imaginative rehearsal that may have supplied or altered its detail.
    when_to_use: A vivid or frequently retold memory may owe part of its imagery, sequence, or certainty to material encountered after the event.
    when_not_to_use: The claim is already bounded and well supported, or tracing the memory's development would expose another person unnecessarily without affecting the work's responsible precision.
    absorbed_from_object_id: none
---

# Interrogate Memory Before Claiming Precision

## Pattern Rule
**IF** a personal essay presents distant, emotionally charged, or unusually exact remembered material that desire, shame, repetition, or elapsed time may have reshaped
**THEN** test the recollection for self-serving change, distinguish secure memory from reconstruction, and qualify the account wherever its precision exceeds responsible confidence
**ELSE** retain confident particulars when their basis remains strong enough for the claim being made

## Do
- Ask what the remembering self would prefer to have happened and whether that preference has cleaned up motive, conduct, dialogue, or consequence.
- Compare the account with diaries, messages, photographs, records, physical facts, or other participants' memories when those are available and consequential.
- Build a chronology of later influences when photographs, repeated stories, rehearsal, cultural knowledge, or subsequent experiences may have entered the recollection; vividness can increase through repetition without increasing accuracy.
- Classify consequential material as direct memory, another person's report, inference, unconscious impression, reconstruction, or invention; preserve that status when turning notes into fluent prose.
- Separate a distinctly remembered remark from dialogue rebuilt only to convey the substance of an exchange.
- Use direct quotation selectively when wording is supportable; otherwise shift to paraphrase or summary before invented precision becomes part of the scene.
- Identify whether a scene happened once, recurred in similar forms, or combines material from several occasions, then make that status legible where it affects trust.
- Keep difficult or embarrassing evidence when removing it would protect the narrator at the cost of an honest account.

## Don't
- Treat vividness, present tense, or minute-by-minute narration as proof that a recollection is accurate.
- Assume every remembered detail is equally dependable because the central event certainly occurred.
- Convert emotional truth into exact invented actions or quotations and present them without qualification.
- Dismiss another participant's conflicting memory merely because the essay centers the writer's viewpoint.
- Treat a family story, repeated account, dream, bodily impression, or image arising from the unconscious as recovered factual memory without independent support.
- Hedge so broadly that readers cannot tell what the writer believes occurred.

## Checklist
- The degree of narrative precision matches the available memory and supporting evidence.
- Wishes, defenses, shame, and later knowledge have been considered as possible sources of distortion.
- Repeated, composite, and reconstructed material is not presented as one verbatim occasion without a responsible signal.
- Readers can distinguish exact remembered or recorded words from the narrator's rendering of their substance.
- Conflicting accounts are acknowledged when they materially change interpretation.
- Report, inference, reconstruction, and unconscious impression remain distinguishable from direct recollection and verified fact.
- Consequential details imported or reinforced by later photographs, stories, rehearsal, or knowledge remain distinguishable from the earliest available recollection.
- The narrator's subjectivity remains visible without becoming a license to fabricate.

## Notes
Memory supplies a personal perspective rather than a neutral recording. Its selectivity can produce meaning, but it can also revise the past toward comfort, coherence, or self-protection. Self-scrutiny therefore asks more than whether a scene feels true: it asks which details are remembered, which are inferred, which can be checked, and which version the narrator is motivated to prefer. Qualification should expose the real limit without draining the account of every usable conviction.

`writing_creative_nonfiction_variant_paraphrase_or_summarize_uncertain_speech` preserves a consequential conversation without pretending to recover a transcript. Use paraphrase when the substance and character of a shorter utterance matter, and summary when the outcome of a longer exchange matters more than its verbal texture. Recorded or distinctly remembered phrases may remain direct quotations, but long dialogue from the distant past should not gain false authority merely because quotation marks make a scene more immediate.

`writing_creative_nonfiction_variant_research_own_life_as_external_subject` interrupts the authority granted automatically to familiar autobiography. Interview family, friends, or other participants; examine photographs, messages, journals, and records; then write a bounded slice as though the subject were another person whose account must be investigated. Use the distance to expose competing memories and overlooked facts, not to deny that the writer still selects and interprets the evidence.

`writing_creative_nonfiction_variant_trace_later_inputs_that_construct_memory` treats a recollection as something with a history rather than as one unchanged recording. Establish the earliest version still available, then mark details that first appear after a photograph, family account, repeated performance, later explanation, similar event, or present sensory trigger. A later element may carry genuine emotional or interpretive importance, but its intensity does not convert it into direct perception from the original event.
