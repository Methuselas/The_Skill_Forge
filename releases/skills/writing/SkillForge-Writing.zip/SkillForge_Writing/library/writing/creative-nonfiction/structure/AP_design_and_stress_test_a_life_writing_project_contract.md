---
object_id: AP_design_and_stress_test_a_life_writing_project_contract
object_type: ap
name: Design and Stress-Test a Life-Writing Project Contract
library_path:
  - writing
  - creative-nonfiction
  - structure
stage_binding: 0 design
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags:
  - creative_nonfiction
  - life_writing
  - project_design
  - biography
  - autobiography
  - evidence
cross_links:
  - rel: supports
    target_object_id: PAT_choose_subject_for_open_ended_exploration
  - rel: supports
    target_object_id: PAT_make_personal_presence_part_of_inquiry
  - rel: supports
    target_object_id: PAT_choose_truth_contract_before_shaping_real_material
  - rel: supports
    target_object_id: PAT_preserve_factual_accountability_while_using_literary_craft
  - rel: supports
    target_object_id: PAT_verify_checkable_facts_and_research_necessary_context
  - rel: supports
    target_object_id: PAT_audit_harm_and_privacy_when_portraying_real_people
  - rel: supports
    target_object_id: PAT_choose_structure_from_discovered_connections
  - rel: supports
    target_object_id: PAT_calibrate_context_to_intended_audience_and_venue
  - rel: related_to
    target_object_id: AP_draft_and_revise_short_creative_nonfiction
  - rel: related_to
    target_object_id: DRILL_audition_fragmented_connected_and_through_line_orders
  - rel: related_to
    target_object_id: DRILL_recast_a_life_writing_event_across_tense_and_narrator_distance
  - rel: related_to
    target_object_id: DRILL_compare_associative_and_narrative_recall_of_one_event
  - rel: related_to
    target_object_id: DRILL_interrogate_a_photograph_as_bounded_evidence
  - rel: related_to
    target_object_id: DRILL_audit_a_diary_across_entry_revision_and_publication_layers
  - rel: related_to
    target_object_id: DRILL_build_an_attributed_documentary_montage_without_faking_voices
  - rel: supports
    target_object_id: PAT_derive_a_personal_essay_theme_from_recurring_life_evidence
reference:
  source_title: "Creative Writing: A Workbook with Readings"
  author: Linda Anderson
confidence: high
references: []
variants: []
---

# Design and Stress-Test a Life-Writing Project Contract

## Objective
Create a revisable design contract for a biographical or autobiographical project that coordinates its inquiry, scope, narrator position, evidence, ethics, form, circulation, and reader promise, then test that contract against actual material before it hardens into a misleading declaration.

## Steps / Flow
1. **Choose one workable life and inquiry.** Activate `PAT_choose_subject_for_open_ended_exploration`. Decide whose life or bounded portion of a life the project examines, distinguish biography from autobiography or another named life-writing form, and state a question the available material may genuinely change. Narrow a whole-life ambition to a period, relationship, practice, conflict, place, or recurring pressure when total coverage would produce only inventory. **Advance gate:** the subject and temporal or thematic boundary are concrete, and the answer is not predetermined.
2. **Audit motives and the reader promise.** Run `DRILL_audit_life_writing_motives_and_reader_promises`. Name the memorial, investigative, corrective, expressive, artistic, commercial, or other motives that govern real choices; expose conflicts among them; and state what experience the work promises readers. Treat competitive distinction as a scope test rather than a demand for novelty. **Advance gate:** each retained motive changes selection, method, or audience, and none is being used to certify truth.
3. **Position the narrator in relation to the subject.** Activate `PAT_make_personal_presence_part_of_inquiry`; for biography, use `writing_creative_nonfiction_variant_declare_biographer_relationship_and_distance`. Identify personal history, access, expertise, admiration, grief, conflict, cultural position, and prior beliefs that shape attention. Choose a central, shared, peripheral, or offstage presence appropriate to the inquiry. **Position gate:** readers could understand what connects this writer to this subject and where that connection creates both access and limitation.
4. **Set the truth contract and evidence architecture.** Activate `PAT_choose_truth_contract_before_shaping_real_material` to decide whether the project claims accountability to evidence or permits invention, then activate `PAT_preserve_factual_accountability_while_using_literary_craft` for the accountable branch. Inventory direct memory, observation, interviews, records, correspondence, artifacts, prior accounts, inference, reconstruction, dispute, and unknowns. Then activate `PAT_verify_checkable_facts_and_research_necessary_context` to test source quality, archive asymmetry, missing voices, and research tasks; use `writing_creative_nonfiction_variant_weight_competing_accounts_by_position_evidence_and_consequence` when versions of the same event differ materially. When a photograph carries a consequential event or gap, run `DRILL_interrogate_a_photograph_as_bounded_evidence`; when a remembered episode already arrives as a smooth story, run `DRILL_compare_associative_and_narrative_recall_of_one_event` to expose omitted material and implied causality. For a documentary assembly, run `DRILL_build_an_attributed_documentary_montage_without_faking_voices` before dramatic arrangement makes source classes difficult to recover. Define how speculation and reconstruction will be signaled. If a counterfactual or hybrid branch permits invention, activate `writing_variant_signal_counterfactual_or_hybrid_fiction_before_borrowing_factual_authority` and separate that branch from the nonfiction contract. **Evidence gate:** central claims have supportable routes, and no structural promise depends on an absence being filled by invention.
5. **Choose the governing scope and wider stakes.** State what the project includes, what it deliberately excludes, and why those boundaries form a meaningful whole rather than a convenience. For autobiography that reaches beyond private experience, use `writing_creative_nonfiction_variant_widen_personal_experience_without_claiming_universality` to connect the particular life to supported larger conditions while preserving difference. Reject a broad theme that the selected evidence cannot demonstrate. **Scope gate:** the project can say why these events matter without claiming to represent every comparable life.
6. **Audit people, privacy, and circulation.** Activate `PAT_audit_harm_and_privacy_when_portraying_real_people`. List identifiable people, permissions actually granted, foreseeable harms, third-party effects, and the difference between private drafting and plausible later circulation. Decide whether consultation, identity protection, professional review, a narrower venue, or a changed form is required. **Ethics gate:** cooperation, fame, death, access, or writer ownership of the experience is not serving as blanket clearance.
7. **Choose and audition form and delivery conditions.** Decide whether prose, poetry, a sequence, a documentary assembly, an addressed form, or another form can carry the evidence and inquiry without confusing its factual status. Activate `PAT_choose_structure_from_discovered_connections` to test where the project belongs on the continuum from connected narrative to purposeful segmentation. When the order remains uncertain, run `DRILL_audition_fragmented_connected_and_through_line_orders`; when tense or narrator distance changes the implied knowledge, run `DRILL_recast_a_life_writing_event_across_tense_and_narrator_distance`. For a diary, journal, letter, or other apparently private form, run `DRILL_audit_a_diary_across_entry_revision_and_publication_layers` to distinguish the stated recipient, implied reader, entry-time knowledge, later additions, external editing, anticipated publication, and plausible later circulation. For travel writing, use `writing_creative_nonfiction_variant_declare_traveler_position_and_limits` when the journey creates both access and apparent authority. Activate `PAT_calibrate_context_to_intended_audience_and_venue` to name the intended readers, necessary context, genre signals, secondary circulation, and venue constraints. **Form gate:** competing samples show that the selected form, structure, temporal stance, and destination preserve the truth contract and give every plausible reader the required footing without flattening productive gaps.
8. **Write the working contract.** In a compact statement, record the subject, active inquiry, motives, scope, narrator position, subject relationship, evidence classes, research gaps, reconstruction rules, ethical constraints, form, readership, and promised experience. Phrase uncertain choices as decisions to test, not claims that a future manuscript has already fulfilled. Do not use the statement as a disclaimer for conduct the contract itself forbids.
9. **Stress-test the declaration against material.** Draft or select two contrasting sample passages: one where the planned method works and one where evidence, distance, privacy, or form strains it. Mark every place where the samples contradict the contract, then revise the contract or abandon the unsuitable passage rather than concealing the mismatch. **Advance gate:** the project can produce actual material without breaking its factual or ethical promises.
10. **Reopen the contract at named milestones.** Recheck it after substantial research, the first complete section, structural revision, and any change in audience or circulation. Update scope, methods, and risks when discovery requires it, while preserving a record of unresolved questions inside the working materials rather than presenting an obsolete declaration to readers. Move into drafting when no known design contradiction blocks the next bounded unit of work.

## Notes
The contract is useful because life writing makes interdependent decisions before prose can solve them locally. Narrator position changes access; archive gaps constrain scope; a wider theme changes research; intended circulation changes privacy risk; and form changes what readers infer as fact. A preface or proposal may eventually draw on the contract, but a public statement should describe the manuscript that actually exists. Neither intentions, credentials, subject cooperation, nor disclosure of method can absolve unsupported claims or avoidable harm.
