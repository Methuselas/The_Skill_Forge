---
object_id: DRILL_compare_full_and_slant_rhyme_across_parallel_drafts
object_type: drill
name: Compare Full and Slant Rhyme Across Parallel Drafts
library_path: [writing, poetry, sound]
stage_binding: 2 block
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags: [poetry, rhyme, slant_rhyme, comparison, deliberate_practice]
cross_links:
  - rel: teaches
    target_object_id: PAT_make_rhyme_serve_sense_and_effect
reference: {source_title: "Creative Writing: A Workbook with Readings", author: W. N. Herbert}
confidence: high
references: []
target_skill: Choosing rhyme distance and distribution by semantic and tonal effect
variants: []
---

# Compare Full and Slant Rhyme Across Parallel Drafts

## Practice Task
Draft two related incidents, revise one through close rhyme and the other through distant correspondence, then compare what each sound field permits and distorts.

## Target Skill
Choosing rhyme distance and distribution by semantic and tonal effect.

## Setup
Choose two journeys, memories, or events with a meaningful parallel. Draft each in plain lines before selecting three or four key words.

## Instructions
1. Build close-rhyme fields for the first draft and wider slant fields for the second.
2. Revise without requiring rhyme at line endings or using every candidate.
3. Map where correspondences cluster, spread, approach, or recede.
4. Read both aloud and mark closure, surprise, texture, filler, and distorted syntax. Document each rejected match beside the craft failure that rejected it, so the field records why a candidate lost rather than only that it did.
5. Keep, loosen, redistribute, or remove sound according to the better fit for each incident.

## Success Check
- Both drafts retain the precise details of their incidents, so what is being compared is sound rather than content.
- Neither draft places correspondence at every line ending, and neither uses every candidate its field offered.
- The mapped distribution shows clustering, spread, approach, or recession rather than an even scatter.
- The audible difference is described as a difference in movement, not assigned a mood the rhyme is assumed to carry.
- Rejected matches are documented by the craft failure that rejected them — distorted syntax, filler, false closure.
- Each draft's final treatment of sound is chosen for its own incident, rather than one approach preferred across both.

## Common Failures
- Making the subjects so different that sound cannot be isolated.
- Equating full rhyme with simplicity and slant rhyme with depth.
- Keeping an attractive match that degrades sense.

## Notes
Parallel material turns a general preference into a comparison. The exercise tests degrees and placement of correspondence, not which rhyme class is universally superior.
