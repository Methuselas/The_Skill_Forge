---
object_id: DRILL_build_poem_around_productive_comparison
object_type: drill
name: Build a Poem Around a Productive Comparison
library_path:
  - writing
  - poetry
  - imagery
stage_binding: 1 skeleton
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags:
  - poetry
  - metaphor
  - simile
  - figurative_language
  - deliberate_practice
cross_links:
  - rel: teaches
    target_object_id: PAT_make_figurative_language_unexpected_and_fitting
  - rel: related_to
    target_object_id: PAT_replace_abstractions_with_specific_sensory_images
  - rel: related_to
    target_object_id: DRILL_transfer_a_comparison_across_unrelated_subjects
reference:
  source_title: "Creative Writing: Four Genres in Brief"
  author: David Starkey
confidence: high
references: []
target_skill: Developing an unexpected but fitting comparison into an organizing poetic structure
variants: []
---

# Build a Poem Around a Productive Comparison

## Practice Task
Draft or substantially revise a short poem so one central metaphor or simile generates its images, movement, and internal order.

## Target Skill
Developing an unexpected but fitting comparison into an organizing poetic structure.

## Setup
Choose a subject currently expressed in flat, abstract, or uninspiring language. On a separate page, leave room to identify the subject, possible comparison terms, and the specific connections each one offers.

## Instructions
1. Describe the subject literally in a few precise words so the exercise begins from what must be revealed rather than from a decorative image.
2. Generate several possible comparison terms. Write the automatic stock likenesses down before rejecting them: a list that never records them cannot show they were considered and passed over rather than never reached.
3. For each candidate, list the credible similarities and the productive differences between it and the subject.
4. Select the connection that is both least predictable and most revealing; discard novelty that cannot remain fitting.
5. Draft the poem around that relation, allowing different implications of the comparison to shape images, turns, and sequence.
6. Replace lines that merely repeat the original likeness with lines that extend, complicate, or test it.
7. Read the draft once for literal coherence and once for figurative force, then remove any line that explains the comparison more fully than the poem needs.

## Success Check
- The literal description exists first, so the poem begins from what must be revealed rather than from an image already liked.
- The first stock likenesses are written down and rejected, rather than avoided by never recording them.
- Each candidate lists both credible similarities and productive differences. A candidate with only similarities has not been examined.
- The selected comparison is the least predictable that remains fitting, and novelty that cannot stay fitting is discarded by that test.
- Images, turns, and sequence come from implications of the relation rather than from restatements of it.
- The poem holds for a reader who never sees the literal description.

## Common Failures
- Choosing the first available vehicle because it already carries a conventional meaning.
- Building a clever comparison whose qualities do not match the actual subject.
- Repeating one likeness in new wording instead of discovering further implications.
- Explaining the metaphor until the reader has no associative work left to do.
- Abandoning literal coherence when the figure begins to generate attractive language.

## Notes
A central comparison can provide more than a striking line: its implications can give a poem integral order. The rep trains selection as much as invention. Multiple candidates expose the difference between mere novelty and the rarer bridge that is unexpected, credible, and fertile enough to sustain development.
