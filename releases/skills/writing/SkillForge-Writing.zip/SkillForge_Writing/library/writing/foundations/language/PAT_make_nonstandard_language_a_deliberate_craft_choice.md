---
object_id: PAT_make_nonstandard_language_a_deliberate_craft_choice
object_type: pattern
name: Make Nonstandard Language a Deliberate Craft Choice
library_path:
- writing
- foundations
- language
stage_binding: 3 rough
lane_fit: skill
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- language
- dialect
- multilingual_writing
- grammar
- voice
cross_links:
- rel: related_to
  target_object_id: DRILL_audit_marked_character_speech_for_individuality_accuracy_and_legibility
reference:
  source_title: 'Creative Writing: Four Genres in Brief'
  author: David Starkey
confidence: high
references: []
variants:
- variant_id: writing_variant_design_invented_language_as_constraint_system
  variant_name: Design Invented Language as a Constraint System
  variant_basis: constraint
  difference_from_foundation: For fictional or institutional language, design not only surface vocabulary but what
    morphology, semantic range, abbreviation, taboo, register, and distribution make easy, difficult, prestigious,
    automatic, ambiguous, or unavailable, then let those constraints affect conduct or inference.
  when_to_use: A constructed vocabulary, professional jargon, institutional register, or invented linguistic system
    should participate in worldbuilding, power, cognition, social membership, or plot rather than serve as decorative
    terminology.
  when_not_to_use: The language difference is a living community variety the writer is treating as a fictional control
    system, or the invented rules create no consequence beyond making the setting sound unusual.
  absorbed_from_object_id: none
---

# Make Nonstandard Language a Deliberate Craft Choice

## Pattern Rule
**IF** fragments, dialect, multilingual wording, or unconventional grammar serve an intended voice, character, heritage, rhythm, or rhetorical effect
**THEN** retain and shape those departures consciously while editing the surrounding text with full attention to language
**ELSE** correct the deviation as an accidental error

## Do
- Identify the precise expressive job performed by each departure from standard written convention.
- Distinguish standardized written convention from speech itself: every speaker has an accent, dialect, register, and language history, even when the page does not mark them conspicuously.
- Let community language and mixed languages carry identity when standardization would erase meaningful social or cultural information.
- Use dialect, community language, and multilingual wording that the writer or represented speaker genuinely knows; when access is partial, research spelling, meaning, context, present use, internal variation, and listener-dependent register through more than one credible perspective before relying on it.
- Audit which speakers receive ordinary spelling and which receive respelling, glosses, grammar labels, translation, or comic framing; revise asymmetry that exists only because one voice is treated as the neutral baseline.
- Preserve scripts, diacritics, pronunciation cues, and translations accurately enough that the language remains itself rather than decorative texture.
- Decide whether meaning should be inferable from context, supplied nearby, or deliberately disclosed later, and test the timing against the intended reader experience.
- Polish syntax, diction, punctuation, and rhythm around the deviation so readers encounter a controlled choice rather than general carelessness.

## Don't
- Normalize identity-bearing language solely because it differs from standardized English.
- Put on an accent, borrow an unfamiliar community marker, or scatter untranslated words to manufacture authenticity or exotic atmosphere.
- Treat a community's systematic grammar as failed standardized English, or turn code-switching and imperfect fluency into automatic evidence of intelligence, honesty, innocence, or social worth.
- Use creativity as an excuse to submit an unrevised draft full of unintended spelling, grammar, or punctuation mistakes.

## Checklist
- Each unconventional construction has a defensible purpose in the work.
- Similar choices are controlled well enough to read as intentional rather than random.
- The intended audience can follow the passage, unless temporary difficulty is itself part of the designed effect.
- The writer can account for the language's meaning and use without treating surface difference as proof of authority.
- Conspicuous marking is distributed by craft purpose rather than by an unexamined standard-versus-deviant hierarchy.
- The rest of the prose has received careful editing and proofreading.

## Notes
Experimental writers do not discard language craft; they depend on it. Fragments and nonstandard speech can represent character, spoken rhythm, region, class, or multilingual experience, while a clean surrounding text establishes that those choices are purposeful. Language is the writer's medium, so freedom and control reinforce rather than cancel one another.

`writing_variant_design_invented_language_as_constraint_system` applies to fictional or institutional language designed by the writer. Decide what its forms make easy, difficult, automatic, prestigious, taboo, ambiguous, or unavailable, and let those consequences enter behavior or inference. Keep this distinct from real community dialects and multilingual usage: a living language variety is not a deficient thought system and should not be treated as one for worldbuilding convenience.
