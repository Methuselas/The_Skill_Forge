---
object_id: DRILL_cast_and_recast_natural_syntax_into_iambic_pentameter
object_type: drill
name: Cast and Recast Natural Syntax into Iambic Pentameter
library_path: [writing, poetry, rhythm]
stage_binding: 2 block
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags: [poetry, iambic_pentameter, meter, syntax, deliberate_practice]
cross_links:
  - rel: teaches
    target_object_id: PAT_scan_and_vary_meter_deliberately
reference: {source_title: "Creative Writing: A Workbook with Readings", author: W. N. Herbert}
confidence: high
references: []
target_skill: Recasting ordinary phrasing into audible five-beat iambic lines without distorting voice or syntax
variants: []
---

# Cast and Recast Natural Syntax into Iambic Pentameter

## Practice Task
Preserve the meaning of ordinary sentences while repeatedly rephrasing them into audible five-beat iambic lines, then test controlled variations without sacrificing natural speech.

## Target Skill
Recasting ordinary phrasing into audible five-beat iambic lines without distorting voice or syntax.

## Setup
Choose one awkwardly phrased factual sentence and five plain statements about familiar actions. Keep the intended meaning of each statement visible beside the working lines.

## Instructions
1. Speak each sentence naturally and mark lexical stresses before trying to fit a meter.
2. Reduce, expand, reorder, or replace wording until the important stresses can occupy five main beats in a predominantly unstressed-stressed movement.
3. Reject versions that require abnormal word order, padding, or implausible pronunciation even when their diagrams look regular.
4. For three lines, test one conditional license: an opening inversion, fluent vowel elision, a light extra syllable within the line, or an extra unstressed ending.
5. Surround each licensed line with two steadier pentameters and read the sequence without stress marks. Keep the variation only if the governing measure remains audible and the line sounds like the intended speaker.
6. Compare the final lines with their original meanings and restore any precision lost during metrical recasting.

## Success Check
- Each line carries five audible beats over a defensible iambic baseline, judged by ear rather than from a diagram.
- Syntax and pronunciation stay natural, and versions needing abnormal order, padding, or implausible stress are rejected even where they scan.
- The essential meaning and voice of each original sentence survive the recasting, with any loss named where it occurs.
- One licensed variation is tested per line, so its effect can be attributed to it.
- Each licensed line sits between steadier pentameters and is read without stress marks before being kept.
- A variation is retained only where it produces emphasis or fluency, never where it conceals a pattern that failed.

## Common Failures
- Counting ten syllables without hearing alternating stress.
- Promoting a normally weak syllable merely because the diagram needs a beat.
- Treating every substitution as forbidden or every extra syllable as harmless.
- Solving the meter by replacing precise language with filler.

## Notes
The exercise separates metrical control from metrical obedience. Recasting trains the ear to negotiate among meaning, syntax, voice, and a recurring beat; the unmarked reading determines whether the negotiation succeeded.
