---
object_id: AP_revise_creative_draft_from_diagnosis_to_final_proof
object_type: ap
name: Revise a Creative Draft from Diagnosis to Final Proof
library_path:
  - writing
  - foundations
  - process
stage_binding: 3 rough
lane_fit: skill
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
  - creative_writing
  - revision
  - recursive_process
  - feedback
  - editing
  - proofreading
cross_links:
  - rel: supports
    target_object_id: PAT_calibrate_context_to_intended_audience_and_venue
  - rel: supports
    target_object_id: PAT_reassess_inspired_drafts_after_distance
  - rel: supports
    target_object_id: PAT_revise_whole_draft_toward_intended_form
  - rel: supports
    target_object_id: PAT_read_draft_aloud_to_defamiliarize_it
  - rel: supports
    target_object_id: PAT_receive_workshop_feedback_without_defending_the_draft
  - rel: supports
    target_object_id: PAT_weight_creative_feedback_by_criteria_and_reader_experience
  - rel: supports
    target_object_id: PAT_separate_revision_from_editing_and_proofreading
  - rel: supports
    target_object_id: PAT_make_nonstandard_language_a_deliberate_craft_choice
  - rel: supports
    target_object_id: PAT_shape_sentence_rhythm_through_length_structure_and_punctuation
  - rel: supports
    target_object_id: PAT_proofread_a_stable_draft_through_independent_passes
  - rel: supports
    target_object_id: PAT_make_proof_corrections_unambiguous
  - rel: related_to
    target_object_id: DRILL_cut_a_narrative_by_half_without_flattening_it
  - rel: related_to
    target_object_id: DRILL_map_repetition_by_scale_placement_and_effect
reference:
  source_title: "Creative Writing: Four Genres in Brief"
  author: David Starkey
confidence: high
references: []
variants: []
---

# Revise a Creative Draft from Diagnosis to Final Proof

## Objective
Take an existing creative draft through recursive reconsideration, evidence gathering, structural change, sentence editing, and final proofreading until it realizes its intended effect for its actual audience and venue without unresolved global defects.

## Steps / Flow
1. **Set the entry conditions.** Start with a draft substantial enough to evaluate. State what the piece is trying to become, who may read it, and where it is meant to appear. Activate `PAT_calibrate_context_to_intended_audience_and_venue` when the destination or readers would change what the work must supply. If the intended result is still too vague to compare against the text, clarify it before diagnosing prose.
2. **Create enough distance for judgment.** When fluency, speed, or emotional intensity makes the draft feel prematurely complete, activate `PAT_reassess_inspired_drafts_after_distance`. Do not diagnose while still relying on the composing moment's excitement. Advance when the work can be reread as an artifact rather than merely remembered as an experience.
3. **Diagnose the whole before treating parts.** Activate `PAT_revise_whole_draft_toward_intended_form`. Compare the existing form and effect with the intended result, then name the consequential mismatches in selection, development, character, plot, structure, or governing shape. **Global gate:** do not begin final sentence editing while a major mismatch remains unnamed or knowingly unresolved.
4. **Choose a perspective branch when diagnosis is weak.** Use only the branch that addresses the missing evidence:
   - If familiarity makes flaws invisible, activate `PAT_read_draft_aloud_to_defamiliarize_it`, mark the resistance heard, and return to whole-draft diagnosis.
   - If reader experience is uncertain and the piece is suitable for circulation, activate `PAT_receive_workshop_feedback_without_defending_the_draft`, preserve the unprompted responses, and return with the marked evidence.
   - If comments conflict or their standards are unclear, activate `PAT_weight_creative_feedback_by_criteria_and_reader_experience`; accept, adapt, or decline advice according to the work's goal rather than the force of the speaker.
   - If the piece is deliberately private, do not force it into workshop. Use distance or read-aloud evidence and preserve the private audience decision.
   - If excess makes the narrative's indispensable material difficult to identify, preserve the current version and run `DRILL_cut_a_narrative_by_half_without_flattening_it`; use the comparison as evidence, then return to whole-draft diagnosis rather than accepting the shorter version automatically.
   - If repetition is being retained or removed by frequency alone, run `DRILL_map_repetition_by_scale_placement_and_effect`; return with a scale-and-placement account of what each recurrence contributes.
5. **Make high-consequence changes first.** Reconceive, cut, expand, reorder, or rebuild the global elements identified in diagnosis before polishing passages that those changes may remove. Preserve the intended effect, audience decision, and strongest serving material as invariants. After each substantial change, reread enough of the whole to test its consequences.
6. **Recover recursively.** If a change introduces a new structural mismatch, destroys a required effect, or reveals that the target itself was wrong, return to step 1 or 3 as appropriate. If no available perspective exposes the problem clearly, return to step 4 rather than making arbitrary local changes. Continue until the global checklist of `PAT_revise_whole_draft_toward_intended_form` passes.
7. **Cross the editing gate deliberately.** Activate `PAT_separate_revision_from_editing_and_proofreading`. Advance only when conception, content, and form are stable enough that sentence-level corrections are unlikely to be discarded by another large change. If editing exposes a global defect, reopen step 3 instead of hiding it with polish.
8. **Edit without erasing intentional language.** Correct unintended sentence-level faults while activating `PAT_make_nonstandard_language_a_deliberate_craft_choice` wherever dialect, fragments, multilingual wording, or unconventional grammar perform a chosen expressive job. Activate `PAT_shape_sentence_rhythm_through_length_structure_and_punctuation` wherever a passage moves with accidental monotony or a cadence that fights its content. The invariant is control: purposeful departures remain, accidental errors do not.
9. **Proofread the stable form.** Activate `PAT_proofread_a_stable_draft_through_independent_passes` only after revision and editing are complete. Review automated suggestions in context, change the reading mode, and inspect the final rendering after the last correction. If a correction exposes a global defect, return to step 3; if it changes surrounding wording or layout, reopen the affected editing and proofing passes rather than assuming the earlier inspection still holds.
10. **Communicate corrections when another person will implement them.** For a formatted proof or shared production file, activate `PAT_make_proof_corrections_unambiguous`. Anchor each instruction to the exact matter, supply the intended replacement or measurement, and request another proof when the changes can reflow or reposition content. Otherwise keep this branch inactive.
11. **Complete.** Stop only when the intended audience and effect are still clear, no consequential global mismatch remains, feedback decisions have been resolved rather than merely collected, intentional language is distinguishable from error, the rendered form is clean, and every communicated correction has been verified or explicitly routed to another proof.

## Notes
The flow is recursive without being orderless. A writer may revisit earlier decisions many times, but global instability blocks final editing and editing blocks final proofreading. A proof is a specific state of the work: substantial late changes invalidate the inspected wording and may disturb layout, so they route backward before release. The perspective branches are diagnostic options, not mandatory ceremonies; purpose, genre, medium, familiarity, length, formality, available time, and privacy determine which route is proportionate. Feedback supplies evidence rather than authority, and completion means the important mismatches are resolved, not that every reader preference has been satisfied.
