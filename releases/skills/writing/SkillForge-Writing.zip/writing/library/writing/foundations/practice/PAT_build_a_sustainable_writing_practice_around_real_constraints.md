---
object_id: PAT_build_a_sustainable_writing_practice_around_real_constraints
object_type: pattern
name: Build a Sustainable Writing Practice Around Real Constraints
library_path:
  - writing
  - foundations
  - practice
stage_binding: 0 design
lane_fit: skill
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
  - creative_writing
  - writing_process
  - practice
  - consistency
  - constraints
cross_links:
  - rel: related_to
    target_object_id: PAT_recover_from_writing_block_by_lowering_the_hurdle
  - rel: related_to
    target_object_id: PAT_collect_fragments_before_demanding_complete_draft
  - rel: related_to
    target_object_id: PAT_separate_generative_and_evaluative_writing_modes
reference:
  source_title: "Creative Writing: A Workbook with Readings"
  author: Linda Anderson
confidence: high
references: []
variants: []
---

# Build a Sustainable Writing Practice Around Real Constraints

## Pattern Rule
**IF** writing occurs only when inspiration, abundant time, or ideal conditions happen to coincide
**THEN** establish a small recurring practice contract fitted to actual obligations, attention, place, and energy, then adjust it from observed sessions
**ELSE** preserve the routine that reliably produces material and revise it only when circumstances or results change

## Do
- Inventory immovable obligations and realistic attention windows before choosing a cadence.
- Set a minimum session small enough to repeat and concrete enough to verify by an action such as generating new language, extending material, diagnosing a known defect, or completing a bounded revision pass.
- Pair one distant project milestone with a near-term target measured by the work that currently matters: completion of a task, a number of sessions, or an amount of new material.
- Revise a repeatedly missed target downward until it supports continuity; increase it only after actual sessions show spare capacity, and review both levels as the project changes.
- Test times, locations, tools, sounds, and entry cues to discover which combination reduces friction for this writer.
- Use unavoidable travel, queues, chores, or other off-desk intervals for safe mental incubation or brief capture, then return that material to a writing session.
- Evaluate the routine after several attempts by what it produced, where it failed, and which conditions were actually repeatable.
- Let longer sessions grow from available capacity without making their duration the minimum required for the practice to count.

## Don't
- Wait for inspiration before becoming available to write.
- Copy another writer's schedule or ritual without testing whether it fits present obligations and attention.
- Treat one missed session as proof that the routine or the writer has failed.
- Count planning, equipment changes, or ritual maintenance as writing when they repeatedly replace work that advances the project.
- Treat flat or negative word-count movement during necessary revision as proof that the session was unproductive.
- Demand an identical daily duration when a different repeatable cadence would better survive real constraints.

## Checklist
- The practice contract names a repeatable cue or time, a workable place or tool, and an observable session action.
- The minimum session fits around current obligations rather than an imagined future life.
- Near-term targets identify an observable task, session cadence, or amount of material and connect to a revisable project milestone.
- At least several trials have produced evidence about which conditions help entry and continuation.
- Off-desk incubation feeds later writing without requiring unsafe or intrusive capture.
- The routine advances the project through new language, usable material, diagnosis, correction, or bounded revision often enough to justify keeping it.
- A disrupted session leads to a specific adjustment rather than abandonment or self-punishment.

## Notes
A writing habit courts discovery and completion by making the writer repeatedly available to the work. Some productive sessions add language; others cut, reconnect, diagnose, or correct existing material, so word-count growth is not a universal measure of progress. Constancy matters because entry becomes more familiar and material remains active between sessions, but constancy need not mean a long daily appointment. A short recurring practice, several protected sessions per week, or another stable cadence can serve when it survives the writer's actual life and produces work.

Rituals and locations are experiments, not prerequisites or signs of seriousness. Keep a cue when it helps attention settle; discard it when maintaining the cue becomes more elaborate than writing. Use `PAT_recover_from_writing_block_by_lowering_the_hurdle` when an established session still stalls, and use `PAT_separate_generative_and_evaluative_writing_modes` when external judgment or premature correction interrupts production.
