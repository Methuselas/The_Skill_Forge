---
name: skillforge-writing
description: "Use for fiction, poetry, creative nonfiction, life writing, college\
  \ admission essays, and career documents \u2014 drafting, structure, viewpoint,\
  \ voice, dialogue, imagery, revision, feedback, and submission \u2014 using the\
  \ SkillForge Writing knowledge library."
---

# SkillForge Writing

This is a self-contained SkillForge release.

`runtime/profile.yaml` (profile `generic`) is this release's **execution contract**. It declares the execution modes, routing, risk checks, and completion requirements this skill is expected to honor. Do not preload it for discussion, critique, help, or another non-productive request. Before the first productive action, resolve the execution mode, apply the activated metaskills, perform the named risk checks, and satisfy the completion requirements. That responsibility is yours — nothing in this package can check it for you.

`scripts/skillforge_runtime.py` is an **optional deterministic helper** for hosts that can execute Python. It holds no state, runs only when invoked, and cannot observe or block anything you do:

- `doctor` checks that the bundled profile and library are internally consistent.
- `resolve --request <user request>` returns the contract for a request as JSON, so mode and check selection are deterministic instead of re-derived each time.
- `verify` audits a completion record you write, and reports which required checks it does not contain.

Prefer the resolver's bounded result to loading the complete profile. Where Python is unavailable, read and apply `runtime/profile.yaml` directly. The release is complete without Python.

The semantic craft knowledge lives in `library/`. Python resolves and reports; it does not sequence stages, gate approvals, or enforce the contract. Hard prerequisites have already been materialized locally. Each card is self-contained: it needs no source document to execute.

## Bundled knowledge

Load `library/metaskills/INDEX.md` as the default baseline, then retrieve only the domain indexes and cards relevant to the current decision. `RELEASE_MANIFEST.json` lists every bundled module; do not preload that list or the complete library.

## Blind Drill administration

This release includes canonical Drills and the optional model-neutral, learner-neutral `scripts/skillforge_drill.py` helper. It standardizes administration, not how a taker reasons or solves the task. `list` and `show` discover the bundled Drills; `prepare` creates a student-safe packet at either `before-instructions` or `before-success-check`; `freeze` seals the produced answer before `reveal` creates the grader packet; and `finalize` requires every canonical Success Check criterion to be dispositioned. Qualification is answer-key blind but skillcard-present: `prepare` packages the Drill's exact linked Pattern/AP cards, and only the Success Check and Common Failures remain hidden. A valid qualification is binary PASS or FAIL; a setup, tool, or package failure is INVALID and says nothing about craft. Linked practice may teach through Drill Instructions, packaged Pattern/AP cards, external material, or a declared combination. Use repeated `--drill` arguments to chain compatible Drills from one domain. Never expose `controller/` to the taker.

The current run purpose is `skillset-improvement`: use the evidence to qualify cards and Skillset Memory, not to claim persistent model-memory or weight changes. Record a valid application miss as a transferable mistake/correction/prevention lesson, never as a named model's weakness. Drill guidance should decay as capability stabilizes; ordinary work then leans on Patterns and Action Protocols.

The helper never repeats a sitting, judges craft semantics, or writes Skillset Memory. `finalize` exports `candidate_training_event.json` for review and later import into the owning repository. If Python is unavailable, follow the same prepare → produce → freeze → reveal → grade order manually from the card.

## Module runtime

This skill ships executable helpers that belong to its own modules. Run them with Python from the root of the project you are working in, using their path inside this installed skill; `--help` lists every command. They keep their state in that project, never in this package, and use only the Python standard library. Each ships with the tests that passed before this release was built.

- `library/metaskills/runtime/ap_runner.py` (module `metaskills`)

Read `library/metaskills/runtime/README.md` before the first use of that runtime.

## Mandatory execution barriers

Before the first productive action, read and retain `references/execution-barriers.md`. Do not load it for a non-productive request.

## Skillset Memory

`memory/<domain>/skill_memory.yaml` is this skillset's **empirical record**: what actually happened when this canon was used, including known weak areas and the boundaries of what has been verified. It is not canon and never overrides a card. Consult it when a task touches a scope it names, and read each entry as an observation carrying a stated confidence, not as an instruction. `training_history.jsonl` holds the events an entry was consolidated from; an event marked `invalid` failed before the capability was exercised and is evidence about a tool or a package, never about craft.

These files ship **read-only**. This package is not the persistence target: new events belong to the library that owns the store, so do not append to them, edit them, or copy their content into a card or a prompt.

- `memory/writing/`

## License and attribution

Keep `LICENSE.md`, `NOTICE.md`, `TRADEMARKS.md`, and `LICENSES/` with this release. The vendored Python helpers and any module runtime code under `library/**/runtime/` are AGPL-3.0-or-later; the Skill instructions, knowledge, declarative profile, memory, and original assets are CC-BY-SA-4.0 unless a shipped file states otherwise.
