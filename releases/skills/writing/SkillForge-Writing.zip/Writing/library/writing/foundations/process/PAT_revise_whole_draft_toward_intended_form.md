---
object_id: PAT_revise_whole_draft_toward_intended_form
object_type: pattern
name: Revise the Whole Draft Toward Its Intended Form
library_path:
  - writing
  - foundations
  - process
stage_binding: 3 rough
lane_fit: skill
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
  - creative_writing
  - revision
  - recursive_process
  - structure
  - redrafting
cross_links:
  - rel: related_to
    target_object_id: PAT_reassess_inspired_drafts_after_distance
reference:
  source_title: "Creative Writing: Four Genres in Brief"
  author: David Starkey
confidence: high
references: []
variants:
  - variant_id: writing_variant_compress_by_function_before_line_trimming
    variant_name: Compress by Function Before Line Trimming
    variant_basis: method_sequence
    difference_from_foundation: When a draft must become shorter or denser, preserve a recoverable version, identify what the draft must accomplish, remove low-function setup, repetition, background, explanation, and decorative passages at section or paragraph scale first, then tighten the surviving sentences.
    when_to_use: Length or density is a named mismatch and the draft contains material whose contribution can be tested against the intended effect.
    when_not_to_use: Accumulation, repetition, breadth, or deliberate slowness creates the intended effect, or cutting would remove necessary orientation, evidence, voice, movement, sensory force, causality, or reader experience.
    absorbed_from_object_id: none
  - variant_id: writing_poetry_variant_release_prescribed_meter_that_no_longer_fits
    variant_name: Release a Prescribed Meter That No Longer Fits
    variant_basis: constraint
    difference_from_foundation: Recast a metered or rhymed poem in free verse, retain only the formal elements that remain expressive, and compare whether the new shape better serves its emerging thought and voice.
    when_to_use: A once-productive pattern has become mere formality, distorts the poem's changing substance, or consumes attention needed by the poem itself.
    when_not_to_use: The meter remains vital to the poem's effect, still generates discovery, or is a required constraint of the task.
    absorbed_from_object_id: none
  - variant_id: writing_variant_compose_toward_clarity_then_revise_toward_strangeness
    variant_name: Compose Toward Clarity Then Revise Toward Strangeness
    variant_basis: method_sequence
    difference_from_foundation: Use the early draft to approximate the intended thought, emotion, event, or effect clearly, then use later passes to cut verbiage and received language and introduce exact, personally distinctive phrasing and structure.
    when_to_use: Pressure to perform a literary style is obscuring what a creative draft is trying to express, while a merely clear version would still lack concentrated and individual language.
    when_not_to_use: Clarifying too early would close a productive discovery process, or later strangeness would become arbitrary novelty instead of a more exact expression.
    absorbed_from_object_id: none
  - variant_id: writing_poetry_variant_audition_alternate_form_for_same_material
    variant_name: Audition an Alternate Form for the Same Material
    variant_basis: method_sequence
    difference_from_foundation: Recast the poem's governing material in a different inherited form and compare which constraint generates stronger language, movement, and discovery before committing to either version.
    when_to_use: The current form is dragging down the content, but the material may benefit from a different pattern of repetition, stanza, rhyme, or turn rather than from abandoning form altogether.
    when_not_to_use: The existing structure already propels the poem, or rewriting into another form would consume effort without testing a named mismatch.
    absorbed_from_object_id: none
  - variant_id: writing_fiction_variant_redesign_structure_after_draft_discovery
    variant_name: Redesign Fiction Structure After Draft Discovery
    variant_basis: method_sequence
    difference_from_foundation: Treat the first draft as evidence about the story's actual center, then replace the planned chronology, opening, conflict sequence, or ending when discovery has made the initial design into a maze.
    when_to_use: Drafting reveals a more consequential event, relation, or turn than the outline anticipated, or the planned sequence blocks movement toward the emerging story.
    when_not_to_use: The structure already carries the discovered material and the difficulty is local execution rather than global design.
    absorbed_from_object_id: none
  - variant_id: writing_variant_use_late_draft_meaning_sentence_as_revision_filter
    variant_name: Use a Late-Draft Meaning Sentence as a Revision Filter
    variant_basis: method_sequence
    difference_from_foundation: After several drafts have exposed the work's underlying movement, state that current meaning in one working sentence and use it to test selection, omission, sequence, and proportion without requiring every passage to state the sentence directly.
    when_to_use: A substantial late draft feels nearly complete but its governing subject or pressure remains difficult to name, making consequential revision choices inconsistent.
    when_not_to_use: The work is still discovering what it means, its productive ambiguity cannot be reduced honestly to one sentence, or the sentence would become a thesis imposed on every image and turn.
    absorbed_from_object_id: none
---

# Revise the Whole Draft Toward Its Intended Form

## Pattern Rule
**IF** a draft's present shape or effect falls short of the work the writer is trying to make
**THEN** compare the work as a whole with its intended form, diagnose the differences, and recursively cut, expand, reorder, or reconceptualize until the important gaps narrow

## Do
- Treat an early draft as an attempt to define the territory, then look for general patterns of development before deciding what belongs.
- Examine global choices such as governing form, central character, plot, and structure alongside the local passages through which they operate.
- Salvage a word, image, or phrase only when it serves the emerging work; let the rest go when no useful part remains.
- Choose the depth and means of reconsideration in light of purpose, format, medium, genre, familiarity with the task and subject, audience, formality, length, and available time.

## Don't
- Expect composition to march once from opening to conclusion without circling back through earlier decisions.
- Keep material merely because it was difficult to produce or felt powerful during composition.
- Let easy local improvements conceal an unresolved mismatch in the work's larger design.
- Continue revising merely because the draft still feels imperfect after consequential mismatches have been resolved.

## Checklist
- The desired effect or emerging form is clear enough to compare with the existing text.
- Major inclusions and exclusions support an observable pattern of development.
- Global changes and their local consequences agree rather than pulling the piece in different directions.
- Another pass names the consequential mismatch it will reduce; when no such mismatch can be named, the draft moves to finalization or outside evaluation rather than preference-swapping.

## Notes
Experienced writers approach redrafting holistically and recursively. Discovery may require moving backward, repeating a decision, or changing something established earlier; messiness is not proof that the process has failed. Context changes which strategy is practical, but not the need to reconsider the work before declaring it finished. Persistence also needs an exit condition: once further changes cannot be tied to a consequential mismatch, dissatisfaction alone is not evidence that another revision pass will improve the work.

`writing_variant_compress_by_function_before_line_trimming` treats compression as a structural revision problem before it becomes a sentence-trimming problem. Preserve a recoverable version, name what the draft must still accomplish, remove whole passages or sections that do little necessary work, then tighten the language that survives. Restore material when comparison exposes a named loss in orientation, evidence, voice, movement, sensory force, causality, or reader experience; a lower word count is not itself proof of improvement.

`writing_poetry_variant_release_prescribed_meter_that_no_longer_fits` tests a constrained poem by recasting it in free verse when meter or rhyme has stopped serving the emerging work. Use the comparison to release mere formality while preserving any formal elements that still carry useful energy; do not discard a constraint that remains essential or required.

`writing_variant_compose_toward_clarity_then_revise_toward_strangeness` separates two pressures that can interfere across creative forms when applied simultaneously. The early pass gets close enough to the intended thought, emotion, event, or effect to establish a target; later passes remove verbiage and received phrasing and search for language and structure shaped by the writer's particular perception. Use the sequence to prevent premature performance of literary style, but do not let clarity flatten ambiguity that the drafting process still needs to explore.

`writing_poetry_variant_audition_alternate_form_for_same_material` diagnoses a form-content mismatch by giving the same material a different inherited pressure. Compare what each version discovers, distorts, or leaves inert; keep the form that propels the poem rather than the one that merely preserves prior effort. Use the existing free-verse recast when the evidence points away from prescribed structure altogether.

`writing_fiction_variant_redesign_structure_after_draft_discovery` treats an outline as a working route rather than a contract. Use the completed first draft to locate the story's true center, then knock down structural walls by changing where the narrative begins, which events cause later ones, how time is arranged, or where the ending falls. Do not invoke a global redesign when the sequence remains sound and only a scene, transition, or sentence needs repair.

`writing_variant_use_late_draft_meaning_sentence_as_revision_filter` turns a mature but still diffuse draft's current underlying movement into a working window for revision. Write the sentence only after repeated drafting has produced enough evidence, then ask which sections sharpen, complicate, or distract from that movement and whether their proportions agree with their importance. Revise the sentence when the work disproves it; release the method when one statement would flatten deliberate multiplicity or close discovery that is still active.
