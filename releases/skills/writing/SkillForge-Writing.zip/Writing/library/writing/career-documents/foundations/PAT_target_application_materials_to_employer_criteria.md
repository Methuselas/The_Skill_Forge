---
object_id: PAT_target_application_materials_to_employer_criteria
object_type: pattern
name: Target Application Materials to Employer Criteria
library_path:
  - writing
  - career-documents
  - foundations
stage_binding: 0 design
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: PAT_calibrate_context_to_intended_audience_and_venue
tags:
  - resume_writing
  - cover_letters
  - job_applications
  - audience
  - employer_criteria
cross_links:
  - rel: prerequisite_for
    target_object_id: PAT_include_optional_resume_sections_only_as_evidence
  - rel: prerequisite_for
    target_object_id: PAT_open_resume_with_employer_relevant_evidence
  - rel: prerequisite_for
    target_object_id: PAT_present_education_and_training_by_hiring_relevance
  - rel: prerequisite_for
    target_object_id: PAT_scale_work_history_detail_by_role_relevance
  - rel: prerequisite_for
    target_object_id: PAT_choose_resume_format_by_evidence_visibility
  - rel: prerequisite_for
    target_object_id: PAT_build_resume_competency_statements_from_fit_and_verifiable_evidence
  - rel: prerequisite_for
    target_object_id: PAT_use_recognizable_job_language_for_resume_discovery
reference:
  source_title: "Writing Resumes & Cover Letters For Dummies, 2nd Australian and New Zealand Edition"
  author: Amanda McCarthy and Kate Southam
confidence: high
references: []
variants:
  - variant_id: writing_application_targeting_variant_transferable_skill_bridge
    variant_name: Transferable-Skill Bridge When Titles Do Not Establish Fit
    variant_basis: method_sequence
    difference_from_foundation: Inventory capabilities from paid, casual, informal, volunteer, educational, sporting, community, and self-directed activity; extract the target role's requirements; keep the genuine intersections; then preview each match in the opening or skill summary and substantiate it in the relevant experience, education, or optional section.
    when_to_use: A school leaver, graduate, career changer, workforce re-entrant, or other candidate lacks occupational titles that directly establish fit but has capabilities acquired in credible settings that perform the target work.
    when_not_to_use: The proposed skills do not match the target requirements, cannot be supported by an example, or direct experience already makes the bridge unnecessary.
    absorbed_from_object_id: none
---

# Target Application Materials to Employer Criteria

## Pattern Rule
**IF** a resume and cover letter are being prepared for a particular opening
**THEN** select and phrase the candidate's evidence against that employer's role criteria, organization, and stated priorities
**ELSE** define a target role family and sector before choosing evidence for a discoverable general resume

## Do
- Mark the responsibilities, qualifications, experience, and personal attributes named in the advertisement or position description.
- Research enough about the organization to distinguish generic employability from a credible reason this candidate fits this workplace and role.
- Pair important requirements with concrete achievements, examples, or qualifications that show the candidate can meet them.
- Reuse the employer's recognizable terminology only where the candidate can truthfully claim the corresponding capability.
- Treat sample applications and templates as structural prompts, then rebuild every claim and sentence from this candidate's target, evidence, and voice.

## Don't
- Send one unchanged application everywhere and expect employers to infer commitment or fit.
- Copy another candidate's résumé or retain template prose that was written for a different history, even when the target roles look similar.
- Claim a requirement merely because its wording appears in the advertisement.
- Let decorative novelty displace the facts a recruiter needs to match against the vacancy.

## Checklist
- Every major requirement has matching evidence or is consciously left unclaimed.
- The application demonstrates knowledge of both the work and the organization.
- Important claims are supported by examples, results, experience, or qualifications.
- Reused role language remains truthful and natural in context.
- Removing the employer and role names would not leave a generic document that could be sent anywhere unchanged.
- Every substantive sentence can be traced to this candidate's evidence rather than a peer, example, or template.

## Notes
Recruiters evaluate an application as a proposed match, not as an autobiography. A resume supplies the career evidence; a cover letter introduces and interprets that evidence for the opening. Relevance therefore governs selection before polish: strong but unrelated material can consume attention while failing to answer the employer's actual question.

`writing_application_targeting_variant_transferable_skill_bridge` changes the evidence-selection sequence when occupational titles do not establish the match. Inventory capabilities across paid, casual, informal, volunteer, educational, sporting, community, and self-directed settings; identify the new role's actual requirements; retain only genuine intersections; then preview each claimed skill where the reviewer will see it early and substantiate it in the section that owns the underlying experience. Use this bridge when the evidence exists outside a conventional job sequence, not to rename generic traits or imply technical experience the candidate has not acquired.
