---
object_id: DRILL_diagnose_comic_couplet_timing_by_scansion
object_type: drill
name: Diagnose Comic Couplet Timing by Scansion
library_path: [writing, poetry, sound]
stage_binding: 3 rough
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags: [poetry, comedy, couplet, scansion, deliberate_practice]
cross_links:
  - rel: teaches
    target_object_id: PAT_scan_and_vary_meter_deliberately
  - rel: related_to
    target_object_id: PAT_make_rhyme_serve_sense_and_effect
reference: {source_title: "Creative Writing: A Workbook with Readings", author: W. N. Herbert}
confidence: high
references: []
target_skill: Locating and revising the rhythmic setup, anticipation, and release of a rhyming joke
variants: []
---

# Diagnose Comic Couplet Timing by Scansion

## Practice Task
Scan a comic setup and rhyming payoff, then test small rhythmic and syntactic changes to locate the strongest release.

## Target Skill
Locating and revising the rhythmic setup, anticipation, and release of a rhyming joke.

## Setup
Choose a comic couplet or short rhyming unit whose final match is predictable but whose delivery still feels weak.

## Instructions
1. Read aloud twice and mark lexical stress, promoted emphasis, pauses, and the prevailing beat.
2. Mark where the rhyme becomes predictable and where syntax permits completion.
3. Create versions that shorten the setup, delay the terminal word, and alter one stress before the payoff. Set aside any version that changes the joke itself rather than its timing: that is a different poem and cannot be compared on this axis.
4. Read every version without exaggerated acting and compare the interval between recognition and release. Reject a version that only lands when performed, and say so, since delivery can rescue a rhythm that will not survive the page.
5. Keep the version whose rhythm makes prediction pleasurable without damaging clarity. Where the kept version bought its timing with something else - a plainer word, a lost precision, a slower setup - state that trade, because a version described only by what it gained cannot be compared with the one you discarded.

## Success Check
- Stress is marked from speech rather than spelling, with promoted and demoted syllables distinguished.
- The point where the rhyme becomes predictable and the point where it is delivered are marked separately.
- Each version alters timing while leaving the semantic joke intact; a version that changes the joke is set aside as a different poem.
- The comparison names the interval between recognition and release, not merely which version reads better.
- Every reading is done without exaggerated performance, and a version rescued by delivery is rejected for that reason.
- The kept version makes prediction pleasurable without costing clarity, and any trade made is stated.

## Common Failures
- Assuming rhyme alone supplies timing.
- Adding filler merely to regularize meter.
- Overacting a line whose written rhythm remains weak.

## Notes
A punchline is both semantic and temporal. Scansion exposes whether the setup creates a stable expectation and whether syntax releases the final word too early, too late, or under the wrong stress.
