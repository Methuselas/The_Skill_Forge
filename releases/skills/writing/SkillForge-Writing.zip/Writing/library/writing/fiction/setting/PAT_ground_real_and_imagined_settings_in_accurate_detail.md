---
object_id: PAT_ground_real_and_imagined_settings_in_accurate_detail
object_type: pattern
name: Ground Real and Imagined Settings in Accurate Detail
library_path:
  - writing
  - fiction
  - setting
stage_binding: 0 design
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags:
  - fiction
  - setting
  - research
  - accuracy
  - worldbuilding
  - credibility
cross_links:
  - rel: related_to
    target_object_id: PAT_choose_truth_contract_before_shaping_real_material
  - rel: related_to
    target_object_id: PAT_match_story_scope_to_required_accumulation
reference:
  source_title: "Creative Writing: Four Genres in Brief"
  author: David Starkey
confidence: high
references: []
variants:
  - variant_id: writing_fiction_variant_expand_worldbuilding_from_active_story_radius
    variant_name: Expand Worldbuilding from the Active Story Radius
    variant_basis: method_sequence
    difference_from_foundation: Build the private world model first around the places, institutions, and causal systems touched by current action plus the first layer of consequences needed for coherence, then expand outward only when later action reaches or depends on more.
    when_to_use: Worldbuilding can expand indefinitely and planning has begun outrunning the story's actual needs.
    when_not_to_use: A distant region, history, institution, or system already exerts consequences on the current narrative and therefore must be established now.
    absorbed_from_object_id: none
  - variant_id: writing_fiction_variant_saturate_historical_imagination_with_period_writing
    variant_name: Saturate Historical Imagination with Period Writing
    variant_basis: method_sequence
    difference_from_foundation: Read fiction, journalism, letters, diaries, and other firsthand language from the period before and during drafting so ordinary materials, assumptions, and verbal atmosphere remain available without turning the story into a research display.
    when_to_use: A historical setting depends on lived textures and habits that isolated fact checks cannot supply.
    when_not_to_use: The reading becomes an avoidance loop, the sources cannot answer the draft's actual uncertainties, or period atmosphere begins to displace story pressure.
    absorbed_from_object_id: none
---

# Ground Real and Imagined Settings in Accurate Detail

## Pattern Rule
**IF** a story depends on a place or period outside the writer's direct knowledge, or on an invented world that still must feel inhabitable
**THEN** research or derive a handful of accurate, ordinary, story-relevant details and make the rest of the setting consistent with them
**ELSE** use firsthand local knowledge when it supplies equal freshness and authority

## Do
- Identify which landmarks, distances, customs, materials, technologies, or environmental facts could expose a false note to knowledgeable readers.
- Prefer a few unusual but exact particulars over a large background dossier that never enters action.
- Decide whether the story needs a real location, an invented one, or a consistent hybrid; use the real place for useful public associations and the invented element where the action needs controlled freedom.
- Build invented environments from concrete physical and social details whose operation readers can recognize, then alter them consistently.
- Look closely at nearby places before assuming distance is required for strangeness or imaginative value.

## Don't
- Use a famous city as shorthand while misplacing landmarks or inventing implausible local behavior.
- Pour all research into the draft to prove that it was done.
- Treat fantasy or science fiction as exempt from material, spatial, and social consistency.
- Substitute generic exoticism for observed or researched particulars.

## Checklist
- High-risk factual details have been checked against reliable knowledge.
- The draft uses only the research needed for credibility, action, and atmosphere.
- Imagined features have concrete consequences for daily life or movement.
- A reader familiar with the place or period would not encounter an avoidable false note.
- Local or firsthand alternatives were considered before choosing remoteness.

## Notes
Believability grows from a handful of details that are accurate, out of the ordinary, and exactly suited to the story. Real and invented settings differ in factual obligation, but both fail when concrete particulars contradict one another. Research supports the fictional frame; it is not the frame's artistic purpose.

`writing_fiction_variant_expand_worldbuilding_from_active_story_radius` bounds private construction without requiring the visible prose to carry everything the writer knows. Establish the part of the world current action touches, add the nearby consequences necessary for consistency, leave unrelated regions and histories unresolved, and expand the model when the narrative reaches or causally depends on them. The private world should exceed the prose when useful, but it need not become encyclopedic by default.

The variant `writing_fiction_variant_saturate_historical_imagination_with_period_writing` keeps period atmosphere available during composition by reading fiction, journalism, letters, diaries, and other contemporary language before and alongside the draft. Use it when isolated fact checks cannot supply ordinary habits and textures; stop when continued reading postpones the story or gathered detail begins to colonize it.
