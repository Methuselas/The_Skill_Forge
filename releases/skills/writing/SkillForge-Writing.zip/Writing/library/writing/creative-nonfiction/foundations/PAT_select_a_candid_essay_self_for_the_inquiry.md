---
object_id: PAT_select_a_candid_essay_self_for_the_inquiry
object_type: pattern
name: Select a Candid Essay Self for the Inquiry
library_path:
  - writing
  - creative-nonfiction
  - foundations
stage_binding: 2 block
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags:
  - creative_nonfiction
  - personal_essay
  - self_portrayal
  - candor
  - contradiction
cross_links:
  - rel: related_to
    target_object_id: PAT_make_personal_presence_part_of_inquiry
  - rel: related_to
    target_object_id: PAT_separate_experiencing_self_from_reflective_narrator
  - rel: related_to
    target_object_id: PAT_interrogate_memory_before_claiming_precision
reference:
  source_title: "Creative Writing: Four Genres in Brief"
  author: David Starkey
confidence: high
references: []
variants:
  - variant_id: writing_creative_nonfiction_variant_present_candid_growth_under_admission_evaluation
    variant_name: Present Candid Growth Under Admission Evaluation
    variant_basis: context
    difference_from_foundation: Under high-stakes personal admission evaluation, select a truthful partial self that may include a consequential limitation or challenge while emphasizing the applicant's response, reflection, and effort to grow instead of projecting perfection.
    when_to_use: A personal statement or supplemental essay is meant to show readiness, character, or development beyond the rest of the application.
    when_not_to_use: The limitation is irrelevant, included as harmless self-deprecation, or too unresolved or private to examine without disguise.
    absorbed_from_object_id: none
---

# Select a Candid Essay Self for the Inquiry

## Pattern Rule
**IF** the writer appears as a subject or character but the draft offers either an indiscriminate life inventory or a polished self-defense
**THEN** retain the attitudes, experiences, shortcomings, contradictions, and ambivalence that the particular inquiry needs, and render that partial self candidly
**ELSE** leave private aspects out when they do not change the reader's understanding of the subject

## Do
- Name the essay's live tension, then mark which versions of the writer actually bear on it; a life contains more personae than one short work can use.
- Include a mistake, limitation, or unflattering perception when concealing it would make the narrator's account less trustworthy or the central tension falsely simple.
- Favor traits that pull against one another, since conflict between values, desires, conduct, and later judgment can generate inquiry rather than a fixed verdict.
- Reveal enough personal context for readers to understand motive and stakes without treating complete disclosure as the measure of courage.
- If the subject is still too emotionally charged to examine without disguise or retaliation, defer it or choose a topic that can presently withstand candor.
- Shape the selected self through voice, sentence movement, scene, and arrangement after deciding what must be disclosed; confession alone does not make literature.

## Don't
- Use self-belittlement as a charm strategy when the admitted flaw carries no consequence and risks no real self-revision.
- Disclose every intimate fact merely to prove honesty; irrelevant exposure can overwhelm the work as easily as concealment can weaken it.
- Assign every failure to other people while presenting the narrator's motives as uncomplicated and pure.
- Reduce a complex past self to contempt so the present narrator can appear wise by comparison.
- Treat subjective conviction as permission to state uncertain memories or invented actions as fact.

## Checklist
- Every retained aspect of the writer changes the inquiry, stakes, relation, or reader's interpretation.
- At least one consequential tension complicates a purely flattering or purely condemnatory self-portrait.
- Omitted personal material is irrelevant or responsibly private rather than evidence hidden to protect the narrator's image.
- Disclosure gives readers what they need without turning the essay into an exhaustive confession.
- Style and structure make the selected persona legible without substituting performance for honest examination.
- Factual confidence remains proportionate to memory and evidence even where emotional conviction is strong.

## Notes
The self on the page is made by subtraction. Selection does not authorize fabrication; it concentrates one truthful configuration of a larger life around the work's present question. Candor earns trust when it admits pressures that materially complicate the narrator's preferred account. Routine self-mockery can do the opposite by offering a harmless flaw in place of the contradiction the essay actually needs to face.

A personal essay is also not a police confession. Readers encounter the writer through what is disclosed and through how the language has been shaped. The usable balance is enough intimacy to expose the live tension, enough restraint to keep unrelated privacy from colonizing the work, and enough revision to turn disclosure into a deliberate literary experience.

`writing_creative_nonfiction_variant_present_candid_growth_under_admission_evaluation` applies candid self-selection to an evaluative personal statement: present the strongest truthful self, not a flawless invention. When a shortcoming or challenge is material, make the response, reflection, and effort to grow visible; do not use cosmetic self-deprecation or disclose material that cannot yet withstand candid examination.
