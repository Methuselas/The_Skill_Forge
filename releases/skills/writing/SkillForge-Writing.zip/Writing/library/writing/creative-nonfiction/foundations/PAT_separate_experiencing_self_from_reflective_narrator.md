---
object_id: PAT_separate_experiencing_self_from_reflective_narrator
object_type: pattern
name: Separate the Experiencing Self from the Reflective Narrator
library_path:
  - writing
  - creative-nonfiction
  - foundations
stage_binding: 2 block
lane_fit: skill
foundation_role: specialization
routing_class: specialized
specialization_axis: genre
foundation_object_id: none
tags:
  - creative_nonfiction
  - narrator
  - experiencing_self
  - hindsight
  - characterization
cross_links:
  - rel: related_to
    target_object_id: PAT_make_personal_presence_part_of_inquiry
  - rel: related_to
    target_object_id: PAT_interrogate_memory_before_claiming_precision
  - rel: related_to
    target_object_id: PAT_portray_real_people_through_selective_behavioral_detail
  - rel: related_to
    target_object_id: DRILL_recast_a_life_writing_event_across_tense_and_narrator_distance
reference:
  source_title: "Creative Writing: Four Genres in Brief"
  author: David Starkey
confidence: high
references: []
variants:
  - variant_id: writing_creative_nonfiction_variant_test_third_person_self_distance_without_claiming_objectivity
    variant_name: Test Third-Person Self-Distance without Claiming Objectivity
    variant_basis: method_sequence
    difference_from_foundation: Recast a bounded autobiographical passage in the third person to expose habitual self-explanation, alter sympathy, and make the earlier person available for observation while preserving the narrator's authorship, evidence limits, and later knowledge.
    when_to_use: First-person proximity makes the writer defend, idealize, or collapse into the earlier self, and a pronoun shift may reveal a more useful relation between experience and reflection.
    when_not_to_use: Third person would conceal responsibility, pretend to neutral access, confuse identity, or create emotional distance that the inquiry should confront directly.
    absorbed_from_object_id: none
---

# Separate the Experiencing Self from the Reflective Narrator

## Pattern Rule
**IF** a personal essay lets the present-day narrator's knowledge, language, or judgment overwrite the self who originally lived the event
**THEN** characterize the earlier self within the limits of that moment while letting the later voice frame, question, and interpret the experience from a distinct vantage
**ELSE** merge the two positions only when elapsed time and changed understanding have no consequential effect on the account

## Do
- State what the earlier self wanted, feared, noticed, and believed before later consequences became known.
- Let present reflection identify a past blind spot without pretending that recognition guided the original action.
- Use shifts in time frame, angle, voice, rhythm, or juxtaposition to make the distance between experience and narration perceptible.
- Give the onstage self observable choices and limitations rather than making that figure a mouthpiece for the essay's finished wisdom.
- Track where hindsight changes sympathy, irony, or interpretation and decide which temporal position should control each passage.
- When testing past and present tense, hold the event, evidence status, and uncertainty constant so changes in access or distance are not mistaken for new knowledge.

## Don't
- Give the earlier self polished conclusions that only years of reflection made possible.
- Mock past ignorance from a narrator position that conceals its own remaining limits.
- Flatten the lived self into an example whose only purpose is to prove the present narrator correct.
- Switch between then and now so quietly that readers cannot tell who knows what.
- Confuse honest temporal framing with permission to redesign conduct or motive.
- Treat present tense, child diction, or sensory immediacy as proof that a recollection is more accurate or less mediated.

## Checklist
- The person inside the event acts from information available at that time.
- Later interpretation adds meaning without retroactively changing what occurred.
- Voice or framing makes consequential shifts between experience and reflection legible.
- The earlier self remains a credible person rather than a prop for hindsight.
- Irony, judgment, and sympathy can be traced to the temporal vantage producing them.
- Every tense preserves the same boundary between remembered, reported, inferred, reconstructed, and unknown material.

## Notes
In first-person nonfiction, author, narrator, and character may refer to one life without functioning as one consciousness. The lived self moves through incomplete information; the narrating self knows what followed and has language for patterns that were invisible then. Preserving that distance creates both honesty and dramatic tension because readers can inhabit the event while also hearing the later mind test its meaning. Tense changes the reader's temporal relation to the account, not the factual basis of the account; an immediate voice remains a present construction made from whatever evidence and memory the writer actually has.

`writing_creative_nonfiction_variant_test_third_person_self_distance_without_claiming_objectivity` uses pronoun and naming distance as a diagnostic rather than an authority claim. Draft the same bounded material in first and third person while holding event, evidence, and uncertainty constant. Compare where the third-person version permits observation or compassion and where it merely disguises judgment, shame, or hindsight. Keep it only when readers can still locate who is telling, what that narrator knows, and why the distance serves the inquiry.
