---
object_id: PAT_hold_member_identity_with_constant_width
object_type: pattern
name: Hold Member Identity With Constant Width
library_path:
- art
- foundations
- form-construction
stage_binding: 2 block
lane_fit: skill
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- figure_drawing
- foreshortening
- width
- proportion
cross_links:
- rel: related_to
  target_object_id: PAT_build_gesture_into_clear_masses
reference:
  source_title: Dynamic Figure Drawing
  author: Burne Hogarth
confidence: high
references: []
variants: []
---

# Hold Member Identity With Constant Width

## Pattern Rule
**IF** a cylindrical arm, leg, finger, or comparable form changes apparent length because it advances, recedes, bends, or turns nearly end-on
**THEN** preserve its designed width at corresponding stable cross-sections while allowing the projected length to vary
**ELSE** use ordinary proportion checks when the member is not materially foreshortened

## Do
- Compare thigh to thigh, calf to calf, upper arm to upper arm, and forearm to forearm at equivalent regions rather than measuring across unlike bulges.
- Preserve the intended taper from a broader parent region toward the narrower joint or terminal form.
- Use a visible partner member or a deliberately matched figure as the norm when the foreshortened member has little usable length.
- Add temporary diameter lines or ellipse checks when visual judgment alone does not establish the same form convincingly.

## Don't
- Treat the visible projected length as proof that the physical member became shorter or longer.
- Force one literal width along the entire limb and erase its natural taper.
- Compare unrelated people, body types, or species as though they share one canonical set of diameters.
- Measure through a knee, elbow, or knuckle bulge when a stable mid-shank offers the cleaner norm.

## Checklist
- Corresponding regions read as the same designed member despite different apparent lengths.
- The taper remains believable from parent mass to joint and terminal form.
- Any measuring aid proves the volume without becoming a required feature of the final drawing.
- The figure still has its own proportions rather than a generic cross-figure template.

## Notes
Constant width is a rational control for preserving size identity in depth. Apply the constant only within the chosen figure and between comparable regions of a tapered form; it must not erase individual anatomy, body type, or species difference.
