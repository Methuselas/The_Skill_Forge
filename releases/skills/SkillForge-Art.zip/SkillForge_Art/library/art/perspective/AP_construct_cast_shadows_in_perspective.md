---
object_id: AP_construct_cast_shadows_in_perspective
object_type: ap
name: Construct Cast Shadows in Perspective
library_path:
- art
- perspective
stage_binding: 4 final
lane_fit: both
foundation_role: specialization
routing_class: specialized
specialization_axis: method
foundation_object_id: none
tags:
- perspective
- shadow
- light
- projection
cross_links:
- rel: supports
  target_object_id: PAT_choose_cast_shadow_ray_model_from_light_geometry
- rel: supports
  target_object_id: PAT_project_cast_shadow_points_from_shade_boundary_to_receiver
reference:
  source_title: Perspective Drawing Handbook
  author: Joseph D'Amelio
confidence: high
references: []
variants:
- variant_id: VAR_reconstruct_shadows_across_complex_receivers
  variant_name: Reconstruct Shadows Across Changing Receivers
  variant_basis: method_sequence
  difference_from_foundation: 'Absorbs Norling''s receiver-turn checkpoint and extends it to inclined, multi-plane, and curved receivers: keep the same light ray but reconstruct each intersection on the new receiving geometry.'
  when_to_use: Use when a cast shadow crosses a wall, incline, curved form, or other receiver break.
  when_not_to_use: Do not continue a shadow as one flat screen-space contour across changing receiver geometry.
  absorbed_from_object_id: none
- variant_id: VAR_eissen_estimate_cast_shadow_from_simplified_proxy_geometry
  variant_name: Estimate Cast Shadow From Simplified Proxy Geometry
  variant_basis: method_sequence
  difference_from_foundation: 'Adds a fast product-sketch branch: reduce the caster to cheap proxy geometry, project only the few boundaries or cross-sections needed to establish direction and footprint, and for thin elevated forms project the top surface or cross-section as a pseudo-cast/drop shadow rather than reconstructing the whole contour. Offset the footprint visibly when that explains elevation and light direction better than a centered halo.'
  when_to_use: Use when an exploratory or explanatory sketch needs a believable cast shadow quickly and exact constructed projection would cost more time than the drawing requires.
  when_not_to_use: Do not use the estimate when technical accuracy, a difficult receiver, or close shadow-object alignment must be proven constructively; return to the foundation projection method instead.
  absorbed_from_object_id: none
---

# Construct Cast Shadows in Perspective

## Objective
Project cast shadows so the light direction, receiving plane, object position, and scene perspective all agree.

## Steps / Flow
**Entry Conditions**
- A cast shadow must be placed constructively rather than guessed from value alone.
- The receiving plane and the object's placement are sufficiently established to support projection.

**Persistent Invariants**
- Shade is the unlit side of the form; cast shadow is the region on another surface from which the light is blocked.
- The shade boundary supplies the points that cast the shadow.
- Sunlight is treated as parallel rays; a nearby point light uses rays diverging from the source.
- Shadow construction must remain consistent with the receiving plane's perspective.

**Flow**
1. **Classify the light.** Use `PAT_choose_cast_shadow_ray_model_from_light_geometry` to choose the parallel/directional or local-point-source ray model before projection.
2. **Find the casting boundary.** Use `PAT_project_cast_shadow_points_from_shade_boundary_to_receiver` to identify valid shade-boundary casting points and project them to the receiver. Keep the following branch steps as sequence-level setup and validation for that projection.
3. **Solve the receiving-plane direction.** Establish how shadow-bearing lines travel across that plane.
4. **Parallel sunlight branch.** Keep the light rays parallel in space. When oblique to the picture plane, use the light-ray vanishing point and the shadow-direction vanishing point in their corresponding perspective relationship.
5. **Local point-source branch.** Draw rays from the actual light source through the relevant shade-boundary points; use the source's projection onto the plane to establish the shadow direction for upright forms.
6. **Intersect constructions.** The intersections locate exact cast-shadow points; connect them in the order supplied by the casting boundary.
7. **Validate.** Confirm that lower directional light produces longer projected shadows and higher directional light shorter ones under the same scene geometry, and that local-light shadows fan consistently from the source.

**Failure / Rollback Rules**
- If the shadow direction contradicts the receiving plane, re-solve that plane before moving the shadow.
- If sunlight rays diverge, return to the parallel-light branch.
- If a point-source shadow behaves as parallel sunlight, return to source projection and ray intersections.
- If the casting boundary is wrong, repair the shade line before adjusting the shadow contour.

**Completion Criteria**
- Shadow points can be traced back to valid casting points and light rays.
- The shadow lies on the receiving plane rather than floating over it.
- Parallel and point-source lights produce visibly different but internally coherent projection behavior.
- The cast shadow supports, rather than contradicts, the scene's established depth field.

## Notes
The geometry serves a simple operational question: identify what blocks the light, establish how the rays travel, and solve where those rays meet the receiving surface.

`VAR_reconstruct_shadows_across_complex_receivers` remains a bounded variant under the conditions recorded in its variant metadata.

`VAR_eissen_estimate_cast_shadow_from_simplified_proxy_geometry` is the fast-sketch alternative when exact projection is unnecessary. Reduce a block to the relevant footprint or top corners, an upright cylinder to its top ellipse, a rounded irregular form to a few decisive horizontal cross-sections, or a horizontal cylinder to an enclosing square that can be projected before an ellipse is inscribed. For spherical or similarly simple rounded forms, estimate the slanted shadow ellipse from the established light direction and apparent width. The shortcut is successful when the shadow explains orientation and contact without pretending to be an exact construction.

For a thin elevated caster, the proxy can become extremely cheap: project its top surface or cross-section as the drop-shadow footprint. Keep the result subordinate to the established light direction, and avoid a mechanically centered symmetrical halo when an asymmetric offset makes the elevation and shadow direction easier to read.
