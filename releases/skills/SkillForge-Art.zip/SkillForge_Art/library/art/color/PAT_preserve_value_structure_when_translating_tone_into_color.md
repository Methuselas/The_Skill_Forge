---
object_id: PAT_preserve_value_structure_when_translating_tone_into_color
object_type: pattern
name: Preserve Value Structure When Translating Tone Into Color
library_path:
- art
- color
stage_binding: 3 rough
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- rendering
- color
- value
- tone
- light_shadow
- hierarchy
- color_translation
cross_links:
- rel: related_to
  target_object_id: PAT_consolidate_resolved_form_with_tone
- rel: related_to
  target_object_id: PAT_separate_local_value_from_light_and_shadow_effect
reference:
  source_title: Creative Illustration
  author: Andrew Loomis
confidence: high
references: []
variants: []
---
# Preserve Value Structure When Translating Tone Into Color

## Pattern Rule
**IF** a tonal design already establishes the form, lighting, and hierarchy the picture depends on
**THEN** carry those relationships into color deliberately, checking that hue and chroma choices do not accidentally destroy the value separations or large light/shadow grouping that made the tonal version work
**ELSE** resolve the value structure first or consciously redesign it rather than expecting color to repair an unresolved tonal statement.

## Do
- Identify which relative value relationships are carrying form, focal hierarchy, and light/shadow grouping before adding full color.
- Translate the large value families first, then introduce hue, chroma, temperature, reflected color, and local variation inside that structure.
- Recheck the colored version at reduced size or in grayscale when a passage becomes harder to read after color is introduced.
- Preserve enough separation between important neighboring forms that color differences do not become the only thing holding them apart.
- Allow color to alter the tonal plan when the change is intentional and improves the picture; then treat the new relationship as a redesign rather than an accidental drift.
- When subdividing a strong parent mass, prefer hue, chroma, or temperature variation that stays inside the parent value family unless a real value break is necessary; extra values should not fracture a large light or dark shape without cause.

## Don't
- Do not assume an attractive hue or high chroma will compensate for a collapsed value hierarchy.
- Do not force every colored passage to match the grayscale numerically; color perception, material, illumination, and atmosphere can require compression or selective shifts.
- Do not treat local color as independent of light and surrounding influence.
- Do not use grayscale checking as proof that hue and chroma are unimportant; it is only a diagnostic for value structure.

## Checklist
- The main light/shadow and focal value relationships remain legible after color is added.
- Important forms do not merge accidentally because their colored values drifted together.
- Hue and chroma choices support rather than obscure the intended hierarchy.
- Any substantial tonal change introduced during color is deliberate and re-evaluated as part of the design.

## Notes
Form and pictorial relationships still depend on a coherent value structure after hue is introduced. Comparing a small grayscale life study with a color version can reveal where hue, chroma, or local-color expectation disguises a value error. This does not reduce color to grayscale: value remains one structural axis, while hue, chroma, temperature, material, and illumination can add or deliberately reshape the design.
