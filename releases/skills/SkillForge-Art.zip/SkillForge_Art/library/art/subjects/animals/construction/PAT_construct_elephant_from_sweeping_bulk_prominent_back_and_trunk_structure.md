---
object_id: PAT_construct_elephant_from_sweeping_bulk_prominent_back_and_trunk_structure
object_type: pattern
name: Construct an Elephant From Sweeping Bulk, a Prominent Back, and Trunk Structure
library_path:
- art
- subjects
- animals
- construction
stage_binding: 2 block
lane_fit: both
foundation_role: specialization
routing_class: specialized
specialization_axis: domain
foundation_object_id: PAT_block_quadruped_from_dorsal_axis_and_three_body_masses
tags:
- animal_drawing
- elephant
- proboscidean
- animal_construction
- heavy_body
- trunk
- skeletal_landmarks
cross_links:
- rel: related_to
  target_object_id: PAT_route_animal_gesture_through_governing_action_line
- rel: related_to
  target_object_id: PAT_design_surface_anatomy_as_microgesture_on_parent_forms
reference:
  source_title: The Art of Animal Drawing
  author: Ken Hultgren
confidence: high
references: []
variants: []
---

# Construct an Elephant From Sweeping Bulk, a Prominent Back, and Trunk Structure

## Pattern Rule
**IF** an elephant block has become one soft oval with four posts and a hose-like trunk
**THEN** establish the large sweeping body masses first, keep the dorsal/back structure readable through the bulk, preserve the angular changes that organize the head and supports, and build the trunk as a tapered structured form before adding lesser surface forms
**ELSE** use the broader quadruped mass scaffold when the subject does not need elephant-specific bulk, back, and trunk relationships.

## Do
- Start with the largest rounded masses and the overall sweep of the body. Round in the main forms before adding smaller forms and finish.
- Keep a readable dorsal route across the top of the body. The vertebral column is especially prominent on the back, so the upper contour should not dissolve into an unstructured dome.
- Let the bulk contain angular structural changes, especially from the front and three-quarter view. The head, shoulder region, legs, and feet still need changes of plane and direction even when the silhouette is massive.
- Attach the trunk from the constructed head and taper it through its length instead of drawing a uniform tube. On the underside, preserve the flatter, divided surface treatment before elaborating wrinkles and texture.
- Use the skeleton as an explanation for visible depressions and attachments rather than copying bone shapes onto the skin. For example, let the skull structure explain the hollow cheek.
- Add ears, tusks, skin folds, toes, and small contour breaks only after the main body, head, limb supports, and trunk already read.

## Don't
- Do not make sheer size an excuse for featureless roundness; preserve angular structure inside the big sweeping forms.
- Do not turn the prominent back structure into an exposed bony ridge in every individual or view. Use it as a construction cue and check the intended reference.
- Do not make the trunk a smooth rubber hose whose underside, taper, attachment, and directional changes are all identical.
- Do not trace the skeleton literally through the finished surface; let it explain mass placement, cheek relief, and support relationships.
- Do not spend on wrinkles and small skin marks before the large rounded masses and lesser structural forms are separated.

## Checklist
- The body reads as large and sweeping without collapsing into one undifferentiated oval.
- A clear dorsal/back route organizes the top of the mass before surface detail.
- Head, shoulder, leg, and foot changes remain structurally angular enough to support the bulk.
- The trunk attaches to the head, tapers, and has a deliberate underside rather than a uniform cylindrical treatment.
- Skeletal landmarks explain visible depressions and attachments without becoming literal surface lines.
- The elephant remains structurally readable when wrinkles, tusks, and decorative detail are removed.

## Notes
Build the elephant with “big, sweeping forms” while retaining its angular structure and prominent back. Use the skeleton to explain the hollow cheek, distinguish the flatter divided underside of the trunk, and progress from main forms to lesser forms to finish. Stylized examples do not establish fixed anatomical measurements.
