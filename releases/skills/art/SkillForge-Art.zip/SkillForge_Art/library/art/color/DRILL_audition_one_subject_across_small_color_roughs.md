---
object_id: DRILL_audition_one_subject_across_small_color_roughs
object_type: drill
name: Audition One Subject Across Small Color Roughs
library_path:
- art
- color
stage_binding: 0 design
lane_fit: teach
foundation_role: specialization
routing_class: teaching
specialization_axis: method
foundation_object_id: PAT_choose_color_strategy_to_fit_subject_purpose_and_viewing_context
tags:
- rendering
- color
- color_rough
- palette
- iteration
- thumbnail
cross_links:
- rel: teaches
  target_object_id: PAT_choose_color_strategy_to_fit_subject_purpose_and_viewing_context
- rel: teaches
  target_object_id: PAT_unify_palette_with_shared_color_influence
- rel: related_to
  target_object_id: DRILL_recompose_one_subject_across_tonal_keys_and_plans
reference:
  source_title: Creative Illustration
  author: Andrew Loomis
confidence: high
references: []
target_skill: deliberately comparing several picture-level color conceptions before committing to a finished palette
variants:
- variant_id: VAR_olofsson_duplicate_near_final_render_for_global_finish_auditions
  variant_name: Duplicate a Near-Final Render for Global Finish Auditions
  variant_basis: method_sequence
  difference_from_foundation: 'Moves the audition later in the process: freeze one substantially resolved geometry base, duplicate
    it identically, then vary picture-level value, contrast, hue, saturation, temperature, background key, and focal highlights
    so finish decisions can be compared without design changes contaminating the test.'
  when_to_use: Use when product geometry is stable but the final color, mood, background, or contrast treatment is still undecided.
  when_not_to_use: Do not use late finish auditions to avoid fixing unresolved geometry, and do not alter the product design
    between copies if the goal is a controlled finish comparison.
  absorbed_from_object_id: none
- variant_id: VAR_barber_recolor_fixed_subject_to_test_semantic_shift
  variant_name: Recolor a Fixed Subject to Test Semantic Shift
  variant_basis: emphasis
  difference_from_foundation: Holds drawing, composition, identifying forms, and normally the major value organization stable while
    deliberately replacing the subject's expected color language with an incongruent palette so the semantic effect of color can
    be isolated and compared against a control version.
  when_to_use: Use when diagnosing how strongly a subject's reading depends on expected or culturally learned color conventions,
    or when considering an intentional semantic inversion through color.
  when_not_to_use: Do not use when physical illumination or local-color fidelity is the primary assignment, and do not generalize
    the result into a universal hue-meaning rule without support from the intended audience and context.
  absorbed_from_object_id: none
- variant_id: VAR_hammond_hold_subject_color_fixed_while_auditioning_background_context
  variant_name: Hold Subject Color Fixed While Auditioning Background Context
  variant_basis: emphasis
  difference_from_foundation: Narrows the color audition to one controlled variable by keeping the subject drawing, major value organization,
    and subject color treatment substantially fixed while changing only the surrounding or background color field, so context-driven shifts
    in separation, prominence, harmony, and focal strength can be compared directly.
  when_to_use: Use when the subject palette is already acceptable but the surrounding color field is unresolved and you need to test how
    background context changes the subject's apparent strength or color relationships.
  when_not_to_use: Do not use when the background must represent a specific physical illumination or environment, and do not treat a
    textbook complementary pairing as automatically superior to other contextually appropriate surrounds.
  absorbed_from_object_id: none
---

# Audition One Subject Across Small Color Roughs

## Practice Task
Make four to six small color roughs of substantially the same subject, changing the overall color conception while keeping drawing and detail simple enough for direct comparison.

## Target Skill
Separating subject choice from color strategy so palette, chroma distribution, temperature, and unifying influence can be tested cheaply before final rendering.

## Setup
Choose one subject with a stable crop and readable value structure. Prepare four to six small thumbnail boxes. If the final image will be seen against a known page, cover, dark field, light field, or block of copy, include a simple representation of that surround in the comparison.

## Instructions
1. Reduce the subject to its largest value and color masses; keep the drawing nearly identical across all versions.
2. Make one rough with a strongly unified or toned palette in which most colors share a common influence.
3. Make one rough with a deliberately restricted parent palette and derive most mixtures from that small set.
4. Make one rough with quieter broad color and a limited area of cleaner or stronger chroma for emphasis.
5. Make at least one additional rough with a materially different warm/cool balance, dominant family, or degree of greying that still fits the subject.
6. Keep each version small and inexpensive. Do not solve texture, anatomy, or finish differences that make the color variable harder to compare.
7. View all roughs together at small size and, when relevant, against the anticipated surrounding field. Compare hierarchy, unity, readability, mood, and how quickly the intended subject or focal area registers. For large-format or distance-read work, also test the rough at a scaled equivalent or physically across the room so failure of the big color/value masses stops the design before expensive finish.
8. Select the strongest color conception for the picture's purpose, then carry that strategy into the larger development rather than combining every attractive color from all versions.

## Success Check
- The subject and major value organization remain substantially stable while the color conception changes clearly from rough to rough.
- At least three alternatives differ in picture-level palette logic rather than only in tiny local hue substitutions.
- The selected rough is chosen for the intended visual effect and context, not because it contains the most saturated color.
- When the final is distance-read, the selected rough still carries at the intended scaled viewing condition.
- The exercise ends with a clear palette direction that can guide later rendering.

## Common Failures
- Changing composition, lighting, pose, and color simultaneously so the color strategies cannot be compared.
- Rendering one rough far beyond the others and selecting it because it has more finish.
- Producing several nearly identical palettes with only cosmetic hue shifts.
- Combining all of the strongest accents from every rough into the final image and destroying the hierarchy the comparison was meant to establish.

## Notes
Small color roughs make palette decisions cheap enough to compare before they become entangled with finish. The exercise complements tonal thumbnail drills: those vary value organization, while this drill keeps the subject and basic structure relatively stable and varies the color conception itself. Include the anticipated surround whenever page, cover, display, or reproduction context will materially change the palette's apparent strength. For large-format work, judge the color rough from the intended distance so small finish cannot disguise weak mass relationships.

`VAR_olofsson_duplicate_near_final_render_for_global_finish_auditions` freezes the design and moves the experiment to picture-level finish. Duplicate one stable base, change only the global value/color/background/highlight treatment, and compare the copies side by side so one version cannot win merely because its geometry also changed.

`VAR_barber_recolor_fixed_subject_to_test_semantic_shift` turns the same controlled comparison into a semantic stress test. Keep the subject structure and major value organization stable, compare an expected color treatment against one or more deliberately incongruent conceptions, then identify whether changes in reading come from hue family, chroma, value relationship, temperature, palette convention, or learned color-to-subject association. Treat the result as context-dependent evidence rather than a universal color dictionary.

`VAR_hammond_hold_subject_color_fixed_while_auditioning_background_context` isolates the surrounding field as the variable. Keep the subject drawing, major values, and subject colors stable across copies, change only the background or surround, then compare subject/background separation, focal strength, harmony, and which subject colors appear more or less prominent. Choose the surround for the picture's actual purpose rather than for maximum contrast alone.
