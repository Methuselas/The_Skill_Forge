---
object_id: PAT_choose_texture_process_by_control_and_spread
object_type: pattern
name: Choose Texture Process by Control and Spread
library_path:
- art
- rendering
stage_binding: 4 final
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- texture
- wet_on_wet
- mark_control
- brushwork
- surface
cross_links:
- rel: supports
  target_object_id: PAT_render_material_from_optical_response
- rel: related_to
  target_object_id: PAT_control_brush_ink_tone_with_moisture_and_pressure
reference:
  source_title: The Artist's Guide to Animal Anatomy
  author: Gottfried Bammes
confidence: high
references: []
variants:
- variant_id: VAR_barber_tilt_support_to_control_gravity_driven_wash_flow
  variant_name: Tilt Support to Control Gravity-Driven Wash Flow
  variant_basis: medium
  difference_from_foundation: Makes support angle an intentional control variable for fluid watercolor passages, using back-and-forth redistribution to even a field, one-way tilt to create visible directional flow, and counter-tilt to oppose a run that exceeds the target.
  when_to_use: Use when a broad or graded wash benefits from gravity-driven redistribution or when a directional run should remain visible as part of the passage.
  when_not_to_use: Do not tilt by default when the passage needs locally stationary pooling, crisp dry-ground control, or a flow direction that gravity would fight; return the support to a stable position once the intended movement has been reached.
  absorbed_from_object_id: none
---

# Choose Texture Process by Control and Spread

## Pattern Rule
**IF** a surface texture depends on soft irregularity, broken edges, or fluent brush shapes rather than exact contour control **THEN** choose the medium, brush load, and ground wetness by how much spreading and edge unpredictability the effect can tolerate, and let that native behavior carry the texture **ELSE** stay on a drier, more controllable ground and build the surface with stable marks or shapes.

## Do
- Use dry-ground linear media when sharp definition is part of the surface read; a pen or similarly stable point keeps edges more explicit than a running wash.
- Use sprayed or evenly damp paper when a fuzzy or velvety edge is useful, but budget for the fact that ink and watercolor spread beyond the exact path of the tool.
- Use half-dry opaque paint with a thick brush when a rough, bristly, or shaggy surface needs broken texture with more control than wet-on-wet work provides.
- Let wet-on-wet watercolor create soft, airy, fluffy transitions when the uncontrolled run of the pigment is an asset rather than a defect.
- On a dry ground with a well-filled brush, vary shape width through pressure, trail the stroke, and lift cleanly; choose a brush whose physical width is appropriate to the scale of the depicted form.
- Use resist processes when markings are better carried by protected light shapes than by drawing every edge directly.
- When a running or spreading process produces useful accidental texture, preserve the chance effect where it strengthens form; intervene only when uncontrolled spread begins to erase articulation or the intended mass relationship.
- When the target texture is stochastic, prefer a process that naturally varies event shape and placement rather than manually spacing identical marks. If a stamp-like source is reused, perturb orientation and placement so the mechanism does not reveal itself as an obvious repeating tile.
- When the field is already dark, consider a subtractive or light-mark route when carving negative-space texture is cleaner than rebuilding the same transition entirely with dark marks. Keep the resulting irregularity subordinate to form, value, and focal hierarchy.

## Don't
- Demand crisp, repeatable contours from a process whose useful character comes from spreading on a wet ground.
- Force every texture through the same mark language merely because one medium is familiar.
- Turn half-dry opaque texture into a hard-edged cutout; broken coat character still has to belong to a living form.
- Draw a laborious second-medium preliminary sketch when the chosen texture process depends on direct, fresh execution and the underdrawing would dictate marks the final medium should discover for itself.
- Repeat an identical stochastic stamp at obvious intervals or orientations when the surface is supposed to feel irregular.

## Checklist
- The chosen process has the right balance of controllability and natural irregularity for the intended surface.
- Wet or running passages are allowed to spread where softness helps and are not being corrected back into mechanical edges.
- Dry or half-dry passages create deliberate broken texture rather than accidental scratchiness.
- Brush width, pressure change, trailing, and lift produce shapes at a scale appropriate to the drawing.
- The texture reads from the behavior of the medium while the underlying form remains legible.
- Repeated stochastic marks do not reveal an accidental tile or stamp pattern, and subtractive/light marks are used only where they clarify the intended texture or transition.

## Notes
The useful decision is not that one named medium belongs to one named texture. The demonstrated continuum runs from dry-ground pen for definition, through sprayed or damp grounds that let ink spread from fuzzy to velvety, half-dry opaque paint for rapid roughness with more control, wet-on-wet watercolor for softness at the cost of predictability, and a loaded brush on dry paper that can move from broad shape to fine line through pressure, trailing, and lift. This Pattern keeps that control-versus-spread tradeoff portable instead of turning the examples into fixed animal-texture recipes. A complementary treatment reinforces the same principle from the opposite direction: chance effects from running ink can be welcomed as texture, but they remain useful only while the form stays articulated enough to read. Later inking examples extend that logic to deliberately stochastic marks: vary placement and orientation when reusing a stamp-like source so the process does not expose itself as a repeating tile, and consider carving light texture from a dark field when a subtractive route produces the target transition more directly.

`VAR_barber_tilt_support_to_control_gravity_driven_wash_flow` adds support orientation to that control system for fluid watercolor. Tilt can work in an evening mode, redistributing a flat or gradated field; in a directional mode, letting gravity remain visible as a run; or in a recovery mode, counter-tilting when the flow exceeds the target. Return the support to a stable position once the desired movement is reached rather than making tilt a universal watercolor setup.
