---
object_id: PAT_choose_viewpoint_to_strengthen_story_effect
object_type: pattern
name: Choose Viewpoint to Strengthen the Story Effect
library_path:
- art
- composition
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- composition
- viewpoint
- camera
- storytelling
- staging
cross_links:
- rel: related_to
  target_object_id: PAT_establish_eye_level_and_vanishing_directions
- rel: related_to
  target_object_id: PAT_repeat_with_variation_to_balance_coherence_and_interest
reference:
  source_title: How to Draw Comics the Marvel Way
  author: Stan Lee and John Buscema
confidence: high
references: []
variants:
- variant_id: VAR_loomis_set_eye_level_from_character_or_power_relationship
  variant_name: Set Eye Level from Character or Power Relationship
  variant_basis: context
  difference_from_foundation: 'Loomis makes eye height an explicit psychological relationship rather than merely a dramatic
    camera choice: a low eye level can make adults, architecture, or a subject tower over the implied viewer; a high eye level
    can create distance, overview, or a spectator-like relation. The useful question is whose eye height the picture psychologically
    belongs to.'
  when_to_use: Use when the scene's intended power, age, intimacy, vulnerability, grandeur, or spectator relationship is not
    being expressed strongly enough by a neutral eye level.
  when_not_to_use: Do not treat low angle as automatically heroic or high angle as automatically weak. Story context, pose,
    lens, scale, staging, and cultural convention can reverse the effect; retain a neutral eye level when comparison or straightforward
    clarity matters more.
  absorbed_from_object_id: none
- variant_id: VAR_dumitrescu_cant_horizon_to_increase_instability_and_action
  variant_name: Cant the Horizon to Increase Instability and Action
  variant_basis: emphasis
  difference_from_foundation: 'Adds camera roll as a deliberate story choice: compare a level view with a canted horizon and
    keep the tilt only when instability, suspense, speed, or action becomes clearer.'
  when_to_use: Use when the scene needs controlled disequilibrium or heightened kinetic pressure and a level camera feels
    too settled.
  when_not_to_use: Do not cant the horizon as decoration, and do not let camera roll excuse incoherent perspective or accidental
    staging.
  absorbed_from_object_id: none
- variant_id: VAR_eissen_choose_viewpoint_for_product_information
  variant_name: Choose the View That Reveals the Product's Most Useful Information
  variant_basis: context
  difference_from_foundation: 'Adds a descriptive product-design criterion to camera choice: identify the dominant informative
    face and keep it less foreshortened than secondary faces, expose enough neighboring surfaces to make volume legible, and
    reject views where important parts overlap and hide one another. Deliberately favor a high, low, side, or user-like view
    when the current design problem lives on a particular surface or interaction; the most informative view may change as
    the design question changes.'
  when_to_use: Use when the drawing is meant to investigate, compare, explain, or develop a product and the most useful camera
    is the one that makes its relevant shape or functional relationships easiest to read.
  when_not_to_use: Do not force an oblique or dramatic view when a side, front, or other direct view communicates the needed
    information more clearly, do not add foreshortening past the point where needed surface information disappears, and do
    not expect one view to explain every side or relationship of a product.
  absorbed_from_object_id: none
- variant_id: VAR_schmid_select_observed_viewpoint_and_arrangement_for_pictorial_intent
  variant_name: Select Observed Viewpoint and Arrangement for Pictorial Intent
  variant_basis: context
  difference_from_foundation: Searches plausible viewpoints, crops, and—where controllable—arrangements for the observed section
    whose large shapes, negative spaces, value pattern, focal hierarchy, and directional relations best support the active
    pictorial target, even when the strongest solution is quiet rather than dramatic.
  when_to_use: Use when painting or drawing from an existing subject and the main creative choice is which visible arrangement
    and view best serves the intended picture.
  when_not_to_use: Do not redesign a naturally compelling arrangement merely to demonstrate compositional cleverness, and
    do not move uncontrollable subject matter that can only be solved by observer position, crop, timing, or selection.
  absorbed_from_object_id: none
---

# Choose Viewpoint to Strengthen the Story Effect

## Pattern Rule
**IF** several camera positions could depict the same subject or story beat
**THEN** choose the viewpoint whose scale, elevation, angle, and spatial emphasis make the intended dramatic or emotional effect read most strongly while keeping the action understandable
**ELSE** retain the straightforward view when clarity, comparison, continuity, or deliberate neutrality matters more than added drama

## Do
- State the intended effect before choosing the camera: urgency, menace, isolation, intimacy, scale, calm, or another readable purpose.
- Test more than one plausible view while the decision is still cheap; the same action can feel radically different from above, below, near, far, or off-axis.
- After selecting the view, hand it to the perspective system rather than treating a dramatic angle as permission for inconsistent geometry.
- Judge the camera by what it makes the viewer feel and understand, not by how unusual the angle looks in isolation.

## Don't
- Do not default to a flat eye-level view merely because it is easiest to draw when it weakens the intended effect.
- Do not choose a severe angle only to make the picture look dynamic if it hides the important action or produces spatial confusion.
- Do not redesign the story beat to justify a camera experiment; compare viewpoints against the same underlying event.

## Checklist
- The selected viewpoint strengthens a named story or emotional effect.
- The key action remains legible from that view.
- Eye level, vanishing behavior, and object orientation can be constructed coherently after the choice is made.
- A simpler view would not communicate the intended effect more clearly.

## Notes
Marvel demonstrates the same doorway entrance, telephone confrontation, and villain pose from comparatively flat and more charged camera positions. The important transferable lesson is a design decision: perspective does not only solve a chosen camera; composition must first choose the camera that best serves the picture.

`VAR_loomis_set_eye_level_from_character_or_power_relationship` adds a character-centered viewpoint question: decide whose eye height the picture implicitly occupies, then use that relation to support power, scale, age, intimacy, or detachment without turning low/high-angle tendencies into fixed emotional formulas.

`VAR_dumitrescu_cant_horizon_to_increase_instability_and_action` adds camera roll to the viewpoint toolbox. Test the same scene level and tilted; preserve the cant only when it contributes a needed instability or action read and the perspective still holds together.
`VAR_eissen_choose_viewpoint_for_product_information` adds a descriptive product-design branch to the same camera decision. Choose the side and elevation by what the sketch must reveal: direct profile is often best for silhouette and side-view comparison; controlled foreshortening can add depth but progressively sacrifices visible surface information; a higher user-like view can expose controls; and a three-dimensional view becomes necessary when form transitions, connections, or hidden spatial relationships are the information being designed.

The Eissen product-information route is diagnostic rather than dramatic: identify the face that carries the current design question, keep that face readable, expose only enough secondary surface to explain volume, and watch for self-overlap that hides important parts. A user-like viewpoint is one useful criterion, not an automatic default.

`VAR_schmid_select_observed_viewpoint_and_arrangement_for_pictorial_intent` applies viewpoint choice to observational design. Move the observer, crop, wait, select another visible section, or rearrange a controllable subject so the large pictorial relationships support the active target; the best view need not be the most dramatic one.

- Looking down can diminish, expose, isolate, or subordinate; looking up can empower, monumentalize, or make the environment oppressive. Apply this to locations and structures as well as people.
- Viewpoint can also progress during a moving shot so the power relationship changes as information is revealed.
