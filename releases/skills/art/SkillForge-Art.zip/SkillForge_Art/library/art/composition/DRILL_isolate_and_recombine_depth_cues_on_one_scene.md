---
object_id: DRILL_isolate_and_recombine_depth_cues_on_one_scene
object_type: drill
name: Isolate and Recombine Depth Cues on One Scene
library_path:
- art
- composition
stage_binding: 0 design
lane_fit: teach
foundation_role: specialization
routing_class: specialized
specialization_axis: method
foundation_object_id: PAT_design_depth_by_coordinating_spatial_cues
tags:
- composition
- depth
- spatial_cues
- deliberate_practice
- atmosphere
cross_links:
- rel: teaches
  target_object_id: PAT_design_depth_by_coordinating_spatial_cues
- rel: related_to
  target_object_id: PAT_grade_depth_with_atmospheric_effect
reference:
  source_title: Art Fundamentals
  author: David Smit
confidence: high
target_skill: coordinate multiple depth cues while understanding the contribution and tradeoff of each cue
references: []
variants:
- variant_id: VAR_stanchfield_reawaken_depth_sensation_by_alternating_monocular_and_binocular_view
  variant_name: Reawaken Depth Sensation by Alternating Monocular and Binocular View
  variant_basis: method_sequence
  difference_from_foundation: Before isolating pictorial depth cues on the page, compare a simple near/far arrangement with one eye and then both eyes so the stronger felt separation of bodies in space becomes an explicit perceptual target for the drawing.
  when_to_use: Use when perspective construction is technically correct but the drawing still feels flat, or when repeated schematic practice has dulled sensitivity to the actual spatial interval between near and far forms.
  when_not_to_use: Do not treat binocular vision as a pictorial technique that can be copied directly onto a flat page; after the perceptual warm-up, construct depth with the existing overlap, scale, projection, ground, negative-space, and atmospheric cues.
  absorbed_from_object_id: none
---

# Isolate and Recombine Depth Cues on One Scene

## Practice Task
Use one simple scene to make a matched series in which depth cues are introduced separately and then recombined deliberately.

## Target Skill
Recognize what individual depth cues contribute and coordinate only the cues that support the intended near-to-far read.

## Setup
Choose a scene with at least three depth planes and a few repeatable forms. Keep the basic subject and camera stable across the series so the cue changes can be compared directly.

## Instructions
1. Establish the scene using mainly overlap and diminishing scale; keep atmosphere and detail grading restrained.
2. Make a second pass that separates foreground, middle, and background primarily through progressive simplification of internal information.
3. Make a third pass that adds a deliberate near-to-far value or contrast grade while preserving the same spatial order.
4. Make a fourth pass that tests an atmospheric hue or chroma change appropriate to the scene conditions instead of assuming one fixed color direction.
5. Compare the versions and identify which cue strengthened depth, which duplicated another cue, and which introduced an unwanted tradeoff.
6. Build a final version using only the mutually reinforcing cues needed for a convincing spatial read.

## Success Check
- Every pass preserves the same scene, camera, and basic spatial order; a deeper-looking version caused by changing the layout does not count as evidence for a depth cue.
- The overlap/scale, detail-grading, value/contrast, and atmospheric-color passes each make their own contribution visible before the cues are recombined.
- The atmospheric hue or chroma treatment follows the pictured conditions rather than defaulting automatically to a generic blue-distance recipe.
- The final version uses only mutually reinforcing cues at useful strengths instead of stacking every tested effect at maximum intensity.
- The comparison names which cue strengthened depth, which duplicated another cue or added little, and which introduced a tradeoff; the final selection is justified by those observations rather than by preference alone.

## Common Failures
- Changing the camera or subject so much between passes that the depth cues cannot be compared.
- Treating blur or fog as the only depth mechanism.
- Applying a generic blue-distance recipe when the actual atmosphere or lighting suggests another color shift.
- Combining every tested cue at full strength until the image looks mechanically processed.

## Notes
The exercise separates the illusion of depth into observable contributors before recombining them. Its purpose is diagnostic: a practitioner should leave knowing which cues carry the spatial read and how far each can be pushed before style, clarity, or atmosphere begins to suffer.

`VAR_stanchfield_reawaken_depth_sensation_by_alternating_monocular_and_binocular_view` adds a perceptual warm-up for artists who understand perspective rules but no longer strongly feel near-to-far separation. Place one hand or simple form near and another materially farther away; compare the arrangement with one eye and then both eyes, attend to the spatial interval rather than object identity, then make a quick drawing that rebuilds that felt separation with ordinary pictorial cues. The binocular comparison supplies a sensation to aim for, not a stereoscopic method the flat drawing can literally reproduce.
