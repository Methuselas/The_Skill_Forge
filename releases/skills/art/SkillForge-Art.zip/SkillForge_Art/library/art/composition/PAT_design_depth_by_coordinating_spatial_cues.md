---
object_id: PAT_design_depth_by_coordinating_spatial_cues
object_type: pattern
name: Design Depth by Coordinating Spatial Cues
library_path:
- art
- composition
stage_binding: 0 design
lane_fit: both
foundation_role: foundation
routing_class: general
specialization_axis: none
foundation_object_id: none
tags:
- composition
- depth
- spatial_hierarchy
- perspective
- atmosphere
cross_links: []
reference:
  source_title: Keys to Drawing
  author: Bert Dodson
confidence: high
references: []
variants:
- variant_id: VAR_smit_use_repeated_known_size_anchors_across_depth
  variant_name: Use Repeated Known-Size Anchors Across Depth
  variant_basis: method_sequence
  difference_from_foundation: Repeats elements of comparable real size at different depths so their diminishing apparent size
    becomes a readable spatial rhythm; familiar human-scale elements can also calibrate the apparent scale of the environment.
  when_to_use: Use when a large environment has weak depth or scale and equivalent objects can be placed coherently through
    the scene.
  when_not_to_use: Do not compare objects whose real sizes are materially different or place scale anchors that violate the
    perspective field simply to force a depth read.
  absorbed_from_object_id: none
- variant_id: VAR_smit_separate_depth_planes_with_simplification_not_automatic_blur
  variant_name: Separate Depth Planes With Simplification, Not Automatic Blur
  variant_basis: style
  difference_from_foundation: For a graphic or stylized depth treatment, separates foreground, middle, and background by reducing
    internal detail, breakup, and shading with distance while allowing silhouette edges to remain intentionally crisp.
  when_to_use: Use when a stylized image needs clear depth without photographic depth-of-field blur and atmospheric conditions
    do not require soft distant edges.
  when_not_to_use: Do not treat crisp distance as a universal optical rule; use atmospheric edge loss or softness when the
    actual or designed environment calls for it.
  absorbed_from_object_id: none
---

# Design Depth by Coordinating Spatial Cues

## Pattern Rule
**IF** the picture's near-to-far structure reads weakly or the intended sense of depth needs emphasis
**THEN** coordinate several compatible depth cues - such as overlap, diminishing size, convergence, and reduced distant edge/contrast clarity - and decide how strongly each should contribute to the spatial statement
**ELSE** avoid intensifying depth cues merely by habit when the subject or composition benefits from a flatter or more neutral spatial read

## Do
- Decide which zones or forms must read as near, middle, and far before strengthening individual cues.
- Combine cues that agree about the same depth order instead of asking one device to carry the entire illusion.
- Increase overlap, size change, convergence, or atmospheric reduction selectively when expressive depth needs a stronger read.
- Keep technical perspective and rendering logic responsible for their own geometry and optical behavior while composition decides their visual emphasis.
- Let the task determine fidelity: observational and technical work should stay close to the actual view, while expressive illustration may intensify bounded cues knowingly.

## Don't
- Intensify one cue until it contradicts the others.
- Invent spatial evidence casually in work whose purpose is accurate observation or technical description.
- Use atmospheric softening to repair wrong convergence, or overlap to hide a bad scale relationship.
- Assume every composition benefits from maximum depth; deliberate flatness is also a valid design choice.

## Checklist
- Major depth cues agree about which forms are near and far.
- No single cue is compensating for a contradiction in another.
- The amount of depth emphasis serves the subject and composition rather than following a fixed recipe.
- If a cue has been exaggerated, the exaggeration is intentional and still preserves a coherent spatial read.

## Notes
Overlap, diminution, convergence, and softening of distant edges or contrast can reinforce one another to create depth and may be intensified for effect. This Pattern owns the compositional decision to coordinate and emphasize those cues; Perspective and Rendering retain ownership of accurate convergence and atmospheric or edge behavior.

`VAR_smit_use_repeated_known_size_anchors_across_depth` turns equivalent real-size elements into depth calibrators. Their apparent-size changes should agree with the spatial field, and familiar human-scale anchors can also communicate the magnitude of surrounding forms.

`VAR_smit_separate_depth_planes_with_simplification_not_automatic_blur` provides a graphic depth route: simplify internal information across planes while keeping selected silhouettes crisp. It is an alternative style treatment, not a claim that distant edges are inherently hard.
