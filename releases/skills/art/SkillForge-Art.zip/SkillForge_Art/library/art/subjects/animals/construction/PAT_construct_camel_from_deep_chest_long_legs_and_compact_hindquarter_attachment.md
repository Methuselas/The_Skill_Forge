---
object_id: PAT_construct_camel_from_deep_chest_long_legs_and_compact_hindquarter_attachment
object_type: pattern
name: Construct a Camel From a Deep Chest, Long Legs, and Compact Hindquarter Attachment
library_path:
- art
- subjects
- animals
- construction
stage_binding: 2 block
lane_fit: both
foundation_role: specialization
routing_class: specialized
specialization_axis: domain
foundation_object_id: PAT_block_quadruped_from_dorsal_axis_and_three_body_masses
tags:
- animal_drawing
- camel
- camelid
- animal_construction
- proportion
- hump
cross_links:
- rel: related_to
  target_object_id: PAT_construct_animal_head_from_cranial_base_nasal_bridge_and_muzzle
- rel: related_to
  target_object_id: PAT_compare_related_animal_types_with_proportion_boxes
reference:
  source_title: The Art of Animal Drawing
  author: Ken Hultgren
confidence: high
references: []
variants: []
---

# Construct a Camel From a Deep Chest, Long Legs, and Compact Hindquarter Attachment

## Pattern Rule
**IF** a camel block reads like a generic long-legged quadruped whose identity depends mainly on the hump
**THEN** organize the body around a deep chest and long leggy frame, keep the hind-leg attachment compact relative to the trunk, construct the head with its own eye-versus-mouth directional relationship, and add the hump or humps as soft masses carried on top of the torso rather than as skeletal peaks
**ELSE** use the broader quadruped mass scaffold when the subject does not need camel-specific proportion and head relationships.

## Do
- Establish the deep chest before refining the belly contour so the long legs hang from a body with enough vertical mass to balance them.
- Keep the upper hindquarter attachment visually compact against the larger chest and longer leg structure across side, front, and rear views.
- Let the head keep its nonparallel facial directions instead of automatically making the eye line follow the mouth line; place the eyes broadly on the constructed head before polishing lids or lashes.
- Treat the hump silhouette as an added soft body mass. Keep it separate from the backbone and preserve the spinal route beneath the outer hump contour.
- Check front and rear views as well as profile so the long limbs, narrow rear attachment, chest width, and hump placement do not work only in silhouette.
- Match the number and shape of humps to the actual subject or reference; more than one hump configuration exists, so no single outline is universal.

## Don't
- Paste a hump onto a horse-like or cattle-like body and expect that surface cue to carry the camel construction.
- Spread the hind-leg attachment so broadly that the small rear support relationship disappears.
- Force the eye and mouth onto one shared slant simply because that alignment works for another animal head.
- Turn the hump into a bony extension of the vertebral column when blocking the skeleton beneath the surface.
- Copy one source specimen's hump count, leg proportions, or head angle as a fixed formula for every camel.

## Checklist
- The animal still reads as camel-like when the hump contour is temporarily hidden.
- The chest is deep enough to counter the length of the legs without becoming a generic barrel.
- The hind legs attach through a compact rear region rather than an over-wide pelvic block.
- The head preserves the observed relationship between eye direction and mouth direction through the turn.
- The hump or humps sit on the torso as soft masses while the spinal route remains structurally separate underneath.
- A front or rear check preserves the same leg spacing and body-width logic established in profile.

## Notes
A camel's identifying construction can combine a very leggy frame, deep chest, compact hindquarter attachment, eye direction that does not simply repeat the mouth direction, and a hump distinct from the backbone. Verify those relationships across skeletal and surface views, front and rear views, sitting poses, and the actual hump configuration. No single specimen supplies universal measurements.
