# Contributing to PASS

Contributions are welcome: corrections, new cards, stronger tests, runtime and
tooling improvements, documentation, and complete new skillsets can all become
part of PASS.

## Start with the owning instructions

Read `AGENTS.md`, then use the matching skill under `.agents/skills/` for the
work. PASS deliberately authors one domain per run. A contribution to one
skillset must not inspect or modify another skillset to make its change work.

For knowledge changes, follow `PASS/SKILL.md` and the phase-specific references
it routes to. Cards must remain valid and executable after their source is gone;
do not copy source passages, page references, research receipts, chat history, or
practice history into canonical cards.

## Adding a skillset

A new independent skillset normally includes:

- a package under `library/<domain>/` with valid modules and cards;
- optional empirical history under `memory/<domain>/`;
- matching repository discovery skills under `.agents/skills/` and
  `.claude/skills/`; and
- a canonical `SkillForge_*.yaml` release recipe when the skillset is ready for
  distribution.

Do not add a global registry or hand-maintained repo-wide index. Discovery comes
from the library, and generated indexes come from the cards.

## Validate the contribution

Run focused checks while working. For card/content-only changes, validate the
affected package and its generated indexes; do not run unrelated repository
tests or rewrite unrelated release recipes. Run the complete boundary only for
canonical promotion or when PASS/runtime/schema/generator/test architecture
changed.

```bash
# Focused package/content validation
python PASS/tools/validate.py --package art --verify-references
python PASS/tools/build_index.py --package art --check

# Full repository boundary when required
python PASS/tools/validate.py --verify-references
python PASS/tools/build_index.py --check
python PASS/tools/memory.py validate
python -m unittest discover -s tests -p "test_*.py"
```

If the contribution changes a release boundary, build and check the affected
release as described in `README.md` and `PASS/docs/MODULE_RELEASES.md`.

## Write useful commit notes

A pushed commit should explain the decision, not only name the files. Use a
short imperative subject and a body that records:

- why the change was needed;
- what behavior, contract, or content changed;
- which validation was run and its result; and
- whether the change has a PASS or SkillForge version impact.

For generated release archives, name the rebuilt products and state that their
release checks passed. Keep transient command output out of the message; record
the evidence another maintainer needs to understand and trust the commit.

Release notes belong in `CHANGELOG.md` as well as the commit body. A commit is
history for maintainers; the changelog is the curated history for users.

Every PASS commit advances [`VERSION`](VERSION) to a strictly greater Semantic
Version and adds the matching dated heading to `CHANGELOG.md`; during public beta,
increment the numeric prerelease suffix. Update the current-version statement in
`README.md` in the same commit. Keep `## Unreleased` empty in committed work: the
release builder refuses to package substantive notes left there, preventing new
contents from being published under an old identity. The versioning test checks
the working tree against `HEAD` before commit and checks `HEAD` against its first
parent after commit. Exported trees without Git history skip only that ancestry
check.

## Licensing contributions

PASS uses split open licensing:

- executable tools and runtime code are AGPL-3.0-or-later;
- authored knowledge, Skill instructions, documentation, declarative profiles,
  recipes, and original assets are CC-BY-SA-4.0.

By submitting a contribution for inclusion, you agree to license it under the
terms applicable to its destination and represent that you have the right to do
so. Identify third-party material and its license explicitly. Do not submit
material copied from a source merely because PASS studied that source.

See `LICENSE.md`, `NOTICE.md`, and `TRADEMARKS.md` for the complete project
policy.
